#pragma once
#include <vector>
#include <iostream>
#include <string>
#include <map>
#include <stack>
#include <set>
#include <list>
#include <algorithm>
#include <math.h>
#include <fstream>
#include <time.h>
using namespace std;

struct task_wcet
{
	int id_num;
	double wcet = 0.00;
};

struct mission_wcet
{
	string task_id;
	double wcet = 0.00;
};


struct task_start_time
{
	int process_id = -1;
	double start_time = -1;
	double finish_time = -1.0;
	double f = -1;
};

struct task
{
	string id;
	double wcet = 0.00;
	vector<string> predecessors_node;
	vector<string> successors_node;
	int replica_state = 0;
	double deadline = -1;
	double priority = -1;
	int process = -1;
	int layer = -1;
	bool can_be_fmin = false;
	bool has_change_replica = false;
	bool is_in_layer = false;
	bool already_choose = false;
	bool has_c = false;
	int min_frequncy_num = 0;
	double min_frequncy = 0.00;
	int opt_frequency_num = 0;
	double opt_frequency = 0.00;
	vector<task_start_time> replica_start_time;
	vector<task_start_time> optimal_replica_time;
	vector<task_start_time> late_replica_time;
};

struct process_task
{
	string task_id;
	int p_id = -1;
	int task_state = -1.00;
	double start_time = -1.00;
	double finish_time = -1.00;
	double f = -1.00;
};


struct process
{
	double ready_time = 0.00;
	double next_start_time = -1.00;
	vector<process_task> pt;
	vector<double> frequency;
};

struct process_time
{
	double time = 0.00;
	double start_time = 0.00;
	double finish_time = 0.00;
	bool is_start = false;
	string task_id;
	double f;
	int p_id = 0;
};

struct finish_time {
	bool finish = false;
	double ftime;
	int finish_pid = -1;
	int false_time = 0;
};

struct opti_fre
{
	double o_f = 0.00;
	int of_num = 0;

};

struct layer_record
{
	double layer_wcet = 0;
	vector<pair<string, double>> down_list;
	vector<process> process_list;
};


struct pro_point
{
	int p_id;
	int num;
};


class EFR_Schedule
{
public:
	EFR_Schedule();
	~EFR_Schedule();
	bool read_graph(string nodefile, string edgefile);
	void get_task_map(double edge_cost[10][10], int task_num, double *wcet, double g_reliability);
	void inital_process(vector<double> frenquncy, int process_num);
	void set_reliability(double rel);
	bool Calculate_Deadline_Priority(double globe_deadline);
	int Calculate_replica_number(string task_id, double reliability, double f);
	double Calculate_lamda_f(double f);
	double Calculate_Energy(double run_time, double run_f);
	double Calculate_Reliable(double run_time, double run_f);
	double Calculate_execution_time(double wcet, double run_f);
	opti_fre optimal_frequency(string task_id, double reliability);
	task_start_time divide_process(string task_id, int rep_num, double t_f);
	task_start_time divide_degree_process(string task_id, int rep_num, double t_f, int theta, int l);
	task_start_time divide_layer_process(string task_id, int rep_num, double t_f);
	task_start_time divide_additional_process(string task_id, int rep_num, double t_f);
	task_start_time divide_heft_process(string task_id, int rep_num);
	task_start_time divide_late_process(string task_id, int rep_num, double t_f);
	bool layer_process_distribution(vector<pair<string, double>> down_list, int layer_end, set<int> add_replica_task);
	bool layer_late_process_distribution(vector<pair<string, double>> up_list, int layer_end, set<int> add_replica_task);

	bool layer_best_process_distribution(vector<pair<string, double>> down_list, int layer_end, set<int> add_replica_task);

	void sort_task_with_priority();
	void change_ccr(double ccr);

	void clear_task_energy();
	void clear_task_map();

	vector<double> Calculate_Deadline_list(int num);
	vector<double> Calculate_Reliability_list(int num);
	int Calculate_task_num();
	int Calculate_task_num2();
	double Calculate_overlapping();
	double Calculate_primary_energy();
	double Calculate_real_energy();

	bool scheduing();
	bool final_scheduling();
	bool best_scheduling();
	void optimization();
	void another_optimization();

	bool Heft_scheduing();
	bool scheduing_optimal_heft();
	bool part_optimal_heft(vector<pair<string, double>> down_list);

	bool partial_scheduling();
	bool add_scheduling();
	bool scheduling_add_heft();
	bool choose_layer();
	bool add_optimization(layer_record lr_max);
	

	
	bool choose_all_layer();
	bool add_new_optimization(layer_record lr_max);
	bool add_modify_optimization(layer_record lr_max);

	bool choose_single_task();
	bool add_single_optimization(string task_id);

	bool another_choose_all_layer();
	bool another_add_new_optimization(layer_record lr_max);

	bool choose_secondary_layer();
	bool add_secondary_optimization(layer_record lr_max);
	bool new_optimization();

	bool decrease_scheduling();
	bool decrease_optimization();
	bool decrease_another_optimization();

	bool partial_optimization();
	bool choose_decrease_task();
	bool add_additional_test(layer_record lr_max);



	bool non_layer_scheduling();

	bool non_layer_partial_scheduling();

	bool ods_scheduling();
	bool ods_part_scheduling(double p_f, int r_num);
	bool ods_optimization();


	bool out_degree_ods_scheduling();
	bool out_degree_ods_part_scheduling(double p_f, int r_num);

	void Calculate_OD();
	int get_ODQ_number(string task_id);

	bool milp_schedule(string milpfile);


	double heft_static_run();
	double static_run();
	double dynamic_run();
	int output_add_additional_replica_num();
	int show_can_add_additional();

	void Display_schedule();
	void Display_heft_schedule();
	void Display_layer();
	void Display_energy();
	void Display_replica_num();
	void Display_optimal_replica();
	void Display_task_time(string task_id);
	void Display_Deadline();
	void Display_edge();
	void Display_frequency(string filename);
	void Display_frequency_list(string filename);
	void Display_optimal_frequency(string filename);
	void check_schedule();
	void set_radio(string radio);

	void output_schedule(string output_filename);
	int times = 0;
private:
	map<string, task> task_map;
	map<string, int> task_replica_number;
	map<string, map<string, double>> edge_communication;
	vector<pair<string, double>> downward_task_list;
	vector<process> process_list;
	vector<process> optimal_process_list;
	vector<process> heft_process_list;
	vector<layer_record> v_lr;
	map<string, double> task_energy_cost;
	map<string, finish_time> task_finish;
	map<string, double> task_original_start_time;
	map<string, int> OD;
	vector<pair<string, int>> ODQ;
	double f_max;
	double f_min;
	double lamda_0;
	double d;
	double globle_reliability;
	double single_reliability;
	int add_additional_replica_number;
	int can_add_additional;
	double bc_wc_radio = 0.1;


};

