#include "EFR_Schedule.h"

bool cmp(const pair<string, double>& a, const pair<string, double>& b) {
	return a.second > b.second;
}

bool cmp_degree(const pair<string, int>& a, const pair<string, int>& b)
{
	return a.second > b.second;
}

bool cmp_pt(const process_task&a, const process_task& b)
{
	return a.start_time < b.start_time;
}

bool cmp_larger_pt(const process_task&a, const process_task& b)
{
	return a.start_time > b.start_time;
}

bool cmp_tw(const task_wcet&a, const task_wcet&b)
{
	return a.wcet > b.wcet;
}

bool cmp_time(const process_time&a, const process_time&b)
{
	return a.time < b.time;
}

bool cmp_lr(const layer_record&a, const layer_record&b)
{
	return a.layer_wcet > b.layer_wcet;
}

bool cmp_mw(const mission_wcet& a, const mission_wcet& b)
{
	return a.wcet > b.wcet;
}

void SplitString(const string& s, vector<string>& v, const string& c)
{
	string::size_type pos1, pos2;
	pos2 = s.find(c);
	pos1 = 0;
	while (string::npos != pos2)
	{
		v.push_back(s.substr(pos1, pos2 - pos1));
		pos1 = pos2 + c.size();
		pos2 = s.find(c, pos1);
	}
	if (pos1 != s.length())
		v.push_back(s.substr(pos1));
}


EFR_Schedule::EFR_Schedule()
{
}


EFR_Schedule::~EFR_Schedule()
{
}

bool EFR_Schedule::read_graph(string nodefile, string edgefile)
{
	ifstream nf(nodefile);
	ifstream ef(edgefile);
	if (!nf.is_open())
	{
		cout << "未成功打开node文件: " << nodefile  << endl;
		return false;
	}
	if (!ef.is_open())
	{
		cout << "未成功打开edge文件: " << edgefile << endl;
		return false;
	}
	string temp;
	while (getline(nf, temp))
	{
		vector<string> node_temp;
		SplitString(temp, node_temp, " ");
		task_map[node_temp[0]].wcet = atof(node_temp[1].c_str());
	}
	string etemp;
	while(getline(ef, etemp))
	{
		vector<string> edge_temp;
		SplitString(etemp, edge_temp, " ");
		task_map[edge_temp[0]].successors_node.push_back(edge_temp[1]);
		task_map[edge_temp[1]].predecessors_node.push_back(edge_temp[0]);
		edge_communication[edge_temp[0]][edge_temp[1]] = atof(edge_temp[2].c_str());
	}
	nf.close();
	ef.close();
	return true;

}

void EFR_Schedule::get_task_map(double edge_cost[10][10], int task_num, double *wcet, double g_reliability)
{
	globle_reliability = g_reliability;
	for (int i = 0; i < task_num; i++)
	{
		task_map[to_string(i)].wcet = wcet[i];
		for (int j = 0; j < task_num; j++)
		{
			cout << "edge cost " << i << "," << j << ":" << edge_cost[i][j] << endl;
			if (edge_cost[i][j] != -1.00)
			{
				edge_communication[to_string(i)][to_string(j)] = edge_cost[i][j];
				task_map[to_string(i)].successors_node.push_back(to_string(j));
				task_map[to_string(j)].predecessors_node.push_back(to_string(i));
			}
		}
	}



}

void EFR_Schedule::inital_process(vector<double> frenquncy, int process_num)
{
	for (int i = 0; i < process_num; i++)
	{
		process p;
		p.frequency = frenquncy;
		process_list.push_back(p);
		heft_process_list.push_back(p);
	}
	f_max = frenquncy[0];
	f_min = frenquncy[frenquncy.size() - 1];
	lamda_0 = 0.000001;
	d = 4;
	add_additional_replica_number = 0;
	can_add_additional = 0;
}

void EFR_Schedule::set_reliability(double rel)
{
	globle_reliability = rel;
	single_reliability = pow(globle_reliability, 1.0 / task_map.size());
}


bool EFR_Schedule::Calculate_Deadline_Priority(double globe_deadline)
{
	list<string> backup_task;
	list<string> next_task_list;
	map<string, task>::iterator mt_it = task_map.begin();
	while (mt_it != task_map.end())
	{
		if (mt_it->second.successors_node.size() == 0)
		{
			mt_it->second.deadline = globe_deadline;
			mt_it->second.priority = mt_it->second.wcet;
			mt_it->second.layer = 0;
			backup_task.push_back(mt_it->first);
		}
		mt_it++;
	}
	//cout << "backup_task size: " << backup_task.size() << endl;
	//list<string> up_task = backup_task;
	while (!backup_task.empty())
	{
		string now_task = backup_task.front();
		backup_task.pop_front();
		for (int i = 0; i < task_map[now_task].predecessors_node.size(); i++)
		{
			string pre_task = task_map[now_task].predecessors_node[i];
			if (pre_task == "sink_1")
			{
				cout << "task_id: " << pre_task << "deadline: " << task_map[now_task].deadline << " wcet: " << task_map[now_task].wcet << " edge: " << edge_communication[pre_task][now_task] << endl;
			}
			double new_deadline = task_map[now_task].deadline - task_map[now_task].wcet - edge_communication[pre_task][now_task];
			double new_priority = task_map[now_task].priority + task_map[pre_task].wcet + edge_communication[pre_task][now_task];
			int new_layer = task_map[now_task].layer + 1;
			if (new_deadline < 0)
			{
				cout << "deadline error " << pre_task << endl;
				return false;
			}
			if (task_map[pre_task].layer == -1.00 || new_layer > task_map[pre_task].layer)
			{
				task_map[pre_task].layer = new_layer;
			}
			if ( task_map[pre_task].deadline == -1.00 || new_deadline < task_map[pre_task].deadline)
			{
				task_map[pre_task].deadline = new_deadline;
			}
			if ( task_map[pre_task].priority == -1.00 || new_priority > task_map[pre_task].priority)
			{
				task_map[pre_task].priority = new_priority;
			}
			next_task_list.push_back(pre_task);
		}
		if (backup_task.empty())
		{
			set<string> s(next_task_list.begin(), next_task_list.end());
			backup_task.assign(s.begin(), s.end());
			next_task_list.clear();
		}
		//cout << "backup_task size: " << backup_task.size() << endl;
	}

	/*while (!up_task.empty())
	{
		string now_task = up_task.front();
		up_task.pop_front();
		//cout << "in up task" << endl;
		for (int i = 0; i < task_map[now_task].predecessors_node.size(); i++)
		{
			string next_task = task_map[now_task].predecessors_node[i];
			int new_layer = task_map[now_task].layer + 1;
			if (task_map[next_task].layer == -1 || new_layer > task_map[next_task].layer)
			{
				task_map[next_task].layer = new_layer;
			}
			up_task.push_back(next_task);
		}
		set<string> s(up_task.begin(), up_task.end());
		up_task.assign(s.begin(), s.end());
	}*/


	return true;
}

int EFR_Schedule::Calculate_replica_number(string task_id, double reliability, double f)
{
	double pri_rel = exp(-Calculate_lamda_f(f)*(task_map[task_id].wcet / f));
	double sec_rel = exp(-Calculate_lamda_f(f_max)*(task_map[task_id].wcet));
	//cout << "pri_rel:" << pri_rel << endl;
	//cout << "sec_rel:" << sec_rel << endl;
	if (pri_rel >= reliability)
		return 1;
	int sec_num = ceil(log((1 - reliability) / (1 - pri_rel)) / log(1 - sec_rel));
	if (sec_num + 1 <= process_list.size())
		return sec_num + 1;
	else
		return -1;
}

double EFR_Schedule::Calculate_lamda_f(double f)
{
	return lamda_0 * exp(d*(1 - f) / (1 - f_min));
}

double EFR_Schedule::Calculate_Energy(double run_time, double run_f)
{
	return run_f * run_f * run_time;
}

double EFR_Schedule::Calculate_Reliable(double run_time, double run_f)
{
	return exp(-Calculate_lamda_f(run_f)*(run_time));
}

double EFR_Schedule::Calculate_execution_time(double wcet, double run_f)
{
	srand((unsigned)time(NULL));
	double s = 0.1 + rand() % 21 / (double)100;
	double wf = wcet * s + (1 - s)*wcet / run_f;
	if (wf < 0)
		cout << "wf <<<<<<<< 0  s: " << s << " " << wcet << " " << run_f << endl;
	return wf;
}

opti_fre EFR_Schedule::optimal_frequency(string task_id, double reliability)
{
	double wcet = task_map[task_id].wcet;
	opti_fre of;
	vector<double> frequency = process_list[0].frequency;
	double min_E = -1.00;
	double o_f = 0.0;
	int of_num = 0;
	for (int i = 0; i < frequency.size(); i++)
	{
		double r1 = Calculate_Reliable(task_map[task_id].wcet / frequency[i], frequency[i]);
		double r2 = Calculate_Reliable(task_map[task_id].wcet, f_max);
		int r_num = Calculate_replica_number(task_id, reliability, frequency[i]);
		double Energy = 0.00;
		for (int n = 1; n <= r_num; n++)
		{
			if (n == 1)
				Energy = frequency[i] * frequency[i] * (wcet / frequency[i]);
			else if (n == 2)
				Energy += (1 - r1) * (double)f_max*wcet;
			else
			{
				Energy += (1 - r1) * pow((1 - r2), n - 2) * (double)f_max*wcet;
			}
		}
		//double Energy = frequency[i] * frequency[i] * ( wcet/frequency[i] ) + (1 - r1) * (double)f_max*wcet*(r_num - 1);
		if (min_E == -1.00 || Energy < min_E)
		{
			min_E = Energy;
			o_f = frequency[i];
			of_num = i;
		}
	}
	if (of_num == 0)
		cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
	of.of_num = of_num;
	of.o_f = o_f;
	return of;
}

task_start_time EFR_Schedule::divide_process(string task_id, int rep_num, double t_f)
{
	double min_start_time = -1.00;
	int process_id = 0;
	set<int> already_process_id;
	for (int i = 0; i < task_map[task_id].replica_start_time.size(); i++)
	{
		already_process_id.insert(task_map[task_id].replica_start_time[i].process_id);
	}
	//double max_end_time = -1.00;
	for (int i = 0; i < process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;
		double max_end_time = -1.00;
		for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
		{
			double late_start_time = -1.00;
			string pre_task = task_map[task_id].predecessors_node[j];
			double commu_time = edge_communication[pre_task][task_id];
			double wcet = task_map[pre_task].wcet;
			int rsize = task_map[pre_task].replica_start_time.size();
			if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
			{
				if (rsize == 1)
				{
					//late_start_time = task_map[pre_task].replica_start_time[0].start_time + wcet / task_map[pre_task].replica_start_time[0].f;
					late_start_time = task_map[pre_task].replica_start_time[0].finish_time;
				}
				else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
				{
					//late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f;
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time;
				}	
				else
				{
					//late_start_time = task_map[pre_task].replica_start_time[rsize - 2].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 2].f + commu_time;
					late_start_time = task_map[pre_task].replica_start_time[rsize - 2].finish_time + commu_time;
				}				
			}
			else
			{
				//late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f + commu_time;
				late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time + commu_time;
			}
			if (rsize > 1)
				late_start_time = max(late_start_time, task_map[pre_task].replica_start_time[0].finish_time + commu_time);
			if (max_end_time < late_start_time)
				max_end_time = late_start_time;
		}
		double start_time = max(max_end_time, process_list[i].ready_time);
		if (min_start_time == -1.00 || start_time < min_start_time)
		{
			min_start_time = start_time;
			process_id = i;
		}
	}

	/*for (int i = 0; i < task_map[task_id].predecessors_node.size(); i++)
	{
		double late_start_time = -1.00;
		string pre_task = task_map[task_id].predecessors_node[i];
		double commu_time = edge_communication[pre_task][task_id];
		double wcet = task_map[pre_task].wcet;
		for (int j = 0; j < task_replica_number[pre_task]; j++)
		{
			if (late_start_time < task_map[pre_task].replica_start_time[j].start_time + wcet + commu_time)
				late_start_time = task_map[pre_task].replica_start_time[j].start_time + wcet + commu_time;
		}
		if (max_end_time < late_start_time)
			max_end_time = late_start_time;
	}
	int process_id = 0;
	double min_start_time = -1.00;
	for (int i = 0; i < process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;
		double start_time = max(max_end_time , process_list[i].ready_time);
		
		if (min_start_time == -1.00 || min_start_time > start_time)
		{
			//cout << "now task:" << task_id << " start time:" << start_time << " min start time: " << min_start_time << " p id:" << i << endl;
			min_start_time = start_time;
			process_id = i;
		}			
	}*/
	
	process_task new_pt;
	task_start_time new_ts;
	double wf = Calculate_execution_time(task_map[task_id].wcet, t_f);
	new_ts.process_id = process_id;
	new_ts.start_time = min_start_time;
	new_ts.f = t_f;
	new_ts.finish_time = min_start_time + wf;
	new_pt.start_time = min_start_time;
	new_pt.task_id = task_id;
	new_pt.task_state = rep_num;
	new_pt.f = t_f;
	new_pt.finish_time = min_start_time + wf;
	process_list[process_id].pt.push_back(new_pt);
	process_list[process_id].ready_time = min_start_time + wf;


	return new_ts;
}

task_start_time EFR_Schedule::divide_degree_process(string task_id, int rep_num, double t_f, int theta, int l)
{
	double min_start_time = -1.00;
	int process_id = 0;
	set<int> already_process_id;
	for (int i = 0; i < task_map[task_id].replica_start_time.size(); i++)
	{
		already_process_id.insert(task_map[task_id].replica_start_time[i].process_id);
	}
	//double max_end_time = -1.00;
	int now_place = get_ODQ_number(task_id);
	if (now_place <= l)
	{
		for (int i = 0; i < process_list.size(); i++)
		{
			if (already_process_id.find(i) != already_process_id.end())
				continue;

			double max_end_time = -1.00;
			for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
			{
				double late_start_time = -1.00;
				string pre_task = task_map[task_id].predecessors_node[j];
				double commu_time = edge_communication[pre_task][task_id];
				double wcet = task_map[pre_task].wcet;
				int rsize = task_map[pre_task].replica_start_time.size();
				if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
				{
					if (rsize == 1)
					{
						late_start_time = task_map[pre_task].replica_start_time[0].finish_time;
					}
					else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
					{
						late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time;
					}
					else
					{
						late_start_time = task_map[pre_task].replica_start_time[rsize - 2].finish_time + commu_time;
					}
				}
				else
				{
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time;
				}
				if (task_map[task_id].replica_start_time.size() > 0)
					if (late_start_time < task_map[task_id].replica_start_time[0].start_time)
						late_start_time = task_map[task_id].replica_start_time[0].start_time;
				if (max_end_time < late_start_time)
					max_end_time = late_start_time;
			}
			double start_time = max(max_end_time, process_list[i].ready_time);
			if (min_start_time == -1.00 || start_time < min_start_time)
			{
				min_start_time = start_time;
				process_id = i;
			}
		}
	}
	else
	{
		for (int i = 0; i < process_list.size(); i++)
		{
			if (already_process_id.find(i) != already_process_id.end())
				continue;
			double max_end_time = -1.00;
			for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
			{
				double late_start_time = -1.00;
				string pre_task = task_map[task_id].predecessors_node[j];
				double commu_time = edge_communication[pre_task][task_id];
				double wcet = task_map[pre_task].wcet;
				int rsize = task_map[pre_task].replica_start_time.size();
				if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
				{
					if (rsize == 1)
					{
						late_start_time = task_map[pre_task].replica_start_time[0].finish_time;
					}
					else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
					{
						late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time;
					}
					else
					{
						late_start_time = task_map[pre_task].replica_start_time[rsize - 2].finish_time + commu_time;
					}
				}
				else
				{
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].finish_time;
				}
				if (task_map[task_id].replica_start_time.size() > 0)
					if (late_start_time < task_map[task_id].replica_start_time[0].start_time)
						late_start_time = task_map[task_id].replica_start_time[0].start_time;
				if (max_end_time < late_start_time)
					max_end_time = late_start_time;
			}
			double start_time = max(max_end_time, process_list[i].ready_time);
			if (min_start_time == -1.00 || start_time < min_start_time)
			{
				min_start_time = start_time;
				process_id = i;
			}
			break;
		}
	}
	

	process_task new_pt;
	task_start_time new_ts;
	double wf = Calculate_execution_time(task_map[task_id].wcet, t_f);
	new_ts.process_id = process_id;
	new_ts.start_time = min_start_time;
	new_ts.f = t_f;
	new_ts.finish_time = min_start_time + wf;
	new_pt.start_time = min_start_time;
	new_pt.task_id = task_id;
	new_pt.task_state = rep_num;
	new_pt.f = t_f;
	new_pt.finish_time = min_start_time + wf;
	process_list[process_id].pt.push_back(new_pt);
	process_list[process_id].ready_time = min_start_time + wf;


	return new_ts;
}

task_start_time EFR_Schedule::divide_layer_process(string task_id, int rep_num, double t_f)
{
	double min_start_time = -1.00;
	int process_id = 0;
	set<int> already_process_id;
	for (int i = 0; i < task_map[task_id].optimal_replica_time.size(); i++)
	{
		already_process_id.insert(task_map[task_id].optimal_replica_time[i].process_id);
	}
	//double max_end_time = -1.00;
	for (int i = 0; i < process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;

		double max_end_time = -1.00;
		for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
		{
			double late_start_time = -1.00;
			string pre_task = task_map[task_id].predecessors_node[j];
			double commu_time = edge_communication[pre_task][task_id];
			double wcet = task_map[pre_task].wcet;
			int rsize = task_map[pre_task].replica_start_time.size();
			if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
			{
				if (rsize == 1)
					late_start_time = task_map[pre_task].replica_start_time[0].start_time + wcet / task_map[pre_task].replica_start_time[0].f;
				else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f;
				else
					late_start_time = task_map[pre_task].replica_start_time[rsize - 2].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 2].f + commu_time;
			}
			else
			{
				late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f + commu_time;
			}
			if (max_end_time < late_start_time)
				max_end_time = late_start_time;
		}
		double start_time = max(max_end_time, process_list[i].ready_time);
		if (min_start_time == -1.00 || start_time < min_start_time)
		{
			min_start_time = start_time;
			process_id = i;
		}
	}

	/*for (int i = 0; i < task_map[task_id].predecessors_node.size(); i++)
	{
		double late_start_time = -1.00;
		string pre_task = task_map[task_id].predecessors_node[i];
		double commu_time = edge_communication[pre_task][task_id];
		double wcet = task_map[pre_task].wcet;
		for (int j = 0; j < task_replica_number[pre_task]; j++)
		{
			if (late_start_time < task_map[pre_task].replica_start_time[j].start_time + wcet + commu_time)
				late_start_time = task_map[pre_task].replica_start_time[j].start_time + wcet + commu_time;
		}
		if (max_end_time < late_start_time)
			max_end_time = late_start_time;
	}
	int process_id = 0;
	double min_start_time = -1.00;
	for (int i = 0; i < process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;
		double start_time = max(max_end_time , process_list[i].ready_time);

		if (min_start_time == -1.00 || min_start_time > start_time)
		{
			//cout << "now task:" << task_id << " start time:" << start_time << " min start time: " << min_start_time << " p id:" << i << endl;
			min_start_time = start_time;
			process_id = i;
		}
	}*/

	process_task new_pt;
	task_start_time new_ts;
	new_ts.process_id = process_id;
	new_ts.start_time = min_start_time;
	new_ts.f = t_f;
	new_ts.finish_time = min_start_time + task_map[task_id].wcet / t_f;
	new_pt.start_time = min_start_time;
	new_pt.task_id = task_id;
	new_pt.task_state = rep_num;
	new_pt.f = t_f;
	new_pt.finish_time = min_start_time + task_map[task_id].wcet / t_f;
	process_list[process_id].pt.push_back(new_pt);
	process_list[process_id].ready_time = min_start_time + task_map[task_id].wcet / t_f;


	return new_ts;
}

task_start_time EFR_Schedule::divide_additional_process(string task_id, int rep_num, double t_f)
{
	double min_start_time = -1.00;
	int process_id = 0;
	set<int> already_process_id;
	for (int i = 0; i < task_map[task_id].replica_start_time.size(); i++)
	{
		already_process_id.insert(task_map[task_id].replica_start_time[i].process_id);
	}
	//double max_end_time = -1.00;
	for (int i = 0; i < process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;
		double max_end_time = -1.00;
		for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
		{
			double late_start_time = -1.00;
			string pre_task = task_map[task_id].predecessors_node[j];
			double commu_time = edge_communication[pre_task][task_id];
			double wcet = task_map[pre_task].wcet;
			int rsize = task_map[pre_task].replica_start_time.size();
			if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
			{
				if (rsize == 1)
					late_start_time = task_map[pre_task].replica_start_time[0].start_time + wcet / task_map[pre_task].replica_start_time[0].f;
				else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f;
				else
					late_start_time = task_map[pre_task].replica_start_time[rsize - 2].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 2].f + commu_time;
			}
			else
			{
				late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet / task_map[pre_task].replica_start_time[rsize - 1].f + commu_time;
			}

			if (max_end_time < late_start_time)
				max_end_time = late_start_time;
		}
		max_end_time = max(max_end_time, task_map[task_id].replica_start_time[0].start_time + task_map[task_id].wcet / task_map[task_id].replica_start_time[0].f);
		double start_time = max(max_end_time, process_list[i].ready_time);
		if (min_start_time == -1.00 || start_time < min_start_time)
		{
			min_start_time = start_time;
			process_id = i;
		}
	}

	process_task new_pt;
	task_start_time new_ts;
	new_ts.process_id = process_id;
	new_ts.start_time = min_start_time;
	new_ts.f = t_f;
	new_pt.start_time = min_start_time;
	new_pt.task_id = task_id;
	new_pt.task_state = rep_num;
	new_pt.f = t_f;
	process_list[process_id].pt.push_back(new_pt);
	process_list[process_id].ready_time = min_start_time + task_map[task_id].wcet / t_f;


	return new_ts;
}

task_start_time EFR_Schedule::divide_heft_process(string task_id, int rep_num)
{
	double min_start_time = -1.00;
	int process_id = 0;
	set<int> already_process_id;
	for (int i = 0; i < task_map[task_id].replica_start_time.size(); i++)
	{
		already_process_id.insert(task_map[task_id].replica_start_time[i].process_id);
	}
	//double max_end_time = -1.00;
	for (int i = 0; i < heft_process_list.size(); i++)
	{
		if (already_process_id.find(i) != already_process_id.end())
			continue;
		double max_end_time = -1.00;
		for (int j = 0; j < task_map[task_id].predecessors_node.size(); j++)
		{
			double late_start_time = -1.00;
			string pre_task = task_map[task_id].predecessors_node[j];
			double commu_time = edge_communication[pre_task][task_id];
			double wcet = task_map[pre_task].wcet;
			int rsize = task_map[pre_task].replica_start_time.size();
			if (rsize == 0)
				cout << pre_task << ":" << task_map[pre_task].priority << " " << task_id << ":" << task_map[task_id].priority << endl;
			if (task_map[pre_task].replica_start_time[rsize - 1].process_id == i)
			{
				if (rsize == 1)
					late_start_time = task_map[pre_task].replica_start_time[0].start_time + wcet;
				else if (task_map[pre_task].replica_start_time[rsize - 1].start_time > task_map[pre_task].replica_start_time[rsize - 2].start_time + commu_time)
					late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet;
				else
					late_start_time = task_map[pre_task].replica_start_time[rsize - 2].start_time + wcet + commu_time;
			}
			else
			{
				late_start_time = task_map[pre_task].replica_start_time[rsize - 1].start_time + wcet + commu_time;
			}
			if (max_end_time < late_start_time)
				max_end_time = late_start_time;
		}
		double start_time = max(max_end_time, heft_process_list[i].ready_time);
		if (min_start_time == -1.00 || start_time < min_start_time)
		{
			min_start_time = start_time;
			process_id = i;
		}
	}
	
	process_task new_pt;
	task_start_time new_ts;
	new_ts.process_id = process_id;
	new_ts.start_time = min_start_time;
	new_ts.f = f_max;
	new_pt.start_time = min_start_time;
	new_pt.task_id = task_id;
	new_pt.task_state = rep_num;
	new_pt.f = f_max;
	heft_process_list[process_id].pt.push_back(new_pt);
	heft_process_list[process_id].ready_time = min_start_time + task_map[task_id].wcet;


	return new_ts;



}

task_start_time EFR_Schedule::divide_late_process(string task_id, int rep_num, double t_f)
{
	double max_start_time = -1.00;
	double Et_max = -1.00;
	for (int i = 0; i < task_map[task_id].successors_node.size(); i++)
	{
		string next_task_id = task_map[task_id].successors_node[i];
		if (Et_max == -1.00 || Et_max > task_map[next_task_id].optimal_replica_time[0].start_time - edge_communication[task_id][next_task_id])
		{
			Et_max = task_map[next_task_id].optimal_replica_time[0].start_time - edge_communication[task_id][next_task_id];
		}

	}
	//cout << "1" << endl;
	if (Et_max == -1.00)
		Et_max = task_map[task_id].deadline;
	else
		Et_max = min(task_map[task_id].deadline, Et_max);
	//cout << "2" << endl;
	if (rep_num < task_map[task_id].replica_start_time.size())
	{
		if (optimal_process_list[task_map[task_id].replica_start_time[rep_num].process_id].next_start_time == -1.00)
		{
			optimal_process_list[task_map[task_id].replica_start_time[rep_num].process_id].next_start_time = Et_max - task_map[task_id].wcet;
		}
		else
		{
			Et_max = min(Et_max, optimal_process_list[task_map[task_id].replica_start_time[rep_num].process_id].next_start_time);
		}
	}
	else
	{
		set<int> already_process_id;
		for (int i = 0; i < task_map[task_id].replica_start_time.size(); i++)
		{
			already_process_id.insert(task_map[task_id].replica_start_time[i].process_id);
		}
		double max_end_time = -1.00;
		int p_id = 0;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			if (already_process_id.find(i) != already_process_id.end())
				continue;
			if (max_end_time == -1.00 || max_end_time < min(Et_max, optimal_process_list[i].next_start_time))
			{
				p_id = i;
				max_end_time = min(Et_max, optimal_process_list[i].next_start_time);
			}
		}
		task_start_time new_st;
		new_st.process_id = p_id;
		new_st.f = f_max;
		new_st.start_time = max_end_time - task_map[task_id].wcet;

		//task_map[task_id].optimal_replica_time.insert(task_map[task_id].optimal_replica_time.begin(), new_st);
		optimal_process_list[p_id].next_start_time = new_st.start_time;
		process_task new_pt;
		new_pt.task_id = task_id;
		new_pt.start_time = new_st.start_time;
		new_pt.task_state = rep_num;
		new_pt.f = f_max;
		optimal_process_list[p_id].pt.insert(optimal_process_list[p_id].pt.begin(), new_pt);

		return new_st;


	}
	
	//cout << "3" << endl;
	task_start_time now_st = task_map[task_id].replica_start_time[rep_num];
	task_start_time new_st;
	new_st.process_id = now_st.process_id;
	new_st.f = f_max;
	if (now_st.start_time < Et_max - task_map[task_id].wcet)
		new_st.start_time = Et_max - task_map[task_id].wcet;
	else
		new_st.start_time = now_st.start_time;

	//task_map[task_id].optimal_replica_time.insert(task_map[task_id].optimal_replica_time.begin(), new_st);
	optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
	process_task new_pt;
	new_pt.task_id = task_id;
	new_pt.start_time = new_st.start_time;
	new_pt.task_state = rep_num;
	new_pt.f = f_max;
	optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);

	return new_st;

}

bool EFR_Schedule::layer_process_distribution(vector<pair<string, double>> down_list, int layer_end, set<int> add_replica_task)
{
	map<string, int> new_task_replica;
	int max_replica_num = -1;
	for (int i = 0; i <= layer_end; i++)
	{
		string now_task_id = down_list[i].first;
		task_map[now_task_id].optimal_replica_time.clear();
		if (add_replica_task.find(i) != add_replica_task.end())
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id] + 1;
		}
		else
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id];
		}
		if (max_replica_num == -1 || max_replica_num < new_task_replica[now_task_id])
			max_replica_num = new_task_replica[now_task_id];
		task_start_time new_st = divide_layer_process(down_list[i].first, 0, f_max);
		task_map[now_task_id].optimal_replica_time.push_back(new_st);
	}
	//cout << "optimal max_replica_num: " << max_replica_num << endl;
	for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++)
	{
		for (int i = 0; i <= layer_end; i++)
		{
			if (rep_num > new_task_replica[down_list[i].first] - 1)
				continue;
			string now_task_id = down_list[i].first;
			task_start_time new_st = divide_layer_process(now_task_id, rep_num, f_max);
			task_map[now_task_id].optimal_replica_time.push_back(new_st);
		}
	}

	bool exceed_deadline = false;

	for (int i = 0; i <= layer_end; i++)
	{
		double now_end_time = task_map[down_list[i].first].optimal_replica_time[new_task_replica[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			exceed_deadline = true;
			break;
		}
	}


	if (exceed_deadline == true)
		return false;
	else
		return true;

}

bool EFR_Schedule::layer_late_process_distribution(vector<pair<string, double>> up_list, int layer_end, set<int> add_replica_task)
{
	map<string, int> new_task_replica;
	int max_replica_num = -1;
	for (int i = 0; i <= layer_end; i++)
	{
		string now_task_id = up_list[i].first;
		task_map[now_task_id].optimal_replica_time.clear();
		if (add_replica_task.find(i) != add_replica_task.end())
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id] + 1;
		}
		else
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id];
		}
		if (max_replica_num == -1 || max_replica_num < new_task_replica[now_task_id])
			max_replica_num = new_task_replica[now_task_id];
	}
	//cout << "ddd" << endl;
	//cout << "optimal max_replica_num: " << max_replica_num << endl;
	for (int rep_num = max_replica_num - 1; rep_num >= 0; rep_num--)
	{
		for (int i = 0; i <= layer_end; i++)
		{
			if (rep_num > new_task_replica[up_list[i].first] - 1)
				continue;
			//cout << "fff1" << endl;
			string now_task_id = up_list[i].first;
			task_start_time new_st = divide_late_process(now_task_id, rep_num, f_max);
			//cout << "fff" << endl;
			task_map[now_task_id].late_replica_time.insert(task_map[now_task_id].late_replica_time.begin(),new_st);
		}
	}

	bool exceed_start_time = false;

	for (int i = 0; i <= layer_end; i++)
	{
		double now_start_time = task_map[up_list[i].first].late_replica_time[0].start_time;
		if (now_start_time < task_original_start_time[up_list[i].first])
		{
			exceed_start_time = true;
			break;
		}
	}


	if (exceed_start_time == true)
		return false;
	else
		return true;
}

bool EFR_Schedule::layer_best_process_distribution(vector<pair<string, double>> down_list, int layer_end, set<int> add_replica_task)
{
	map<string, int> new_task_replica;
	int max_replica_num = -1;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i <= layer_end; i++)
	{
		string now_task_id = down_list[i].first;
		task_map[now_task_id].replica_start_time.clear();
		if (add_replica_task.find(i) != add_replica_task.end())
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id] + 1;
		}
		else
		{
			new_task_replica[now_task_id] = task_replica_number[now_task_id];
		}
		if (max_replica_num == -1 || max_replica_num < new_task_replica[now_task_id])
			max_replica_num = new_task_replica[now_task_id];
		task_start_time new_st = divide_process(down_list[i].first, 0, f_max);
		task_map[now_task_id].replica_start_time.push_back(new_st);
	}
	//cout << "optimal max_replica_num: " << max_replica_num << endl;
	for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++)
	{
		for (int i = 0; i <= layer_end; i++)
		{
			if (rep_num > new_task_replica[down_list[i].first] - 1)
				continue;
			string now_task_id = down_list[i].first;
			task_start_time new_st = divide_process(now_task_id, rep_num, f_max);
			task_map[now_task_id].replica_start_time.push_back(new_st);
		}
	}

	bool exceed_deadline = false;

	for (int i = 0; i <= layer_end; i++)
	{
		double now_end_time = task_map[down_list[i].first].replica_start_time[new_task_replica[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			exceed_deadline = true;
			break;
		}
	}


	if (exceed_deadline == true)
		return false;
	
	down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		if (!task_map[down_list[0].first].is_in_layer) //说明当前层为顺序层，才有顺序方式排列
		{
			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，返回false
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}
		}
		else //当前层为layer-by-layer
		{
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = task_replica_number[down_list[i].first];
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}

			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}

			bool exceed_deadline = false;
			//cout << "aaa" << endl;
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline)
				return false;

		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	
	
	}

	return true;
}

void EFR_Schedule::sort_task_with_priority()
{
	map<string, task>::iterator mt_it = task_map.begin();
	map<string, double> map_tp;
	while (mt_it != task_map.end())
	{
		map_tp[mt_it->first] = mt_it->second.priority;
		mt_it++;
	}
	downward_task_list.assign(map_tp.begin(), map_tp.end());
	sort(downward_task_list.begin(), downward_task_list.end(), cmp);
}

void EFR_Schedule::change_ccr(double ccr)
{
	map<string, map<string, double>>::iterator e_it_1 = edge_communication.begin();
	while (e_it_1 != edge_communication.end())
	{
		map<string, double>::iterator e_it_2 = e_it_1->second.begin();
		while (e_it_2 != e_it_1->second.end())
		{
			e_it_2->second *= ccr;
			e_it_2++;
		}
		e_it_1++;
	}
}

void EFR_Schedule::clear_task_energy()
{
	task_energy_cost.clear();
	task_finish.clear();
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time = t_it->second.replica_start_time;
		t_it++;
	}
}

void EFR_Schedule::clear_task_map()
{
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.layer = -1;
		t_it->second.deadline = -1;
		t_it->second.priority = -1;
		t_it->second.replica_start_time.clear();
		t_it++;
	}
	for (int i = 0; i < heft_process_list.size(); i++)
	{
		heft_process_list[i].pt.clear();
		heft_process_list[i].next_start_time = -1.00;
		heft_process_list[i].ready_time = 0.00;
	}
	downward_task_list.clear();
}

vector<double> EFR_Schedule::Calculate_Deadline_list(int num)
{
	map<string, task>::iterator t_it = task_map.begin();
	double total_wcet = 0.00;
	while (t_it != task_map.end())
	{
		total_wcet += t_it->second.wcet;
		t_it++;
	}

	double deadline = (double)total_wcet/heft_process_list.size();
	bool has_find_deadline = false;
	while (!has_find_deadline)
	{
		if (Calculate_Deadline_Priority(deadline))
		{
			sort_task_with_priority();
			//cout << "aaa" << endl;
			if (Heft_scheduing())
				has_find_deadline = true;
			else
			{
				clear_task_map();
				deadline *= 1.1;
			}
			//cout << "bbb" << endl;
				
		}
		else
		{
			clear_task_map();
			deadline *= 1.1;
		}
	}
	clear_task_map();
	double max_deadline = 10 * deadline;
	vector<double> deadline_list;
	deadline_list.push_back(deadline);
	for (int i = 0; i < num - 2; i++)
	{
		deadline_list.push_back(deadline + (max_deadline - deadline) / (num - 1)*(i + 1));
	}
	deadline_list.push_back(max_deadline);

	return deadline_list;

}

vector<double> EFR_Schedule::Calculate_Reliability_list(int num)
{
	map<string, task>::iterator t_it = task_map.begin();
	double min_rel = 1.00;
	while (t_it != task_map.end())
	{
		min_rel *= exp(-Calculate_lamda_f(f_max)*(t_it->second.wcet / f_max));
		t_it++;
	}
	vector<double> rel_list;
	rel_list.push_back(min_rel);
	for (int i = 1; i < num; i++)
	{
		rel_list.push_back(1.00 - (double)(1.00 - min_rel)*(double)pow(0.1, i));
	}
	return rel_list;
}

int EFR_Schedule::Calculate_task_num()
{
	int num = 0;
	for (int i = 0; i < process_list.size(); i++)
	{
		num += process_list[i].pt.size();
	}
	return num;
}

int EFR_Schedule::Calculate_task_num2()
{
	int num = 0;
	map<string, int>::iterator t_it = task_replica_number.begin();
	while (t_it != task_replica_number.end())
	{
		num += t_it->second;
		t_it++;
	}
	return num;
}

double EFR_Schedule::Calculate_overlapping()
{
	double overlapping_energy = 0.00;
	map<string, task>::iterator tm_it = task_map.begin();

	while (tm_it != task_map.end())
	{
		string t_id = tm_it->first;
		double end_time = task_map[t_id].replica_start_time[0].start_time + task_map[t_id].wcet / task_map[t_id].replica_start_time[0].f;
		for (int i = 1; i < task_replica_number[t_id]; i++)
		{
			if (task_map[t_id].replica_start_time[i].start_time < end_time)
			{
				double overlap_time = min(end_time - task_map[t_id].replica_start_time[i].start_time, task_map[t_id].wcet);
				overlapping_energy += overlap_time * f_max * f_max;
			}
		}
		tm_it++;
	}
	
	return overlapping_energy;
}

double EFR_Schedule::Calculate_primary_energy()
{
	double e = 0.00;
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		e += t_it->second.wcet * t_it->second.replica_start_time[0].f;
		t_it++;
	}
	return e;
}

double EFR_Schedule::Calculate_real_energy()
{
	double e = 0.00;
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		double f_pri = t_it->second.replica_start_time[0].f;
		double wcet = t_it->second.wcet;
		double r1 = Calculate_Reliable(wcet / f_pri, f_pri);
		if (t_it->second.replica_start_time.size() > 1)
		{
			e += t_it->second.wcet * t_it->second.replica_start_time[0].f + (1 - r1)*wcet*f_max;
		}
		else
		{
			e += t_it->second.wcet * t_it->second.replica_start_time[0].f;
		}
		t_it++;
	}
	return e;
}

bool EFR_Schedule::scheduing()
{
	vector<pair<string,double>> down_list =  downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}				
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}
		
		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].finish_time;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}				
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{
			
			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].finish_time;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}
			
			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose part optimal heft" << endl;
				return part_optimal_heft(down_list);
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}
				
		}  //当分层分配方式成功时，计算f_min时的replica数量，并进行相应分配，以期得到更好的优化结果
		else
		{
			vector<process> pre_process_list = process_list;
			process_list = temp_process_list;
			vector<task_wcet> possible_change_task;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_min的replica数量
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				//cout << "task id:" << down_list[i].first << "another: " << another_replica_num << "pri:" << task_replica_number[down_list[i].first] << endl;
				if (another_replica_num == -1)
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else if (another_replica_num > task_replica_number[down_list[i].first])
				{
					can_add_additional++;
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_wcet new_tw;
					new_tw.id_num = i;
					new_tw.wcet = task_map[down_list[i].first].wcet;
					possible_change_task.push_back(new_tw);
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size()-1; j >=0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}

			sort(possible_change_task.begin(), possible_change_task.end(), cmp_tw);

			set<int> add_replica_task;

			for (int i = 0; i < possible_change_task.size(); i++)
			{
				set<int> temp_add_replica = add_replica_task;
				temp_add_replica.insert(possible_change_task[i].id_num);
				process_list = temp_process_list;
				if (layer_process_distribution(down_list, layer_end, temp_add_replica))
				{
					add_replica_task = temp_add_replica;
				}
			}



			if (add_replica_task.empty())
			{
				process_list = pre_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].optimal_replica_time.clear();
				}

			}
			else
			{
				process_list = temp_process_list;
				layer_process_distribution(down_list, layer_end, add_replica_task);
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time = task_map[down_list[i].first].optimal_replica_time;
					task_map[down_list[i].first].optimal_replica_time.clear();
				}
			}

			for (int j = 0; j < possible_change_task.size(); j++)
			{
				if (add_replica_task.find(possible_change_task[j].id_num) == add_replica_task.end())
				{
					task_map[down_list[possible_change_task[j].id_num].first].can_be_fmin = false;
					task_map[down_list[possible_change_task[j].id_num].first].has_change_replica = false;
				}
				else
				{
					task_replica_number[down_list[possible_change_task[j].id_num].first]++;
					add_additional_replica_number++;
				}
			}


		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	return true;
}

bool EFR_Schedule::final_scheduling()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	partial_scheduling();
	// 此时partial_scheduling分配成功，选择从后往前分配additional replica
	vector<pair<string, double>> up_list = downward_task_list;
	reverse(up_list.begin(), up_list.end());
	optimal_process_list = process_list;
	bool has_changed = true;
	vector<pair<string, double>> temp_up_list = up_list;
	while (has_changed)
	{
		has_changed = false;
		up_list = temp_up_list;
		for (int i = 0; i < process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].next_start_time = -1.00;
			optimal_process_list[i].ready_time = 0.00;
		}
		while (!up_list.empty())
		{
			vector<process> temp_optimal_process = optimal_process_list;
			int layer_end = 0;
			while (layer_end < up_list.size())  //计算同层任务数
			{
				if (task_map[up_list[0].first].layer != task_map[up_list[layer_end].first].layer)
				{
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (task_map[up_list[0].first].is_in_layer) //当前层为layer-by-layer层
			{
				double max_replica_num = -1.00;
				for (int i = 0; i <= layer_end; i++)
				{
					task_original_start_time[up_list[i].first] = task_map[up_list[i].first].replica_start_time[0].start_time;
					if (task_replica_number[up_list[i].first] > max_replica_num)
						max_replica_num = task_replica_number[up_list[i].first];
				}
				for (int rep_num = max_replica_num - 1; rep_num >= 0; rep_num--)
				{
					for (int i = 0; i <= layer_end; i++)
					{
						if (task_replica_number[up_list[i].first] - 1 < rep_num)
							continue;
						task_start_time new_st = divide_late_process(up_list[i].first, rep_num, f_max);
						task_map[up_list[i].first].optimal_replica_time.insert(task_map[up_list[i].first].optimal_replica_time.begin(), new_st);
					}
				}
				//cout << "aaa" << endl;
				// 当推后任务分配完成后，计算当前层每个任务的f_min的replica数量
				vector<process> pre_optimal_process = optimal_process_list;
				optimal_process_list = temp_optimal_process;
				vector<task_wcet> possible_change_task;
				for (int i = 0; i <= layer_end; i++) //计算每个任务在f_min的replica数量
				{
					int another_replica_num = Calculate_replica_number(up_list[i].first, reliability, f_min);
					//cout << "task id:" << down_list[i].first << "another: " << another_replica_num << "pri:" << task_replica_number[down_list[i].first] << endl;
					if (another_replica_num == -1)
					{
						task_map[up_list[i].first].can_be_fmin = false;
						task_map[up_list[i].first].has_change_replica = false;
						string now_task_id = up_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else if (another_replica_num > task_replica_number[up_list[i].first])
					{
						task_map[up_list[i].first].can_be_fmin = true;
						task_map[up_list[i].first].has_change_replica = true;
						task_wcet new_tw;
						new_tw.id_num = i;
						new_tw.wcet = task_map[up_list[i].first].wcet;
						possible_change_task.push_back(new_tw);
						string now_task_id = up_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[up_list[i].first].can_be_fmin = true;
						task_map[up_list[i].first].has_change_replica = false;
					}
				}

				sort(possible_change_task.begin(), possible_change_task.end(), cmp_tw);

				set<int> add_replica_task;
				//cout << "ccc" << endl;
				for (int i = 0; i < possible_change_task.size(); i++)
				{
					set<int> temp_add_replica = add_replica_task;
					temp_add_replica.insert(possible_change_task[i].id_num);
					optimal_process_list = temp_optimal_process;
					if (layer_late_process_distribution(up_list, layer_end, temp_add_replica))
					{
						add_replica_task = temp_add_replica;
					}
				}
				//cout << "ddd" << endl;
				if (add_replica_task.empty())
				{
					optimal_process_list = pre_optimal_process;
					for (int i = 0; i <= layer_end; i++)
					{
						task_map[up_list[i].first].late_replica_time.clear();
					}

				}
				else
				{
					optimal_process_list = temp_optimal_process;
					layer_late_process_distribution(up_list, layer_end, add_replica_task);
					for (int i = 0; i <= layer_end; i++)
					{
						task_map[up_list[i].first].optimal_replica_time = task_map[up_list[i].first].late_replica_time;
						task_map[up_list[i].first].late_replica_time.clear();
					}
				}



				for (int j = 0; j < possible_change_task.size(); j++)
				{
					if (add_replica_task.find(possible_change_task[j].id_num) == add_replica_task.end())
					{
						task_map[up_list[possible_change_task[j].id_num].first].can_be_fmin = false;
						task_map[up_list[possible_change_task[j].id_num].first].has_change_replica = false;
					}
					else
					{
						task_replica_number[up_list[possible_change_task[j].id_num].first]++;
						//add_additional_replica_number++;
					}
				}
			}  //当前层为顺序层
			else
			{
				double max_replica_num = -1.00;
				for (int i = 0; i <= layer_end; i++)
				{
					task_original_start_time[up_list[i].first] = task_map[up_list[i].first].replica_start_time[0].start_time;
					if (task_replica_number[up_list[i].first] > max_replica_num)
						max_replica_num = task_replica_number[up_list[i].first];
				}
				for (int i = 0; i < layer_end; i++)
				{
					for (int rep_num = task_replica_number[up_list[i].first] - 1; rep_num >= 0; rep_num--)
					{
						task_start_time new_st = divide_late_process(up_list[i].first, rep_num, f_max);
						task_map[up_list[i].first].optimal_replica_time.insert(task_map[up_list[i].first].optimal_replica_time.begin(), new_st);
					}
				}

			
			}
			
			//cout << "bbb" << endl;
			up_list.erase(up_list.begin(), up_list.begin() + layer_end + 1);
		}

		process_list = optimal_process_list;
		map<string, task>::iterator tm_it = task_map.begin();
		while (tm_it != task_map.end())
		{
			tm_it->second.replica_start_time = tm_it->second.optimal_replica_time;
			tm_it->second.optimal_replica_time.clear();
			tm_it++;
		}
		
	}


	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}

	map<string, task>::iterator tm_it = task_map.begin();
	while (tm_it != task_map.end())
	{
		tm_it->second.replica_start_time.clear();
		tm_it++;
	}

	vector<pair<string, double>> down_list = downward_task_list;

	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			int now_replica_num = task_replica_number[down_list[i].first];
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return part_optimal_heft(down_list);
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	
	
	
	


	return true;
}

bool EFR_Schedule::best_scheduling()
{
	partial_scheduling();
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		if (!task_map[down_list[0].first].is_in_layer) //说明当前层是顺序层
		{
			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}
		}
		else //当前层是layer-by-layer层
		{
			process_list = temp_process_list;
			vector<task_wcet> possible_change_task;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_min的replica数量
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				//cout << "task id:" << down_list[i].first << "another: " << another_replica_num << "pri:" << task_replica_number[down_list[i].first] << endl;
				if (another_replica_num == -1)
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else if (another_replica_num > task_replica_number[down_list[i].first])
				{
					//can_add_additional++;
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_wcet new_tw;
					new_tw.id_num = i;
					new_tw.wcet = task_map[down_list[i].first].wcet;
					possible_change_task.push_back(new_tw);
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}

			sort(possible_change_task.begin(), possible_change_task.end(), cmp_tw);

			set<int> add_replica_task;

			for (int i = 0; i < possible_change_task.size(); i++)
			{
				set<int> temp_add_replica = add_replica_task;
				temp_add_replica.insert(possible_change_task[i].id_num);
				process_list = temp_process_list;
				if (layer_best_process_distribution(down_list, layer_end, temp_add_replica))
				{
					add_replica_task = temp_add_replica;
				}
			}

			process_list = temp_process_list;
			layer_process_distribution(down_list, layer_end, add_replica_task);
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time = task_map[down_list[i].first].optimal_replica_time;
				task_map[down_list[i].first].optimal_replica_time.clear();
			}

			for (int j = 0; j < possible_change_task.size(); j++)
			{
				if (add_replica_task.find(possible_change_task[j].id_num) == add_replica_task.end())
				{
					task_map[down_list[possible_change_task[j].id_num].first].can_be_fmin = false;
					task_map[down_list[possible_change_task[j].id_num].first].has_change_replica = false;
				}
				else
				{
					task_replica_number[down_list[possible_change_task[j].id_num].first]++;
					add_additional_replica_number++;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}
	return true;
}

void EFR_Schedule::optimization()
{
	vector<pair<string, double>> up_list = downward_task_list;
	reverse(up_list.begin(), up_list.end());
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	vector<pair<string, double>> temp_up_list = up_list;
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		up_list = temp_up_list;
		while (!up_list.empty())
		{
			int layer_end = 0;
			while (layer_end < up_list.size())  //计算同层任务数
			{
				if (task_map[up_list[0].first].layer != task_map[up_list[layer_end].first].layer)
				{
					break;
				}
				layer_end++;
			}
			layer_end--;
			
			double max_replica_num = -1.00;
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[up_list[i].first] > max_replica_num)
					max_replica_num = task_replica_number[up_list[i].first];
			}
			//cout << "bbb" << endl;
			if (task_map[up_list[0].first].is_in_layer)
			{
				//cout << "in layer" << endl;
				for (int rep_num = max_replica_num - 1; rep_num >= 0; rep_num--)
				{
					for (int i = 0; i <= layer_end; i++)
					{
						if (task_replica_number[up_list[i].first] - 1 < rep_num)
							continue;

						string now_task_id = up_list[i].first;
						task_start_time now_st = task_map[now_task_id].replica_start_time[rep_num];
						double late_end_time = -1.00;
						double Et_max = -1.00;
						for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
						{
							string suc_task = task_map[now_task_id].successors_node[j];
							double possible_end_time = task_map[suc_task].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task];
							if (late_end_time == -1.00 || possible_end_time < late_end_time)
								late_end_time = possible_end_time;
						}


						if (late_end_time == -1.00)
						{
							Et_max = task_map[now_task_id].deadline;
						}
						else
						{
							Et_max = min(late_end_time, task_map[now_task_id].deadline);
						}


						if (optimal_process_list[now_st.process_id].next_start_time == -1.00)
						{
							optimal_process_list[now_st.process_id].next_start_time = Et_max - task_map[now_task_id].wcet;
						}
						else
						{
							Et_max = min(Et_max, optimal_process_list[now_st.process_id].next_start_time);
						}


						int rep_max = task_map[now_task_id].optimal_replica_time.size() - 1;
						if (rep_max >= 0)
							Et_max = min(Et_max, task_map[now_task_id].optimal_replica_time[0].start_time);

						//cout << "111" << endl;
						task_start_time new_st;
						if (rep_num != 0 || (rep_num == 0 && task_map[now_task_id].has_c) )
						{
							if (rep_num == 0 && task_map[now_task_id].has_c)
							{
								task_map[now_task_id].has_c = false;
								has_changed = true;
							}

							if (rep_num == 0)
							{
								new_st.process_id = now_st.process_id;
								new_st.f = now_st.f;
								if (now_st.finish_time < Et_max)
								{
									new_st.start_time = Et_max - ( now_st.finish_time - now_st.start_time );
									new_st.finish_time = Et_max;
								}
								else
								{
									new_st.start_time = now_st.start_time;
									new_st.finish_time = now_st.finish_time;
								}
								/*else
								{
									int j = 0;
									for (j = 0; j < process_list[0].frequency.size(); j++)
									{
										if (new_st.start_time + task_map[now_task_id].wcet / process_list[0].frequency[j] > Et_max)
											break;
									}
									if (j > 0)
										j--;
									new_st.f = process_list[0].frequency[j];
									new_st.start_time = now_st.start_time;
									//cout << "aaa" << endl;
									if (new_st.f >= task_map[now_task_id].min_frequncy)
									{
										//cout << "bbb" << endl;
										//cout << "replica number: " << task_map[now_task_id].replica_start_time.size() << " " << "optimal replica: " << task_map[now_task_id].optimal_replica_time.size() << endl;
										task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[0];
										int delete_process_id = need_delete_st.process_id;
										double delete_time = need_delete_st.start_time;
										for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
										{
											if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
											{
												optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
												break;
											}
										}
										task_map[now_task_id].has_change_replica = false;
										task_map[now_task_id].can_be_fmin = false;
										task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin());
										task_replica_number[now_task_id]--;
										has_changed = true;
									}
									//cout << "ccc" << endl;
								}*/
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
								process_task new_pt;
								new_pt.task_id = now_task_id;
								new_pt.start_time = new_st.start_time;
								new_pt.task_state = rep_num;
								new_pt.f = now_st.f;
								new_pt.finish_time = new_st.finish_time;
								optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							}
							else
							{
								//cout << "in secondary" << endl;
								//task_start_time new_st;
								new_st.process_id = now_st.process_id;
								new_st.f = now_st.f;
								if (now_st.finish_time < Et_max)
								{
									new_st.start_time = Et_max - (now_st.finish_time - now_st.start_time);
									new_st.finish_time = Et_max;
									//has_changed = true;
								}
								else
								{
									new_st.start_time = now_st.start_time;
									new_st.finish_time = now_st.finish_time;
								}
								/*if (task_map[now_task_id].optimal_replica_time.empty())
								{
									task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								}
								else
								{
									new_st.start_time = min(new_st.start_time, task_map[now_task_id].optimal_replica_time[0].start_time);
									task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								}*/
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
								process_task new_pt;
								new_pt.task_id = now_task_id;
								new_pt.start_time = new_st.start_time;
								new_pt.task_state = rep_num;
								new_pt.f = now_st.f;
								new_pt.finish_time = new_st.finish_time;
								optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							}				
							
						}
						else //对于primary replica采取先减少频率，再往后移动的方案，并且没有考虑因为频率减少而可能增加的replica.
						{
							//cout << "in primary" << endl;
							//cout << "222" << endl;
							//task_start_time new_st;
							new_st.process_id = now_st.process_id;
							if (now_st.finish_time < Et_max)
							{
								//cout << "in a" << endl;
								//has_changed = true;
								bool has_find = false;
								int f_i = 0;
								double wf_before = now_st.finish_time - now_st.start_time;
								double wf = now_st.finish_time - now_st.start_time;
								if (task_map[now_task_id].can_be_fmin)
								{
									for (f_i = 0; f_i < process_list[new_st.process_id].frequency.size(); f_i++)
									{
										wf_before = wf;
										wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
										if (wf < 0)
											cout << "in dynamic run: " << process_list[0].frequency[f_i] << endl;
										if (now_st.start_time + wf > Et_max)
										{
											break;
										}
									}
									f_i--;
									if (f_i == process_list[0].frequency.size() - 1)
										wf_before = wf;
								}
								else
								{
									for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
									{
										wf_before = wf;
										wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
										if (wf < 0)
											cout << "in dynamic run: " << process_list[0].frequency[f_i] << endl;
										if (now_st.start_time + wf > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].min_frequncy_num)
										f_i--;
									if (f_i == task_map[now_task_id].min_frequncy_num)
										wf_before = wf;
								}

								new_st.f = process_list[new_st.process_id].frequency[f_i];
								new_st.start_time = Et_max - wf_before;
								new_st.finish_time = Et_max;
								//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
							}
							else
							{
								//cout << "in b" << endl;
								new_st.start_time = now_st.start_time;
								new_st.finish_time = now_st.finish_time;
								new_st.f = now_st.f;
							}
							//cout << "333" << endl;
							if (new_st.f > now_st.f)
							{
								new_st.f = now_st.f;
								new_st.start_time = now_st.start_time;
								new_st.finish_time = now_st.finish_time;
								new_st.process_id = now_st.process_id;
							}
								
							if (new_st.f < now_st.f)
							{
								has_changed = true;
								//cout << now_task_id << " " << "new st: " << new_st.f << "now st: " << now_st.f << endl;
							}
								
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = new_st.f;
							new_pt.finish_time = new_st.finish_time;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							//cout << "444" << endl;

							if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
							{
								add_additional_replica_number--;
								task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
								int delete_process_id = need_delete_st.process_id;
								double delete_time = need_delete_st.start_time;
								for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
								{
									if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
									{
										optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
										break;
									}
								}
								task_map[now_task_id].has_change_replica = false;
								task_map[now_task_id].can_be_fmin = false;
								task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
								task_replica_number[now_task_id]--;
								has_changed = true;
								//cout << "888" << endl;
							}

						}


					}
				}
			}
			else
			{
				//cout << "in not layer" << endl;
				for (int i = 0; i <= layer_end; i++)
				{
					for (int rep_num = task_replica_number[up_list[i].first] - 1; rep_num >= 0; rep_num--)
					{
						if (task_replica_number[up_list[i].first] - 1 < rep_num)
							continue;

						string now_task_id = up_list[i].first;
						task_start_time now_st = task_map[now_task_id].replica_start_time[rep_num];
						double late_end_time = -1.00;
						double Et_max = -1.00;
						for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
						{
							string suc_task = task_map[now_task_id].successors_node[j];
							double possible_end_time = task_map[suc_task].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task];
							if (late_end_time == -1.00 || possible_end_time < late_end_time)
								late_end_time = possible_end_time;
						}


						if (late_end_time == -1.00)
						{
							Et_max = task_map[now_task_id].deadline;
						}
						else
						{
							Et_max = min(late_end_time, task_map[now_task_id].deadline);
						}


						if (optimal_process_list[now_st.process_id].next_start_time == -1.00)
						{
							optimal_process_list[now_st.process_id].next_start_time = Et_max - task_map[now_task_id].wcet;
						}
						else
						{
							Et_max = min(Et_max, optimal_process_list[now_st.process_id].next_start_time);
						}


						int rep_max = task_map[now_task_id].optimal_replica_time.size() - 1;
						if (rep_max >= 0)
							Et_max = min(Et_max, task_map[now_task_id].optimal_replica_time[0].start_time);

						//cout << "111" << endl;
						task_start_time new_st;
						if (rep_num != 0 || (rep_num == 0 && task_map[now_task_id].has_c))
						{
							if (rep_num == 0 && task_map[now_task_id].has_c)
							{
								task_map[now_task_id].has_c = false;
								has_changed = true;
							}

							if (rep_num == 0)
							{
								new_st.process_id = now_st.process_id;
								new_st.f = now_st.f;
								if (now_st.finish_time < Et_max)
								{
									new_st.start_time = Et_max - ( now_st.finish_time - now_st.start_time );
									new_st.finish_time = Et_max;
								}
								else
								{
									new_st.start_time = now_st.start_time;
									new_st.finish_time = now_st.finish_time;
								}
								/*else
								{
									int j = 0;
									for (j = 0; j < process_list[0].frequency.size(); j++)
									{
										if (new_st.start_time + task_map[now_task_id].wcet / process_list[0].frequency[j] > Et_max)
											break;
									}
									if (j > 0)
										j--;
									new_st.f = process_list[0].frequency[j];
									new_st.start_time = now_st.start_time;
									if (new_st.f >= task_map[now_task_id].min_frequncy)
									{
										task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[0];
										int delete_process_id = need_delete_st.process_id;
										double delete_time = need_delete_st.start_time;
										for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
										{
											if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
											{
												optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
												break;
											}
										}
										task_map[now_task_id].has_change_replica = false;
										task_map[now_task_id].can_be_fmin = false;
										task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin());
										task_replica_number[now_task_id]--;
										has_changed = true;
									}
								}*/
								
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
								process_task new_pt;
								new_pt.task_id = now_task_id;
								new_pt.start_time = new_st.start_time;
								new_pt.task_state = rep_num;
								new_pt.f = now_st.f;
								new_pt.finish_time = new_st.finish_time;
								optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							}
							else
							{
								new_st.process_id = now_st.process_id;
								new_st.f = now_st.f;
								if (now_st.finish_time < Et_max)
								{
									new_st.start_time = Et_max - ( now_st.finish_time - now_st.start_time ) ;
									new_st.finish_time = Et_max;
									//has_changed = true;
								}
								else
								{
									new_st.start_time = now_st.start_time;
									new_st.finish_time = now_st.finish_time;
								}
									
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
								optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
								process_task new_pt;
								new_pt.task_id = now_task_id;
								new_pt.start_time = new_st.start_time;
								new_pt.task_state = rep_num;
								new_pt.f = now_st.f;
								new_pt.finish_time = new_st.finish_time;
								optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							}				
							
						}
						else //对于primary replica采取先减少频率，再往后移动的方案，并且没有考虑因为频率减少而可能增加的replica.
						{
							//cout << "222" << endl;
							new_st.process_id = now_st.process_id;
							if (now_st.finish_time < Et_max)
							{
								//has_changed = true;
								bool has_find = false;
								int f_i = 0;
								double wf_before = now_st.finish_time - now_st.start_time;
								double wf = now_st.finish_time - now_st.start_time;
								if (task_map[now_task_id].can_be_fmin)
								{			
									for (f_i = 0; f_i < process_list[new_st.process_id].frequency.size(); f_i++)
									{
										wf_before = wf;
										wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
										if (wf < 0)
											cout << "in dynamic run: " << process_list[0].frequency[f_i] << endl;
										if (now_st.start_time + wf > Et_max)
										{
											break;
										}
									}
									f_i--;
									if (f_i == process_list[0].frequency.size() - 1)
										wf_before = wf;
								}
								else
								{
									for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
									{
										wf_before = wf;
										wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
										if (now_st.start_time + wf > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].min_frequncy_num)
										f_i--;
									if (f_i == task_map[now_task_id].min_frequncy_num)
										wf_before = wf;
								}
								new_st.f = process_list[new_st.process_id].frequency[f_i];
								new_st.start_time = Et_max - wf_before;
								new_st.finish_time = Et_max;
								//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
							}
							else
							{
								new_st.f = now_st.f;
								new_st.start_time = now_st.start_time;
								new_st.finish_time = now_st.finish_time;

							}
							//cout << "333" << endl;
							if (new_st.f > now_st.f)
							{
								new_st.f = now_st.f;
								new_st.start_time = now_st.start_time;
								new_st.process_id = now_st.process_id;
								new_st.finish_time = now_st.finish_time;
							}
							if (new_st.f < now_st.f)
							{
								has_changed = true;
								//cout << now_task_id << " " << "new st: " << new_st.f << "now st: " << now_st.f << endl;
							}
								
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = new_st.f;
							new_pt.finish_time = new_st.finish_time;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							//cout << "444" << endl;

							if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
							{
								add_additional_replica_number--;
								//cout << "555" << endl;
								task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
								//cout << "666" << endl;
								int delete_process_id = need_delete_st.process_id;
								double delete_time = need_delete_st.start_time;
								for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
								{
									if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
									{
										//cout << "7777777" << endl;
										optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
										break;
									}
								}
								task_map[now_task_id].has_change_replica = false;
								task_map[now_task_id].can_be_fmin = false;
								task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
								task_replica_number[now_task_id]--;
								has_changed = true;
							}

						}
					}
				}
			}

			//cout << "aaa" << endl;
			
			up_list.erase(up_list.begin(), up_list.begin() + layer_end + 1);


		}
		//cout << "aaa" << endl;
		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			if (t_it->first == "fasterq-dump_00000220")
			{
				cout << t_it->second.replica_start_time[0].f << " " << t_it->second.optimal_replica_time[0].f << endl;
			}
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}
		if (has_changed)
		{
			//cout << "hhhhhhhhhhhhhhhh" << endl;
			double min_time = -1.00;
			for (int i = 0; i < process_list.size(); i++)
			{
				if (process_list[i].pt.empty())
					continue;
				if (min_time == -1.00 || process_list[i].pt[0].start_time < min_time)
					min_time = process_list[i].pt[0].start_time;
			}

			for (int i = 0; i < process_list.size(); i++)
			{
				for (int j = 0; j < process_list[i].pt.size(); j++)
				{
					process_list[i].pt[j].start_time -= min_time;
					process_list[i].pt[j].finish_time -= min_time;
					process_task now_pt = process_list[i].pt[j];
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].start_time -= min_time;
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].finish_time -= min_time;
				}
			}
		}
		//cout << "bbb" << endl;
		/*if (has_changed)
		{
			for (int i = 0; i < process_list.size(); i++)
			{
				process_list[i].pt.clear();
				process_list[i].ready_time = 0.00;
				process_list[i].next_start_time = -1.00;
			}
			vector<pair<string, double>> down_list = downward_task_list;
			while (!down_list.empty())
			{
				vector<process> temp_process_list = process_list;
				int layer_end = 0;
				bool find_next_layer = false;
				//cout << "down list num: " << down_list.size() << endl;
				//cout << "aaa" << endl;
				while (layer_end < down_list.size())  //计算同层任务数
				{
					if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
					{
						find_next_layer = true;
						break;
					}
					layer_end++;
				}
				//cout << "lay num:" << layer_end << endl;
				layer_end--;
				if (layer_end == down_list.size())
					layer_end--;
				int max_replica_num = -1;
				for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
				{
					task_map[down_list[i].first].replica_start_time.clear();
					task_map[down_list[i].first].is_in_layer = true;
					int now_replica_num = task_replica_number[down_list[i].first];
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].optimal_replica_time[0].f);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
					if (max_replica_num < now_replica_num)
						max_replica_num = now_replica_num;
				}
				//cout << "max replica :" << max_replica_num << endl;
				for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
				{
					for (int i = 0; i <= layer_end; i++)
					{
						if (task_replica_number[down_list[i].first] - 1 < rep_num)
							continue;
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}

				bool exceed_deadline = false;
				//cout << "aaa" << endl;
				for (int i = 0; i <= layer_end; i++)
				{
					//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
					//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						exceed_deadline = true;
						break;
					}
				}
				//cout << "bbb " << exceed_deadline << endl;
				if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
				{

					bool exceed_second_deadline = false;
					process_list = temp_process_list;
					for (int i = 0; i <= layer_end; i++)
					{
						task_map[down_list[i].first].replica_start_time.clear();
						task_map[down_list[i].first].is_in_layer = false;
					}
					for (int i = 0; i <= layer_end; i++)
					{
						for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
						{
							if (j == 0)
							{
								task_start_time now_st = divide_process(down_list[i].first, j, task_map[down_list[i].first].optimal_replica_time[0].f);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}					
						}

						double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
						now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
						if (now_end_time > task_map[down_list[i].first].deadline)
						{
							cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
							exceed_second_deadline = true;
							break;
						}
					}

					if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
					{
						cout << "---------------------------chose optimal heft" << endl;
						//return false;
					}

				}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

				down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
			}

		}*/
	}

	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time = t_it->second.replica_start_time;
		t_it++;
	}
	for (int i = 0; i < process_list.size(); i++)
	{
		sort(process_list[i].pt.begin(), process_list[i].pt.end(), cmp_pt);
	}

	//process_list = optimal_process_list;

}

void EFR_Schedule::another_optimization()
{
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		vector<process> run_process_list = process_list;
		vector<process_task> need_improved_task;
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
				continue;
			reverse(run_process_list[i].pt.begin(), run_process_list[i].pt.end());
			for (int j = 0; j < run_process_list[i].pt.size(); j++)
			{
				run_process_list[i].pt[j].p_id = i;
			}		
		}
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
			{
				continue;
			}
			else
			{
				need_improved_task.push_back(run_process_list[i].pt[0]);
			}
			
		}
		sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);
		

		while (!need_improved_task.empty())
		{
			sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);
			
			for (int i = 1; i < need_improved_task.size(); i++)
			{
				if (need_improved_task[0].task_id == need_improved_task[i].task_id && need_improved_task[0].task_state < need_improved_task[i].task_state)
				{
					process_task temp_pt = need_improved_task[0];
					need_improved_task[0] = need_improved_task[i];
					need_improved_task[i] = temp_pt;
				}
			}
			//cout << "aaa" << endl;
			process_task now_pt = need_improved_task[0];
			string now_task_id = now_pt.task_id;
			int rep_num = now_pt.task_state;
			double Et_max = -1.00;
			double late_end_time = -1.00;
			for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
			{
				string suc_task_id = task_map[now_task_id].successors_node[j];
				if (late_end_time == -1.00 || late_end_time > task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id])
					late_end_time = task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id];
			}
			//cout << "ccc" << endl;
			if (late_end_time == -1.00)
				Et_max = task_map[now_task_id].deadline;
			else
				Et_max = min(task_map[now_task_id].deadline, late_end_time);

			//cout << "ddd1 " << optimal_process_list[now_pt.p_id].pt.size() << endl;

			if (optimal_process_list[now_pt.p_id].pt.size() != 0)
			{
				Et_max = min(optimal_process_list[now_pt.p_id].pt[0].start_time, Et_max);
			}

			//cout << "ddd" << endl;

			if (task_map[now_task_id].optimal_replica_time.size() != 0)
			{
				Et_max = min(task_map[now_task_id].optimal_replica_time[0].start_time, Et_max);
			}

			//cout << "bbb" << endl;

			if (rep_num != 0)
			{
				//cout << "bbb1" << endl;
				process_task new_pt;
				new_pt.f = now_pt.f;
				new_pt.p_id = now_pt.p_id;
				new_pt.task_id = now_pt.task_id;
				new_pt.task_state = now_pt.task_state;
				if (now_pt.finish_time < Et_max)
				{
					new_pt.finish_time = Et_max;
					new_pt.start_time = Et_max - (now_pt.finish_time - now_pt.start_time);
				}
				else
				{
					new_pt.finish_time = now_pt.finish_time;
					new_pt.start_time = now_pt.start_time;
				}
				optimal_process_list[new_pt.p_id].pt.insert(optimal_process_list[new_pt.p_id].pt.begin(), new_pt);
				task_start_time new_st;
				new_st.f = new_pt.f;
				new_st.process_id = new_pt.p_id;
				new_st.start_time = new_pt.start_time;
				new_st.finish_time = new_pt.finish_time;
				task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
				//cout << "bbb3" << endl;
			}
			else
			{
				//cout << "bbb2" << endl;
				task_start_time now_st;
				task_start_time new_st;
				now_st.start_time = now_pt.start_time;
				now_st.finish_time = now_pt.finish_time;
				now_st.f = now_pt.f;
				now_st.process_id = now_pt.p_id;

				new_st.process_id = now_st.process_id;

				if (now_st.finish_time < Et_max)
				{
					//has_changed = true;
					bool has_find = false;
					int f_i = 0;
					double wf_before = now_st.finish_time - now_st.start_time;
					double wf = now_st.finish_time - now_st.start_time;
					if (task_map[now_task_id].can_be_fmin)
					{
						for (f_i = 0; f_i < process_list[new_st.process_id].frequency.size(); f_i++)
						{
							wf_before = wf;
							wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
							if (wf < 0)
								cout << "in dynamic run: " << process_list[0].frequency[f_i] << endl;
							if (now_st.start_time + wf > Et_max)
							{
								break;
							}
						}
						f_i--;
						if (f_i == process_list[0].frequency.size() - 1)
							wf_before = wf;
					}
					else
					{
						for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
						{
							wf_before = wf;
							wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
							if (now_st.start_time + wf > Et_max)
							{
								f_i--;
								break;
							}
						}
						if (f_i > task_map[now_task_id].min_frequncy_num)
							f_i--;
						if (f_i == task_map[now_task_id].min_frequncy_num)
							wf_before = wf;
					}
					new_st.f = process_list[new_st.process_id].frequency[f_i];
					new_st.start_time = Et_max - wf_before;
					new_st.finish_time = Et_max;
					//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
				}
				else
				{
					new_st.f = now_st.f;
					new_st.start_time = now_st.start_time;
					new_st.finish_time = now_st.finish_time;
				}

				if (new_st.f < now_st.f)
					has_changed = true;

				task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
				optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
				process_task new_pt;
				new_pt.task_id = now_task_id;
				new_pt.start_time = new_st.start_time;
				new_pt.task_state = rep_num;
				new_pt.f = new_st.f;
				new_pt.finish_time = new_st.finish_time;
				new_pt.p_id = new_st.process_id;
				optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
				//cout << "444" << endl;

				if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
				{
					if (task_map[now_task_id].optimal_replica_time.size() == 1)
					{
						task_map[now_task_id].has_change_replica = false;
						task_map[now_task_id].can_be_fmin = false;
						cout << "error error errorerrorerrorerrorerrorerrorerror" << endl;
					}
					else
					{
						add_additional_replica_number--;
						//cout << "555" << endl;
						task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
						//cout << "666" << endl;
						int delete_process_id = need_delete_st.process_id;
						double delete_time = need_delete_st.start_time;
						//cout << "999" << endl;


						for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
						{
							if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
							{
								//cout << "7777777" << endl;
								optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
								break;
							}
						}
						//cout << "888" << endl;
						task_map[now_task_id].has_change_replica = false;
						task_map[now_task_id].can_be_fmin = false;
						task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
						task_replica_number[now_task_id]--;
						has_changed = true;
					}
				}


			}



			run_process_list[now_pt.p_id].pt.erase(run_process_list[now_pt.p_id].pt.begin());
			if (run_process_list[now_pt.p_id].pt.size() == 0)
			{
				need_improved_task.erase(need_improved_task.begin());
			}
			else
			{
				need_improved_task[0] = run_process_list[now_pt.p_id].pt[0];
			}
		}

		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}
		if (has_changed)
		{
			//cout << "hhhhhhhhhhhhhhhh" << endl;
			double min_time = -1.00;
			for (int i = 0; i < process_list.size(); i++)
			{
				if (process_list[i].pt.empty())
					continue;
				if (min_time == -1.00 || process_list[i].pt[0].start_time < min_time)
					min_time = process_list[i].pt[0].start_time;
			}

			for (int i = 0; i < process_list.size(); i++)
			{
				for (int j = 0; j < process_list[i].pt.size(); j++)
				{
					process_list[i].pt[j].start_time -= min_time;
					process_list[i].pt[j].finish_time -= min_time;
					process_task now_pt = process_list[i].pt[j];
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].start_time -= min_time;
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].finish_time -= min_time;
				}
			}
		}


	}


}

bool EFR_Schedule::Heft_scheduing()
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability,1.0 / task_map.size());
	for (int i = 0; i < down_list.size(); i++)
	{
		task_map[down_list[i].first].replica_start_time.clear();
		if (down_list[i].first == "cycles_fertilizer_increase_output_parser_00000132")
			cout << "aaa" << endl;
		int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << down_list[i].first << endl;
			return false;
		}
		for (int j = 0; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_heft_process(down_list[i].first, j);
			task_map[down_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[down_list[i].first].replica_start_time[now_replica_num - 1].start_time + task_map[down_list[i].first].wcet;
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			cout << "Heft_exceed_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
			return false;
		}
	}
	return true;
}

bool EFR_Schedule::scheduing_optimal_heft()
{
	can_add_additional = 0;
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].ready_time = 0.00;
		process_list[i].next_start_time = -1.00;
		process_list[i].pt.clear();
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < downward_task_list.size(); i++)
	{
		task_map[downward_task_list[i].first].is_in_layer = false;
		opti_fre of = optimal_frequency(downward_task_list[i].first, reliability);
		task_map[downward_task_list[i].first].opt_frequency_num = of.of_num;
		task_map[downward_task_list[i].first].opt_frequency = of.o_f;
		task_map[downward_task_list[i].first].replica_start_time.clear();
		task_map[downward_task_list[i].first].is_in_layer = false;
		int now_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_max);
		task_replica_number[downward_task_list[i].first] = now_replica_num;
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << downward_task_list[i].first << endl;
			return false;
		}
		for (int j = 0; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_process(downward_task_list[i].first, j, f_max);
			task_map[downward_task_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[downward_task_list[i].first].replica_start_time[now_replica_num - 1].start_time + task_map[downward_task_list[i].first].wcet;
		if (now_end_time > task_map[downward_task_list[i].first].deadline)
		{
			cout << "exceed_deadline: " << downward_task_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[downward_task_list[i].first].deadline << endl;
			return false;
		}

		int another_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_min);
		if (another_replica_num != task_replica_number[downward_task_list[i].first])
		{
			task_map[downward_task_list[i].first].can_be_fmin = false;
			task_map[downward_task_list[i].first].has_change_replica = false;
			can_add_additional++;
			string now_task_id = downward_task_list[i].first;
			int j = 0;
			for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
			{
				if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
					break;
			}
			task_map[now_task_id].min_frequncy_num = j;
			task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
		}
		else
		{
			task_map[downward_task_list[i].first].can_be_fmin = true;
			task_map[downward_task_list[i].first].has_change_replica = false;
		}


	}
	return true;
}

bool EFR_Schedule::part_optimal_heft(vector<pair<string, double>> down_list)
{
	can_add_additional = 0;
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].ready_time = 0.00;
		process_list[i].next_start_time = -1.00;
		process_list[i].pt.clear();
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> temp_down_list;
	temp_down_list = down_list;
	down_list.clear();
	for (int i = 0; i < downward_task_list.size() - temp_down_list.size(); i++)
	{
		down_list.push_back(downward_task_list[i]);
	}
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return scheduing_optimal_heft();
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	down_list = temp_down_list;
	



	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose part optimal heft" << endl;
				return scheduing_optimal_heft();
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当分层分配方式成功时，计算f_min时的replica数量，并进行相应分配，以期得到更好的优化结果
		else
		{
			vector<process> pre_process_list = process_list;
			process_list = temp_process_list;
			vector<task_wcet> possible_change_task;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_min的replica数量
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				//cout << "task id:" << down_list[i].first << "another: " << another_replica_num << "pri:" << task_replica_number[down_list[i].first] << endl;
				if (another_replica_num == -1)
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else if (another_replica_num > task_replica_number[down_list[i].first])
				{
					can_add_additional++;
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_wcet new_tw;
					new_tw.id_num = i;
					new_tw.wcet = task_map[down_list[i].first].wcet;
					possible_change_task.push_back(new_tw);
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}

			sort(possible_change_task.begin(), possible_change_task.end(), cmp_tw);

			set<int> add_replica_task;

			for (int i = 0; i < possible_change_task.size(); i++)
			{
				set<int> temp_add_replica = add_replica_task;
				temp_add_replica.insert(i);
				process_list = temp_process_list;
				if (layer_process_distribution(down_list, layer_end, temp_add_replica))
				{
					add_replica_task = temp_add_replica;
				}
			}



			if (add_replica_task.empty())
			{
				process_list = pre_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].optimal_replica_time.clear();
				}

			}
			else
			{
				process_list = temp_process_list;
				layer_process_distribution(down_list, layer_end, add_replica_task);
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time = task_map[down_list[i].first].optimal_replica_time;
					task_map[down_list[i].first].optimal_replica_time.clear();
				}
			}

			for (int j = 0; j < possible_change_task.size(); j++)
			{
				if (add_replica_task.find(possible_change_task[j].id_num) == add_replica_task.end())
				{
					task_map[down_list[possible_change_task[j].id_num].first].can_be_fmin = false;
					task_map[down_list[possible_change_task[j].id_num].first].has_change_replica = false;
				}
				else
				{
					task_replica_number[down_list[possible_change_task[j].id_num].first]++;
					add_additional_replica_number++;
				}
			}


		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}
	return true;
	
}

bool EFR_Schedule::partial_scheduling()
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			if(layer_end == 0)
				task_map[down_list[i].first].is_in_layer = false;
			else
				task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return scheduing_optimal_heft();
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	return true;
}

bool EFR_Schedule::add_scheduling()
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		layer_record lr;
		lr.process_list = process_list;
		lr.down_list = down_list;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			opti_fre of = optimal_frequency(down_list[i].first, reliability);
			task_map[down_list[i].first].opt_frequency_num = of.of_num;
			task_map[down_list[i].first].opt_frequency = of.o_f;
			lr.layer_wcet += task_map[down_list[i].first].wcet;
			task_map[down_list[i].first].is_in_layer = true;
			task_map[down_list[i].first].replica_start_time.clear();
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		v_lr.push_back(lr);
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{
			
			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "add scheduling false" << endl;
				return scheduing_optimal_heft();
				//return false;
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	return true;
}

bool EFR_Schedule::scheduling_add_heft()
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].ready_time = 0.00;
		process_list[i].next_start_time = -1.00;
		process_list[i].pt.clear();
	}
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	v_lr.clear();
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		layer_record lr;
		lr.process_list = process_list;
		lr.down_list = down_list;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量
		{
			lr.layer_wcet += task_map[down_list[i].first].wcet;
			task_map[down_list[i].first].replica_start_time.clear();
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
		}
		v_lr.push_back(lr);
		bool exceed_deadline = false;
		for (int i = 0; i <= layer_end; i++)
		{
			for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
			{
				task_start_time now_st = divide_process(down_list[i].first, j, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}

			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
				exceed_deadline = true;
				break;
			}
		}


		if (exceed_deadline == true)
		{
			cout << "add heft scheduling false" << endl;
			return false;
		}
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					can_add_additional++;
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}
		
		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	return true;
}

bool EFR_Schedule::choose_layer()
{
	while(v_lr.size() > 0)
	{	
		sort(v_lr.begin(), v_lr.end(), cmp_lr);
		vector<layer_record> temp_v_lr = v_lr;
		if(add_optimization(v_lr[0]))
		{
			continue;
		}
		else
		{
			v_lr = temp_v_lr;
			v_lr.erase(v_lr.begin());
		}
	}

	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].optimal_replica_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			if (task_map[down_list[i].first].has_change_replica)
				task_replica_number[down_list[i].first] = Calculate_replica_number(down_list[i].first, reliability, f_min);
			else
				task_replica_number[down_list[i].first] = Calculate_replica_number(down_list[i].first, reliability, f_max);
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_map[down_list[i].first].has_c = true;
				//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size()-2]);
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
				//task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					//task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_map[down_list[i].first].has_c = true;
						//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
						task_start_time now_st = divide_process(down_list[i].first, j, f_max);
						//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
						//task_start_time now_st = divide_process(down_list[i].first, j, task_map[down_list[i].first].opt_frequency);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							//task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				scheduing_optimal_heft();
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}



	return true;
}

bool EFR_Schedule::add_optimization(layer_record lr_max)
{
	v_lr.clear();
	vector<process> temp_process = process_list;
	process_list = lr_max.process_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = lr_max.down_list;
	
	int layer_end = 0;
	bool find_next_layer = false;
	while (layer_end < down_list.size())  //计算同层任务数
	{
		if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
		{
			find_next_layer = true;
			break;
		}
		layer_end++;
	}
	layer_end--;
	if (layer_end == down_list.size())
		layer_end--;
	int max_replica_num = -1;
	for (int i = 0; i <= layer_end; i++) //计算每个任务在f_min的replica数量，并分配primary replica
	{
		task_map[down_list[i].first].replica_start_time.clear();
		int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << down_list[i].first << endl;
			return false;
		}
		task_replica_number[down_list[i].first] = now_replica_num;
		task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
		task_map[down_list[i].first].replica_start_time.push_back(now_st);
		if (max_replica_num < now_replica_num)
			max_replica_num = now_replica_num;
		if (down_list[i].first == "individuals_00000130")
		{
			cout << "aaaaaaaa: " << task_replica_number[down_list[i].first] << endl;
		}
	}
	for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
	{
		for (int i = 0; i <= layer_end; i++)
		{
			if (task_replica_number[down_list[i].first] - 1 < rep_num)
				continue;
			
			task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
		}
	}
	bool exceed_deadline = false;
	for (int i = 0; i <= layer_end; i++)
	{
		double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			exceed_deadline = true;
			break;
		}
	}

	if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
	{
		return false;
	}
	else //当分层分配成功时，判定每个任务是否change replica
	{
		for (int i = 0; i <= layer_end; i++)
		{
			int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (another_replica_num != task_replica_number[down_list[i].first])
			{
				task_map[down_list[i].first].can_be_fmin = true;
				task_map[down_list[i].first].has_change_replica = true;
				string now_task_id = down_list[i].first;
				int j = 0;
				for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
				{
					if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == another_replica_num)
						break;
				}
				task_map[now_task_id].min_frequncy_num = j;
				task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
			}
			else
			{
				task_map[down_list[i].first].can_be_fmin = true;
				task_map[down_list[i].first].has_change_replica = false;
			}
		}
		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}

	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		layer_record lr;
		lr.process_list = process_list;
		lr.down_list = down_list;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			lr.layer_wcet += task_map[down_list[i].first].wcet;
			task_map[down_list[i].first].replica_start_time.clear();
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		v_lr.push_back(lr);
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		for (int i = 0; i <= layer_end; i++)
		{
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					task_start_time now_st = divide_process(down_list[i].first, j, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "add optimal false" << endl;
				return false;
			}
			else                        //顺序分配方式成功时，判定每个任务是否可以等于f_min
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}



	return true;
}


bool EFR_Schedule::choose_all_layer()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	sort(v_lr.begin(), v_lr.end(), cmp_lr);
	for (int i = 0; i < v_lr.size(); i++)
	{
		if (!add_new_optimization(v_lr[i]))
		{
			vector<pair<string, double>> down_list = v_lr[i].down_list;
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			for (int j = 0; j <= layer_end; j++)
			{
				task_replica_number[down_list[j].first] = Calculate_replica_number(down_list[j].first, reliability, f_max);
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}
				
		}
	}

	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_map[down_list[i].first].has_c = true;
				//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size()-2]);
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
				//task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					//task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_map[down_list[i].first].has_c = true;
						//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
						task_start_time now_st = divide_process(down_list[i].first, j, f_max);
						//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
						//task_start_time now_st = divide_process(down_list[i].first, j, task_map[down_list[i].first].opt_frequency);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							//task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}
	

	return true;
}

bool EFR_Schedule::add_new_optimization(layer_record lr_max)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		if (down_list[0].first == lr_max.down_list[0].first)
		{
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_opt的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				if (now_replica_num != Calculate_replica_number(down_list[i].first, reliability, f_max))
				{
					//int min_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_replica_number[down_list[i].first] = now_replica_num;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == Calculate_replica_number(now_task_id, reliability,  f_max))
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
					//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[now_task_id].min_frequncy_num - 1]);
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
					if (task_map[down_list[i].first].opt_frequency < 0)
						cout << "opt error !!!!" << endl;
					task_map[down_list[i].first].replica_start_time.push_back(now_st);

				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
					task_replica_number[down_list[i].first] = now_replica_num;
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						//task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}					
				}
			}
			bool exceed_deadline = false;
			for (int i = 0; i <= layer_end; i++)
			{
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
			{
				return false;
			}
			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
		else
		{
			vector<process> temp_process_list = process_list;
			int layer_end = 0;
			bool find_next_layer = false;
			//cout << "down list num: " << down_list.size() << endl;
			//cout << "aaa" << endl;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			//cout << "lay num:" << layer_end << endl;
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = task_replica_number[down_list[i].first];
				if (task_map[down_list[i].first].has_change_replica)
				{
					//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
					//task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}				
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			//cout << "max replica :" << max_replica_num << endl;
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						//task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}

			bool exceed_deadline = false;
			//cout << "aaa" << endl;
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}
			//cout << "bbb " << exceed_deadline << endl;
			if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
			{

				bool exceed_second_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						if (j == 0 && task_map[down_list[i].first].has_change_replica)
						{
							//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
							//task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
							task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							if (task_map[down_list[i].first].has_change_replica)
							{
								//task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
						}
						
					}
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_second_deadline = true;
						break;
					}
				}

				if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return false;
				}

			}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
	}
	return true;
}

bool EFR_Schedule::add_modify_optimization(layer_record lr_max)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		if (down_list[0].first == lr_max.down_list[0].first)
		{
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_opt的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				if (now_replica_num != Calculate_replica_number(down_list[i].first, reliability, f_max))
				{
					//int min_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_replica_number[down_list[i].first] = now_replica_num;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == Calculate_replica_number(now_task_id, reliability, f_max))
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
					//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[now_task_id].min_frequncy_num - 1]);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);

				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
					task_replica_number[down_list[i].first] = now_replica_num;
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}
			bool exceed_deadline = false;
			for (int i = 0; i <= layer_end; i++)
			{
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
			{
				return false;
			}
			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
		else
		{
			vector<process> temp_process_list = process_list;
			int layer_end = 0;
			if (task_map[down_list[0].first].is_in_layer) //对该层使用layer-by-layer方法
			{
				bool find_next_layer = false;
				//cout << "down list num: " << down_list.size() << endl;
				//cout << "aaa" << endl;
				while (layer_end < down_list.size())  //计算同层任务数
				{
					if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
					{
						find_next_layer = true;
						break;
					}
					layer_end++;
				}
				//cout << "lay num:" << layer_end << endl;
				layer_end--;
				if (layer_end == down_list.size())
					layer_end--;
				int max_replica_num = -1;
				for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
				{
					task_map[down_list[i].first].replica_start_time.clear();
					int now_replica_num = task_replica_number[down_list[i].first];
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
						//task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
						//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					if (max_replica_num < now_replica_num)
						max_replica_num = now_replica_num;
				}
				//cout << "max replica :" << max_replica_num << endl;
				for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
				{
					for (int i = 0; i <= layer_end; i++)
					{
						if (task_replica_number[down_list[i].first] - 1 < rep_num)
							continue;
						if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				bool exceed_deadline = false;
				//cout << "aaa" << endl;
				for (int i = 0; i <= layer_end; i++)
				{
					//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
					//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						exceed_deadline = true;
						break;
					}
				}
				if (exceed_deadline)
					return false;
			}
			else  //对该层使用顺序分配
			{ 
				bool exceed_second_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						if (j == 0 && task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
							//task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							//task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							if (task_map[down_list[i].first].has_change_replica)
							{
								task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
						}

					}
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_second_deadline = true;
						break;
					}
				}
				if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return false;
				}
			}

			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
	}
	return true;
}

bool EFR_Schedule::choose_single_task()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	sort(v_lr.begin(), v_lr.end(), cmp_lr);
	map<string, task>::iterator t_it = task_map.begin();
	vector<mission_wcet> vm_w;
	while (t_it != task_map.end())
	{
		mission_wcet mw;
		mw.task_id = t_it->first;
		mw.wcet = t_it->second.wcet;
		vm_w.push_back(mw);
		t_it++;
	}
	
	sort(vm_w.begin(), vm_w.end(), cmp_mw);

	for (int i = 0; i < vm_w.size(); i++)
	{
		if (Calculate_replica_number(vm_w[i].task_id, reliability, f_max) == Calculate_replica_number(vm_w[i].task_id, reliability, f_min))
			continue;
		times++;
		if (!add_single_optimization(vm_w[i].task_id))
		{
			//cout << "aaaaaaaaaaaaaaaaaaaaaaaaaaa" << endl;
			times--;
			task_replica_number[vm_w[i].task_id] = Calculate_replica_number(vm_w[i].task_id, reliability, f_max);
			int another_replica_num = Calculate_replica_number(vm_w[i].task_id, reliability, f_min);
			if (another_replica_num != task_replica_number[vm_w[i].task_id])
			{
				task_map[vm_w[i].task_id].can_be_fmin = false;
				task_map[vm_w[i].task_id].has_change_replica = false;
				string now_task_id = vm_w[i].task_id;
				int j = 0;
				for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
				{
					if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == Calculate_replica_number(now_task_id, reliability, f_max))
						break;
				}
				task_map[now_task_id].min_frequncy_num = j;
				task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
			}
			else
			{
				task_map[vm_w[i].task_id].can_be_fmin = true;
				task_map[vm_w[i].task_id].has_change_replica = false;
			}
		}
	}

	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size()-2]);
				//task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					//task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
						//task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							//task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}



	return true;
}

bool EFR_Schedule::add_single_optimization(string increase_task_id)
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;


			int now_replica_num = task_replica_number[down_list[i].first];
			if (down_list[i].first == increase_task_id)
			{
				task_map[down_list[i].first].can_be_fmin = true;
				task_map[down_list[i].first].has_change_replica = true;
				task_replica_number[down_list[i].first] = Calculate_replica_number(down_list[i].first,reliability,f_min);
				now_replica_num = task_replica_number[down_list[i].first];
				string now_task_id = down_list[i].first;
				int j = 0;
				for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
				{
					if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == Calculate_replica_number(now_task_id, reliability, f_max))
						break;
				}
				task_map[now_task_id].min_frequncy_num = j;
				task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else if (task_map[down_list[i].first].has_change_replica)
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[process_list[0].frequency.size() - 2]);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		
	}

	return true;
}


bool EFR_Schedule::another_choose_all_layer()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	sort(v_lr.begin(), v_lr.end(), cmp_lr);
	for (int i = 0; i < v_lr.size(); i++)
	{
		if (!another_add_new_optimization(v_lr[i]))
		{
			vector<pair<string, double>> down_list = v_lr[i].down_list;
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			for (int j = 0; j <= layer_end; j++)
			{
				task_replica_number[down_list[j].first] = Calculate_replica_number(down_list[j].first, reliability, f_max);
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].opt_frequency);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}
	}
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}

	return true;
}

bool EFR_Schedule::another_add_new_optimization(layer_record lr_max)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		if (down_list[0].first == lr_max.down_list[0].first)
		{
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_opt的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = true;
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].opt_frequency);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				if (now_replica_num != Calculate_replica_number(down_list[i].first, reliability, f_max))
				{
					//int min_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
					if (now_replica_num == 1)
						cout << "!!!!!!!!!!!!!!!!!!!: " << Calculate_replica_number(down_list[i].first, reliability, f_max) << endl;
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_replica_number[down_list[i].first] = now_replica_num;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == Calculate_replica_number(now_task_id, reliability, f_max))
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);

				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
					task_replica_number[down_list[i].first] = now_replica_num;
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}
			bool exceed_deadline = false;
			for (int i = 0; i <= layer_end; i++)
			{
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
			{
				return false;
			}
			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
		else
		{
			vector<process> temp_process_list = process_list;
			int layer_end = 0;
			bool find_next_layer = false;
			//cout << "down list num: " << down_list.size() << endl;
			//cout << "aaa" << endl;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			//cout << "lay num:" << layer_end << endl;
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = true;
				int now_replica_num = task_replica_number[down_list[i].first];
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			//cout << "max replica :" << max_replica_num << endl;
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}

			bool exceed_deadline = false;
			//cout << "aaa" << endl;
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}
			//cout << "bbb " << exceed_deadline << endl;
			if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
			{

				bool exceed_second_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						if (j == 0 && task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].opt_frequency);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							if (task_map[down_list[i].first].has_change_replica)
							{
								task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
						}

					}
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_second_deadline = true;
						break;
					}
				}

				if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return false;
				}

			}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
	}
	return true;
}



bool EFR_Schedule::choose_secondary_layer()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	sort(v_lr.begin(), v_lr.end(), cmp_lr);
	for (int i = 0; i < v_lr.size(); i++)
	{
		if (!add_secondary_optimization(v_lr[i]))
		{
			vector<pair<string, double>> down_list = v_lr[i].down_list;
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			for (int j = 0; j <= layer_end; j++)
			{
				task_replica_number[down_list[j].first] = Calculate_replica_number(down_list[j].first, reliability, f_max);
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].opt_frequency);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = task_map[down_list[i].first].opt_frequency_num; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}
	}

	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}

	return true;
}

bool EFR_Schedule::add_secondary_optimization(layer_record lr_max)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		if (down_list[0].first == lr_max.down_list[0].first)
		{
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_opt的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].opt_frequency);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				if (now_replica_num != Calculate_replica_number(down_list[i].first, reliability, f_max))
				{
					//int min_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_replica_number[down_list[i].first] = now_replica_num;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = task_map[down_list[i].first].opt_frequency_num; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == now_replica_num)
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[j - 1]);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);

				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
					task_replica_number[down_list[i].first] = now_replica_num;
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}
			bool exceed_deadline = false;
			for (int i = 0; i <= layer_end; i++)
			{
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
			{
				return false;
			}
			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
		else
		{
			vector<process> temp_process_list = process_list;
			int layer_end = 0;
			bool find_next_layer = false;
			//cout << "down list num: " << down_list.size() << endl;
			//cout << "aaa" << endl;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			//cout << "lay num:" << layer_end << endl;
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = task_replica_number[down_list[i].first];
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			//cout << "max replica :" << max_replica_num << endl;
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}

			bool exceed_deadline = false;
			//cout << "aaa" << endl;
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}
			//cout << "bbb " << exceed_deadline << endl;
			if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
			{

				bool exceed_second_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						if (j == 0 && task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							if (task_map[down_list[i].first].has_change_replica)
							{
								task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
						}

					}
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_second_deadline = true;
						break;
					}
				}

				if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return false;
				}

			}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
	}
	return true;
}


bool EFR_Schedule::new_optimization()
{
	vector<pair<string, double>> up_list = downward_task_list;
	reverse(up_list.begin(), up_list.end());
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	vector<pair<string, double>> temp_up_list = up_list;
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		up_list = temp_up_list;
		while (!up_list.empty())
		{
			int layer_end = 0;
			while (layer_end < up_list.size())  //计算同层任务数
			{
				if (task_map[up_list[0].first].layer != task_map[up_list[layer_end].first].layer)
				{
					break;
				}
				layer_end++;
			}
			layer_end--;

			double max_replica_num = -1.00;
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[up_list[i].first] > max_replica_num)
					max_replica_num = task_replica_number[up_list[i].first];
			}
			//cout << "bbb" << endl;
			if (task_map[up_list[0].first].is_in_layer)
			{
				//cout << "in layer" << endl;
				for (int rep_num = max_replica_num - 1; rep_num >= 0; rep_num--)
				{
					for (int i = 0; i <= layer_end; i++)
					{
						if (task_replica_number[up_list[i].first] - 1 < rep_num)
							continue;

						string now_task_id = up_list[i].first;
						task_start_time now_st = task_map[now_task_id].replica_start_time[rep_num];
						double late_end_time = -1.00;
						double Et_max = -1.00;
						for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
						{
							string suc_task = task_map[now_task_id].successors_node[j];
							double possible_end_time = task_map[suc_task].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task];
							if (late_end_time == -1.00 || possible_end_time < late_end_time)
								late_end_time = possible_end_time;
						}


						if (late_end_time == -1.00)
						{
							Et_max = task_map[now_task_id].deadline;
						}
						else
						{
							Et_max = min(late_end_time, task_map[now_task_id].deadline);
						}


						if (optimal_process_list[now_st.process_id].next_start_time == -1.00)
						{
							optimal_process_list[now_st.process_id].next_start_time = Et_max - task_map[now_task_id].wcet;
						}
						else
						{
							Et_max = min(Et_max, optimal_process_list[now_st.process_id].next_start_time);
						}


						int rep_max = task_map[now_task_id].optimal_replica_time.size() - 1;
						if (rep_max >= 0)
							Et_max = min(Et_max, task_map[now_task_id].optimal_replica_time[0].start_time);

						//cout << "111" << endl;
						if (rep_num != 0)
						{
							//cout << "in secondary" << endl;
							task_start_time new_st;
							new_st.process_id = now_st.process_id;
							new_st.f = f_max;
							if (now_st.start_time < Et_max - task_map[now_task_id].wcet)
							{
								new_st.start_time = Et_max - task_map[now_task_id].wcet;
								//has_changed = true;
							}
							else
								new_st.start_time = now_st.start_time;
							/*if (task_map[now_task_id].optimal_replica_time.empty())
							{
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							}
							else
							{
								new_st.start_time = min(new_st.start_time, task_map[now_task_id].optimal_replica_time[0].start_time);
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							}*/
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = f_max;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
						}
						else //对于primary replica采取先减少频率，再往后移动的方案，并且没有考虑因为频率减少而可能增加的replica.
						{
							//cout << "in primary" << endl;
							//cout << "222" << endl;
							task_start_time new_st;
							new_st.process_id = now_st.process_id;
							if (now_st.start_time < Et_max - task_map[now_task_id].wcet / now_st.f)
							{
								//cout << "in a" << endl;
								//has_changed = true;
								bool has_find = false;
								int f_i = 0;
								if (task_map[now_task_id].can_be_fmin)
								{
									for (f_i = 0; f_i <= task_map[now_task_id].opt_frequency_num; f_i++)
									{
										if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].opt_frequency_num)
										f_i--;
								}
								else
								{
									for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
									{
										if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].min_frequncy_num)
										f_i--;
								}

								new_st.f = process_list[new_st.process_id].frequency[f_i];
								new_st.start_time = Et_max - task_map[now_task_id].wcet / new_st.f;
								//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
							}
							else
							{
								//cout << "in b" << endl;
								new_st.start_time = now_st.start_time;
								new_st.f = now_st.f;
							}
							//cout << "333" << endl;
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = new_st.f;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							cout << "444" << endl;

							if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
							{
								add_additional_replica_number--;
								cout << "555" << endl;
								cout << "task size " << task_map[now_task_id].optimal_replica_time.size() << endl;
								task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
								//cout << "task size " << task_map[now_task_id].optimal_replica_time.size() << endl;
								//cout << "666" << endl;
								int delete_process_id = need_delete_st.process_id;
								double delete_time = need_delete_st.start_time;
								//cout << "7" << endl;
								//cout << "delete id " << delete_process_id << endl;
								//cout << "optimal size" << optimal_process_list.size() << endl;
								for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
								{
									cout << "8" << endl;
									if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
									{
										cout << "7777777" << endl;
										optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
										break;
									}
								}
								cout << "777" << endl;
								task_map[now_task_id].has_change_replica = false;
								task_map[now_task_id].can_be_fmin = false;
								task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
								task_replica_number[now_task_id]--;
								has_changed = true;
								//cout << "888" << endl;
							}
							//cout << "777" << endl;
						}


					}
				}
			}
			else
			{
				//cout << "in not layer" << endl;
				for (int i = 0; i <= layer_end; i++)
				{
					for (int rep_num = task_replica_number[up_list[i].first] - 1; rep_num >= 0; rep_num--)
					{
						if (task_replica_number[up_list[i].first] - 1 < rep_num)
							continue;

						string now_task_id = up_list[i].first;
						task_start_time now_st = task_map[now_task_id].replica_start_time[rep_num];
						double late_end_time = -1.00;
						double Et_max = -1.00;
						for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
						{
							string suc_task = task_map[now_task_id].successors_node[j];
							double possible_end_time = task_map[suc_task].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task];
							if (late_end_time == -1.00 || possible_end_time < late_end_time)
								late_end_time = possible_end_time;
						}


						if (late_end_time == -1.00)
						{
							Et_max = task_map[now_task_id].deadline;
						}
						else
						{
							Et_max = min(late_end_time, task_map[now_task_id].deadline);
						}


						if (optimal_process_list[now_st.process_id].next_start_time == -1.00)
						{
							optimal_process_list[now_st.process_id].next_start_time = Et_max - task_map[now_task_id].wcet;
						}
						else
						{
							Et_max = min(Et_max, optimal_process_list[now_st.process_id].next_start_time);
						}


						int rep_max = task_map[now_task_id].optimal_replica_time.size() - 1;
						if (rep_max >= 0)
							Et_max = min(Et_max, task_map[now_task_id].optimal_replica_time[0].start_time);

						//cout << "111" << endl;
						if (rep_num != 0)
						{
							task_start_time new_st;
							new_st.process_id = now_st.process_id;
							new_st.f = f_max;
							if (now_st.start_time < Et_max - task_map[now_task_id].wcet)
							{
								new_st.start_time = Et_max - task_map[now_task_id].wcet;
								//has_changed = true;
							}
							else
								new_st.start_time = now_st.start_time;
							/*if (task_map[now_task_id].optimal_replica_time.empty())
							{
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							}
							else
							{
								new_st.start_time = min(new_st.start_time, task_map[now_task_id].optimal_replica_time[0].start_time);
								task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							}*/
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = f_max;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
						}
						else //对于primary replica采取先减少频率，再往后移动的方案，并且没有考虑因为频率减少而可能增加的replica.
						{
							//cout << "222" << endl;
							task_start_time new_st;
							new_st.process_id = now_st.process_id;
							if (now_st.start_time < Et_max - task_map[now_task_id].wcet / now_st.f)
							{
								//has_changed = true;
								bool has_find = false;
								int f_i = 0;
								if (task_map[now_task_id].can_be_fmin)
								{
									for (f_i = 0; f_i <= task_map[now_task_id].opt_frequency_num; f_i++)
									{
										if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].opt_frequency_num)
										f_i--;
								}
								else
								{
									for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
									{
										if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
										{
											f_i--;
											break;
										}
									}
									if (f_i > task_map[now_task_id].min_frequncy_num)
										f_i--;
								}

								new_st.f = process_list[new_st.process_id].frequency[f_i];
								new_st.start_time = Et_max - task_map[now_task_id].wcet / new_st.f;
								//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
							}
							else
							{
								new_st.start_time = now_st.start_time;
								new_st.f = now_st.f;
							}
							//cout << "333" << endl;
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
							optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
							process_task new_pt;
							new_pt.task_id = now_task_id;
							new_pt.start_time = new_st.start_time;
							new_pt.task_state = rep_num;
							new_pt.f = new_st.f;
							optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
							//cout << "444" << endl;

							if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
							{
								add_additional_replica_number--;
								//cout << "555" << endl;
								task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
								//cout << "666" << endl;
								int delete_process_id = need_delete_st.process_id;
								double delete_time = need_delete_st.start_time;
								for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
								{
									if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
									{
										//cout << "7777777" << endl;
										optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
										break;
									}
								}
								task_map[now_task_id].has_change_replica = false;
								task_map[now_task_id].can_be_fmin = false;
								task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
								task_replica_number[now_task_id]--;
								has_changed = true;
							}

						}
					}
				}
			}

			//cout << "aaa" << endl;

			up_list.erase(up_list.begin(), up_list.begin() + layer_end + 1);


		}
		//cout << "aaa" << endl;
		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}

	}

	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time = t_it->second.replica_start_time;
		t_it++;
	}


	//process_list = optimal_process_list;
	return true;
}

bool EFR_Schedule::decrease_scheduling()
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //计算每个任务在f_optimal的replica数量，并分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			opti_fre of = optimal_frequency(down_list[i].first, reliability);
			task_map[down_list[i].first].min_frequncy = of.o_f;
			task_map[down_list[i].first].min_frequncy_num = of.of_num;
			int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, of.o_f);
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_replica_number[down_list[i].first] = now_replica_num;
			task_start_time now_st = divide_process(down_list[i].first, 0, of.o_f);
			task_map[down_list[i].first].replica_start_time.push_back(now_st);
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
		}

		bool exceed_deadline = false;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].finish_time;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].finish_time);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当optimal分层分配方式失败时，转为按fmax分层分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_max的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				task_replica_number[down_list[i].first] = now_replica_num;
				task_start_time now_st = divide_process(down_list[i].first, 0, f_max);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].finish_time;
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当fmax分层分配失败时，说明只能使用顺序分配方式
			{
				bool exceed_third_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						task_start_time now_st = divide_process(down_list[i].first, j, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}

					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].finish_time;
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_third_deadline = true;
						break;
					}
				}

				if (exceed_third_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return scheduing_optimal_heft();
				}
				else                        //顺序分配方式成功时，判定每个任务是否可以等于f_optimal
				{
					for (int i = 0; i <= layer_end; i++)
					{
						int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].min_frequncy);
						if (another_replica_num != task_replica_number[down_list[i].first])
						{
							can_add_additional++;
							task_map[down_list[i].first].can_be_fmin = false;
							task_map[down_list[i].first].has_change_replica = false;
							string now_task_id = down_list[i].first;
							int j = 0;
							for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
							{
								if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
									break;
							}
							task_map[now_task_id].min_frequncy_num = j;
							task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
						}
						else
						{
							task_map[down_list[i].first].can_be_fmin = true;
							task_map[down_list[i].first].has_change_replica = false;
						}
					}
				}
			}
			else                        //fmax分层分配方式成功时，判定每个任务是否可以等于f_optimal
			{
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].min_frequncy);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						can_add_additional++;
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}  //当optimal分层分配方式成功时，判定每个任务是否可以等于f_min
		else
		{
			for (int i = 0; i <= layer_end; i++)
			{
				int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, task_map[down_list[i].first].min_frequncy);
				if (another_replica_num != task_replica_number[down_list[i].first])
				{
					task_map[down_list[i].first].can_be_fmin = false;
					task_map[down_list[i].first].has_change_replica = false;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
				}
			}
		}

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);

	}

	return true;
}

bool EFR_Schedule::decrease_optimization()
{
	vector<pair<string, double>> up_list = downward_task_list;
	reverse(up_list.begin(), up_list.end());
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	vector<pair<string, double>> temp_up_list = up_list;
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		up_list = temp_up_list;
		while (!up_list.empty())
		{
			int layer_end = 0;
			while (layer_end < up_list.size())  //计算同层任务数
			{
				if (task_map[up_list[0].first].layer != task_map[up_list[layer_end].first].layer)
				{
					break;
				}
				layer_end++;
			}
			layer_end--;

			double max_replica_num = -1.00;
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[up_list[i].first] > max_replica_num)
					max_replica_num = task_replica_number[up_list[i].first];
			}

			for (int rep_num = max_replica_num - 1; rep_num >= 0; rep_num--)
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[up_list[i].first] - 1 < rep_num)
						continue;

					string now_task_id = up_list[i].first;
					task_start_time now_st = task_map[now_task_id].replica_start_time[rep_num];
					double late_end_time = -1.00;
					double Et_max = -1.00;
					for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
					{
						string suc_task = task_map[now_task_id].successors_node[j];
						double possible_end_time = task_map[suc_task].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task];
						if (late_end_time == -1.00 || possible_end_time < late_end_time)
							late_end_time = possible_end_time;
					}


					if (late_end_time == -1.00)
					{
						Et_max = task_map[now_task_id].deadline;
					}
					else
					{
						Et_max = min(late_end_time, task_map[now_task_id].deadline);
					}


					if (optimal_process_list[now_st.process_id].next_start_time == -1.00)
					{
						optimal_process_list[now_st.process_id].next_start_time = Et_max - task_map[now_task_id].wcet;
					}
					else
					{
						Et_max = min(Et_max, optimal_process_list[now_st.process_id].next_start_time);
					}


					int rep_max = task_map[now_task_id].optimal_replica_time.size() - 1;
					if (rep_max >= 0)
						Et_max = min(Et_max, task_map[now_task_id].optimal_replica_time[0].start_time);

					//cout << "111" << endl;
					if (rep_num != 0) //任何replica开始往后移，能多后就多后
					{
						task_start_time new_st;
						new_st.process_id = now_st.process_id;
						new_st.f = f_max;
						if (now_st.finish_time < Et_max)
						{
							new_st.start_time = Et_max - ( now_st.finish_time - now_st.start_time );
							new_st.finish_time = Et_max;
						}
						else
						{
							new_st.start_time = now_st.start_time;
							new_st.finish_time = now_st.finish_time;
						}
							
						/*if (task_map[now_task_id].optimal_replica_time.empty())
						{
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
						}
						else
						{
							new_st.start_time = min(new_st.start_time, task_map[now_task_id].optimal_replica_time[0].start_time);
							task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
						}*/
						task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
						optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
						process_task new_pt;
						new_pt.task_id = now_task_id;
						new_pt.start_time = new_st.start_time;
						new_pt.task_state = rep_num;
						new_pt.f = f_max;
						new_pt.finish_time = new_st.finish_time;
						optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
					}
					else //对于primary replica采取先减少频率，最多减少到f_optimal，再往后移动的方案
					{
						//cout << "222" << endl;
						task_start_time new_st;
						new_st.process_id = now_st.process_id;
						if (now_st.start_time < Et_max - task_map[now_task_id].wcet / now_st.f)
						{
							bool has_find = false;
							int f_i = 0;
							double wf_before = now_st.finish_time - now_st.start_time;
							double wf = now_st.finish_time - now_st.start_time;
							if (task_map[now_task_id].can_be_fmin)
							{
								for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num ; f_i++)
								{
									wf_before = wf;
									wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
									if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
									{
										break;
									}
								}
								f_i--;
								if (f_i == task_map[now_task_id].min_frequncy_num)
									wf_before = wf;
							}
							else
							{
								for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
								{
									wf_before = wf;
									wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
									if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
									{
										f_i--;
										break;
									}
								}
								if (f_i > task_map[now_task_id].min_frequncy_num)
									f_i--;
								if (f_i == task_map[now_task_id].min_frequncy_num)
									wf_before = wf;
							}

							new_st.f = process_list[new_st.process_id].frequency[f_i];
							new_st.start_time = Et_max - wf_before;
							new_st.finish_time = Et_max;
							//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
						}
						else
						{
							new_st.start_time = now_st.start_time;
							new_st.f = now_st.f;
							new_st.finish_time = now_st.finish_time;
						}
						//cout << "333" << endl;
						task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
						optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
						process_task new_pt;
						new_pt.task_id = now_task_id;
						new_pt.start_time = new_st.start_time;
						new_pt.task_state = rep_num;
						new_pt.f = new_st.f;
						new_pt.finish_time = new_st.finish_time;
						optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
						//cout << "444" << endl;

						if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
						{
							add_additional_replica_number--;
							//cout << "555" << endl;
							task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
							//cout << "666" << endl;
							int delete_process_id = need_delete_st.process_id;
							double delete_time = need_delete_st.start_time;
							for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
							{
								if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
								{
									//cout << "7777777" << endl;
									optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
									break;
								}
							}
							task_map[now_task_id].has_change_replica = false;
							task_map[now_task_id].can_be_fmin = false;
							task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
							task_replica_number[now_task_id]--;
							has_changed = true;
						}

					}


				}
			}

			up_list.erase(up_list.begin(), up_list.begin() + layer_end + 1);


		}
		//cout << "aaa" << endl;
		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}
		//cout << "bbb" << endl;
	}

	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time = t_it->second.replica_start_time;
		t_it++;
	}
	for (int i = 0; i < process_list.size(); i++)
	{
		sort(process_list[i].pt.begin(), process_list[i].pt.end(), cmp_pt);
	}

	//process_list = optimal_process_list;
}

bool EFR_Schedule::decrease_another_optimization()
{
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		vector<process> run_process_list = process_list;
		vector<process_task> need_improved_task;
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
				continue;
			reverse(run_process_list[i].pt.begin(), run_process_list[i].pt.end());
			for (int j = 0; j < run_process_list[i].pt.size(); j++)
			{
				run_process_list[i].pt[j].p_id = i;
			}
		}
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
			{
				continue;
			}
			else
			{
				need_improved_task.push_back(run_process_list[i].pt[0]);
			}

		}
		sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);



		while (!need_improved_task.empty())
		{
			sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);
			//cout << "aaa" << endl;
			process_task now_pt = need_improved_task[0];
			string now_task_id = now_pt.task_id;
			int rep_num = now_pt.task_state;
			double Et_max = -1.00;
			double late_end_time = -1.00;
			for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
			{
				string suc_task_id = task_map[now_task_id].successors_node[j];
				if (late_end_time == -1.00 || late_end_time > task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id])
					late_end_time = task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id];
			}
			//cout << "ccc" << endl;
			if (late_end_time == -1.00)
				Et_max = task_map[now_task_id].deadline;
			else
				Et_max = min(task_map[now_task_id].deadline, late_end_time);

			//cout << "ddd1 " << optimal_process_list[now_pt.p_id].pt.size() << endl;

			if (optimal_process_list[now_pt.p_id].pt.size() != 0)
			{
				Et_max = min(optimal_process_list[now_pt.p_id].pt[0].start_time, Et_max);
			}

			//cout << "ddd" << endl;

			if (task_map[now_task_id].optimal_replica_time.size() != 0)
			{
				Et_max = min(task_map[now_task_id].optimal_replica_time[0].start_time, Et_max);
			}

			//cout << "bbb" << endl;

			if (rep_num != 0)
			{

				process_task new_pt;
				new_pt.f = now_pt.f;
				new_pt.p_id = now_pt.p_id;
				new_pt.task_id = now_pt.task_id;
				new_pt.task_state = now_pt.task_state;
				if (now_pt.finish_time < Et_max)
				{
					new_pt.finish_time = Et_max;
					new_pt.start_time = Et_max - (now_pt.finish_time - now_pt.start_time);
				}
				else
				{
					new_pt.finish_time = now_pt.finish_time;
					new_pt.start_time = now_pt.start_time;
				}
				optimal_process_list[new_pt.p_id].pt.insert(optimal_process_list[new_pt.p_id].pt.begin(), new_pt);
				task_start_time new_st;
				new_st.f = new_pt.f;
				new_st.process_id = new_pt.p_id;
				new_st.start_time = new_pt.start_time;
				new_st.finish_time = new_pt.finish_time;
				task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
			}
			else
			{
				task_start_time now_st;
				task_start_time new_st;
				now_st.start_time = now_pt.start_time;
				now_st.finish_time = now_pt.finish_time;
				now_st.f = now_pt.f;
				now_st.process_id = now_pt.p_id;

				new_st.process_id = now_st.process_id;

				if (now_st.finish_time < Et_max)
				{
					//has_changed = true;
					bool has_find = false;
					int f_i = 0;
					double wf_before = now_st.finish_time - now_st.start_time;
					double wf = now_st.finish_time - now_st.start_time;
					if (task_map[now_task_id].can_be_fmin)
					{
						for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
						{
							wf_before = wf;
							wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
							if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
							{
								break;
							}
						}
						f_i--;
						if (f_i == task_map[now_task_id].min_frequncy_num)
							wf_before = wf;
					}
					else
					{
						for (f_i = 0; f_i <= task_map[now_task_id].min_frequncy_num; f_i++)
						{
							wf_before = wf;
							wf = Calculate_execution_time(task_map[now_task_id].wcet, process_list[0].frequency[f_i]);
							if (now_st.start_time + task_map[now_task_id].wcet / process_list[new_st.process_id].frequency[f_i] > Et_max)
							{
								f_i--;
								break;
							}
						}
						if (f_i > task_map[now_task_id].min_frequncy_num)
							f_i--;
						if (f_i == task_map[now_task_id].min_frequncy_num)
							wf_before = wf;
					}
					new_st.f = process_list[new_st.process_id].frequency[f_i];
					new_st.start_time = Et_max - wf_before;
					new_st.finish_time = Et_max;
					//cout << "task id: " << now_task_id << " f: " << new_st.f << endl;
				}
				else
				{
					new_st.f = now_st.f;
					new_st.start_time = now_st.start_time;
					new_st.finish_time = now_st.finish_time;
				}

				if (new_st.f < now_st.f)
					has_changed = true;

				task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
				optimal_process_list[now_st.process_id].next_start_time = new_st.start_time;
				process_task new_pt;
				new_pt.task_id = now_task_id;
				new_pt.start_time = new_st.start_time;
				new_pt.task_state = rep_num;
				new_pt.f = new_st.f;
				new_pt.finish_time = new_st.finish_time;
				new_pt.p_id = new_st.process_id;
				optimal_process_list[now_st.process_id].pt.insert(optimal_process_list[now_st.process_id].pt.begin(), new_pt);
				//cout << "444" << endl;

				if (task_map[now_task_id].has_change_replica && new_st.f >= task_map[now_task_id].min_frequncy)
				{
					if (task_map[now_task_id].optimal_replica_time.size() == 1)
					{
						task_map[now_task_id].has_change_replica = false;
						task_map[now_task_id].can_be_fmin = false;
					}
					else
					{
						add_additional_replica_number--;
						//cout << "555" << endl;
						task_start_time need_delete_st = task_map[now_task_id].optimal_replica_time[1];
						//cout << "666" << endl;
						int delete_process_id = need_delete_st.process_id;
						double delete_time = need_delete_st.start_time;
						//cout << "999" << endl;


						for (int i = 0; i < optimal_process_list[delete_process_id].pt.size(); i++)
						{
							if (optimal_process_list[delete_process_id].pt[i].start_time == delete_time)
							{
								//cout << "7777777" << endl;
								optimal_process_list[delete_process_id].pt.erase(optimal_process_list[delete_process_id].pt.begin() + i);
								break;
							}
						}
						//cout << "888" << endl;
						task_map[now_task_id].has_change_replica = false;
						task_map[now_task_id].can_be_fmin = false;
						task_map[now_task_id].optimal_replica_time.erase(task_map[now_task_id].optimal_replica_time.begin() + 1);
						task_replica_number[now_task_id]--;
						has_changed = true;
					}
				}


			}

			run_process_list[now_pt.p_id].pt.erase(run_process_list[now_pt.p_id].pt.begin());
			if (run_process_list[now_pt.p_id].pt.size() == 0)
			{
				need_improved_task.erase(need_improved_task.begin());
			}
			else
			{
				need_improved_task[0] = run_process_list[now_pt.p_id].pt[0];
			}
		}

		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}
		if (has_changed)
		{
			//cout << "hhhhhhhhhhhhhhhh" << endl;
			double min_time = -1.00;
			for (int i = 0; i < process_list.size(); i++)
			{
				if (process_list[i].pt.empty())
					continue;
				if (min_time == -1.00 || process_list[i].pt[0].start_time < min_time)
					min_time = process_list[i].pt[0].start_time;
			}

			for (int i = 0; i < process_list.size(); i++)
			{
				for (int j = 0; j < process_list[i].pt.size(); j++)
				{
					process_list[i].pt[j].start_time -= min_time;
					process_list[i].pt[j].finish_time -= min_time;
					process_task now_pt = process_list[i].pt[j];
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].start_time -= min_time;
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].finish_time -= min_time;
				}
			}
		}


	}
}

bool EFR_Schedule::partial_optimization()
{
	partial_scheduling();
	optimization();
	return true;
}

bool EFR_Schedule::choose_decrease_task()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	sort(v_lr.begin(), v_lr.end(), cmp_lr);
	for (int i = 0; i < v_lr.size(); i++)
	{
		if (!add_additional_test(v_lr[i]))
		{
			vector<pair<string, double>> down_list = v_lr[i].down_list;
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			for (int j = 0; j <= layer_end; j++)
			{
				task_replica_number[down_list[j].first] = Calculate_replica_number(down_list[j].first, reliability, f_max);
				for (int i = 0; i <= layer_end; i++)
				{
					int another_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
					if (another_replica_num != task_replica_number[down_list[i].first])
					{
						task_map[down_list[i].first].can_be_fmin = false;
						task_map[down_list[i].first].has_change_replica = false;
						string now_task_id = down_list[i].first;
						int j = 0;
						for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
						{
							if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
								break;
						}
						task_map[now_task_id].min_frequncy_num = j;
						task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					}
					else
					{
						task_map[down_list[i].first].can_be_fmin = true;
						task_map[down_list[i].first].has_change_replica = false;
					}
				}
			}

		}
	}

	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	//	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		vector<process> temp_process_list = process_list;
		int layer_end = 0;
		bool find_next_layer = false;
		//cout << "down list num: " << down_list.size() << endl;
		//cout << "aaa" << endl;
		while (layer_end < down_list.size())  //计算同层任务数
		{
			if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
			{
				find_next_layer = true;
				break;
			}
			layer_end++;
		}
		//cout << "lay num:" << layer_end << endl;
		layer_end--;
		if (layer_end == down_list.size())
			layer_end--;
		int max_replica_num = -1;
		for (int i = 0; i <= layer_end; i++) //分配primary replica
		{
			task_map[down_list[i].first].replica_start_time.clear();
			task_map[down_list[i].first].is_in_layer = true;
			int now_replica_num = task_replica_number[down_list[i].first];
			if (task_map[down_list[i].first].has_change_replica)
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			else
			{
				task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].optimal_replica_time[0].f);
				task_map[down_list[i].first].replica_start_time.push_back(now_st);
			}
			if (max_replica_num < now_replica_num)
				max_replica_num = now_replica_num;
		}
		//cout << "max replica :" << max_replica_num << endl;
		for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
		{
			for (int i = 0; i <= layer_end; i++)
			{
				if (task_replica_number[down_list[i].first] - 1 < rep_num)
					continue;
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
			}
		}

		bool exceed_deadline = false;
		//cout << "aaa" << endl;
		for (int i = 0; i <= layer_end; i++)
		{
			//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
			//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
			double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
			if (now_end_time > task_map[down_list[i].first].deadline)
			{
				exceed_deadline = true;
				break;
			}
		}
		//cout << "bbb " << exceed_deadline << endl;
		if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
		{

			bool exceed_second_deadline = false;
			process_list = temp_process_list;
			for (int i = 0; i <= layer_end; i++)
			{
				task_map[down_list[i].first].replica_start_time.clear();
				task_map[down_list[i].first].is_in_layer = false;
			}
			for (int i = 0; i <= layer_end; i++)
			{
				for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
				{
					if (j == 0 && task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						if (j == 0)
						{
							task_start_time now_st = divide_process(down_list[i].first, j, task_map[down_list[i].first].optimal_replica_time[0].f);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else if (task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							task_start_time now_st = divide_process(down_list[i].first, j, f_max);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
					}
				}

				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
					exceed_second_deadline = true;
					break;
				}
			}

			if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
			{
				cout << "---------------------------chose optimal heft" << endl;
				return false;
			}

		}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

		down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
	}


	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time.clear();
		t_it++;
	}

	return true;
}

bool EFR_Schedule::add_additional_test(layer_record lr_max)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].next_start_time = -1.00;
		process_list[i].ready_time = 0.00;
	}
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	vector<pair<string, double>> down_list = downward_task_list;
	while (!down_list.empty())
	{
		if (down_list[0].first == lr_max.down_list[0].first)
		{
			int layer_end = 0;
			bool find_next_layer = false;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //计算每个任务在f_opt的replica数量，并分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_min);
				if (now_replica_num == -1)
				{
					cout << "replica num false task id: " << down_list[i].first << endl;
					return false;
				}
				if (now_replica_num != Calculate_replica_number(down_list[i].first, reliability, f_max))
				{
					//int min_replica_num = Calculate_replica_number(down_list[i].first, reliability, f_max);
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = true;
					task_replica_number[down_list[i].first] = now_replica_num;
					string now_task_id = down_list[i].first;
					int j = 0;
					for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
					{
						if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == now_replica_num)
							break;
					}
					task_map[now_task_id].min_frequncy_num = j;
					task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
					task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[j - 1]);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);

				}
				else
				{
					task_map[down_list[i].first].can_be_fmin = true;
					task_map[down_list[i].first].has_change_replica = false;
					task_replica_number[down_list[i].first] = now_replica_num;
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].optimal_replica_time[0].f);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}
			bool exceed_deadline = false;
			for (int i = 0; i <= layer_end; i++)
			{
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}

			if (exceed_deadline) //当分层分配方式失败，则说明该层只能用顺序法测试
			{
				return false;
			}
			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
		else
		{
			vector<process> temp_process_list = process_list;
			int layer_end = 0;
			bool find_next_layer = false;
			//cout << "down list num: " << down_list.size() << endl;
			//cout << "aaa" << endl;
			while (layer_end < down_list.size())  //计算同层任务数
			{
				if (task_map[down_list[0].first].layer != task_map[down_list[layer_end].first].layer)
				{
					find_next_layer = true;
					break;
				}
				layer_end++;
			}
			//cout << "lay num:" << layer_end << endl;
			layer_end--;
			if (layer_end == down_list.size())
				layer_end--;
			int max_replica_num = -1;
			for (int i = 0; i <= layer_end; i++) //分配primary replica
			{
				task_map[down_list[i].first].replica_start_time.clear();
				int now_replica_num = task_replica_number[down_list[i].first];
				if (task_map[down_list[i].first].has_change_replica)
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				else
				{
					task_start_time now_st = divide_process(down_list[i].first, 0, task_map[down_list[i].first].optimal_replica_time[0].f);
					task_map[down_list[i].first].replica_start_time.push_back(now_st);
				}
				if (max_replica_num < now_replica_num)
					max_replica_num = now_replica_num;
			}
			//cout << "max replica :" << max_replica_num << endl;
			for (int rep_num = 1; rep_num <= max_replica_num - 1; rep_num++) //分配secondary replica
			{
				for (int i = 0; i <= layer_end; i++)
				{
					if (task_replica_number[down_list[i].first] - 1 < rep_num)
						continue;
					if (task_map[down_list[i].first].has_change_replica)
					{
						task_start_time now_st = divide_additional_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
					else
					{
						task_start_time now_st = divide_process(down_list[i].first, rep_num, f_max);
						task_map[down_list[i].first].replica_start_time.push_back(now_st);
					}
				}
			}

			bool exceed_deadline = false;
			//cout << "aaa" << endl;
			for (int i = 0; i <= layer_end; i++)
			{
				//cout << "task id: " << down_list[i].first << "real replica num :" << task_map[down_list[i].first].replica_start_time.size() << endl;
				//cout << "task id: " << down_list[i].first << "replica num :" << task_replica_number[down_list[i].first] << endl;
				double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
				now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
				if (now_end_time > task_map[down_list[i].first].deadline)
				{
					exceed_deadline = true;
					break;
				}
			}
			//cout << "bbb " << exceed_deadline << endl;
			if (exceed_deadline) //当分层分配方式失败时，转为按先后顺序分配
			{

				bool exceed_second_deadline = false;
				process_list = temp_process_list;
				for (int i = 0; i <= layer_end; i++)
				{
					task_map[down_list[i].first].replica_start_time.clear();
				}
				for (int i = 0; i <= layer_end; i++)
				{
					for (int j = 0; j < task_replica_number[down_list[i].first]; j++)
					{
						if (j == 0 && task_map[down_list[i].first].has_change_replica)
						{
							task_start_time now_st = divide_process(down_list[i].first, 0, process_list[0].frequency[task_map[down_list[i].first].min_frequncy_num - 1]);
							task_map[down_list[i].first].replica_start_time.push_back(now_st);
						}
						else
						{
							if (j == 0)
							{
								task_start_time now_st = divide_process(down_list[i].first, j, task_map[down_list[i].first].optimal_replica_time[0].f);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else if (task_map[down_list[i].first].has_change_replica)
							{
								task_start_time now_st = divide_additional_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
							else
							{
								task_start_time now_st = divide_process(down_list[i].first, j, f_max);
								task_map[down_list[i].first].replica_start_time.push_back(now_st);
							}
						}

					}
					double now_end_time = task_map[down_list[i].first].replica_start_time[task_replica_number[down_list[i].first] - 1].start_time + task_map[down_list[i].first].wcet;
					now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].start_time + task_map[down_list[i].first].wcet / task_map[down_list[i].first].replica_start_time[0].f);
					if (now_end_time > task_map[down_list[i].first].deadline)
					{
						cout << "exceed_second_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
						exceed_second_deadline = true;
						break;
					}
				}

				if (exceed_second_deadline) //当顺序分配失败时，说明只能使用Heft分配方式
				{
					cout << "---------------------------chose optimal heft" << endl;
					return false;
				}

			}  //当分层分配方式成功时，判定每个任务是否可以等于f_min

			down_list.erase(down_list.begin(), down_list.begin() + layer_end + 1);
		}
	
	}


	return true;
}



bool EFR_Schedule::non_layer_scheduling()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < downward_task_list.size(); i++)
	{
		vector<process> temp_process = process_list;
		task_map[downward_task_list[i].first].is_in_layer = false;
		opti_fre of = optimal_frequency(downward_task_list[i].first, reliability);
		task_map[downward_task_list[i].first].opt_frequency_num = of.of_num;
		task_map[downward_task_list[i].first].opt_frequency = of.o_f;
		task_map[downward_task_list[i].first].replica_start_time.clear();
		task_map[downward_task_list[i].first].is_in_layer = false;
		int now_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_max);
		task_replica_number[downward_task_list[i].first] = now_replica_num;
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << downward_task_list[i].first << endl;
			return false;
		}
		for (int j = 0; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_process(downward_task_list[i].first, j, f_max);
			task_map[downward_task_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[downward_task_list[i].first].replica_start_time[now_replica_num - 1].start_time + task_map[downward_task_list[i].first].wcet;
		if (now_end_time > task_map[downward_task_list[i].first].deadline)
		{
			cout << "exceed_deadline: " << downward_task_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[downward_task_list[i].first].deadline << endl;
			return scheduing_optimal_heft();
		}
		int another_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_min);
		if (another_replica_num != task_replica_number[downward_task_list[i].first])
		{
			process_list = temp_process;
			task_map[downward_task_list[i].first].replica_start_time.clear();
			for (int j = 0; j < another_replica_num; j++)
			{
				task_start_time	new_ts = divide_process(downward_task_list[i].first, j, f_max);
				task_map[downward_task_list[i].first].replica_start_time.push_back(new_ts);
			}
			double another_end_time = task_map[downward_task_list[i].first].replica_start_time[another_replica_num - 1].start_time + task_map[downward_task_list[i].first].wcet;
			bool exceed = false;
			if (another_end_time > task_map[downward_task_list[i].first].deadline)
			{
				exceed = true;
			}
			if (exceed)
			{
				task_map[downward_task_list[i].first].can_be_fmin = false;
				task_map[downward_task_list[i].first].has_change_replica = false;
				process_list = temp_process;
				task_map[downward_task_list[i].first].replica_start_time.clear();
				task_map[downward_task_list[i].first].replica_start_time.clear();
				for (int j = 0; j < now_replica_num; j++)
				{
					task_start_time	new_ts = divide_process(downward_task_list[i].first, j, f_max);
					task_map[downward_task_list[i].first].replica_start_time.push_back(new_ts);
				}
			}
			else
			{
				task_map[downward_task_list[i].first].can_be_fmin = true;
				task_map[downward_task_list[i].first].has_change_replica = true;
			}
			string now_task_id = downward_task_list[i].first;
			int j = 0;
			for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
			{
				if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
					break;
			}
			task_map[now_task_id].min_frequncy_num = j;
			task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
			if (!exceed)
				task_replica_number[downward_task_list[i].first] = another_replica_num;
		}
		else
		{
			task_map[downward_task_list[i].first].can_be_fmin = true;
			task_map[downward_task_list[i].first].has_change_replica = false;
		}


	}
	return true;
}


bool EFR_Schedule::non_layer_partial_scheduling()
{
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < downward_task_list.size(); i++)
	{
		vector<process> temp_process = process_list;
		task_map[downward_task_list[i].first].is_in_layer = false;
		opti_fre of = optimal_frequency(downward_task_list[i].first, reliability);
		task_map[downward_task_list[i].first].opt_frequency_num = of.of_num;
		task_map[downward_task_list[i].first].opt_frequency = of.o_f;
		task_map[downward_task_list[i].first].replica_start_time.clear();
		task_map[downward_task_list[i].first].is_in_layer = false;
		int now_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_max);
		task_replica_number[downward_task_list[i].first] = now_replica_num;
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << downward_task_list[i].first << endl;
			return false;
		}
		for (int j = 0; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_process(downward_task_list[i].first, j, f_max);
			task_map[downward_task_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[downward_task_list[i].first].replica_start_time[now_replica_num - 1].start_time + task_map[downward_task_list[i].first].wcet;
		if (now_end_time > task_map[downward_task_list[i].first].deadline)
		{
			cout << "exceed_deadline: " << downward_task_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[downward_task_list[i].first].deadline << endl;
			return scheduing_optimal_heft();
		}
		int another_replica_num = Calculate_replica_number(downward_task_list[i].first, reliability, f_min);
		if (another_replica_num != task_replica_number[downward_task_list[i].first])
		{
			
			task_map[downward_task_list[i].first].can_be_fmin = true;
			task_map[downward_task_list[i].first].has_change_replica = true;
			string now_task_id = downward_task_list[i].first;
			int j = 0;
			for (j = process_list[0].frequency.size() - 1; j >= 0; j--)
			{
				if (Calculate_replica_number(now_task_id, reliability, process_list[0].frequency[j]) == task_replica_number[now_task_id])
					break;
			}
			task_map[now_task_id].min_frequncy_num = j;
			task_map[now_task_id].min_frequncy = process_list[0].frequency[j];
		}
		else
		{
			task_map[downward_task_list[i].first].can_be_fmin = true;
			task_map[downward_task_list[i].first].has_change_replica = false;
		}


	}
	return true;
}



bool EFR_Schedule::ods_scheduling()
{
	int r_num = 1;
	while (true)
	{
		if (r_num >= process_list.size())
		{
			for (int j = 0; j < process_list.size(); j++)
			{
				process_list[j].pt.clear();
				process_list[j].next_start_time = -1.00;
				process_list[j].ready_time = 0.00;
			}
			return scheduing_optimal_heft();
		}
		for (int i = process_list[0].frequency.size() - 1; i >= 0; i--)
		{
			map<string, task>::iterator t_it = task_map.begin();
			double min_rel = 1.00;
			while (t_it != task_map.end())
			{
				double now_rel = 1.00;
				if (r_num == 1)
					now_rel = Calculate_Reliable(t_it->second.wcet / process_list[0].frequency[i], process_list[0].frequency[i]);
				else
				{
					now_rel = 1 - (1 - Calculate_Reliable(t_it->second.wcet / process_list[0].frequency[i], process_list[0].frequency[i])) * pow(1 - Calculate_Reliable(t_it->second.wcet, f_max), r_num - 1);
				}
				min_rel *= now_rel;
				t_it++;
			}

			if (min_rel >= globle_reliability)
			{
				//cout << "min rel:" << min_rel << " r num: " << r_num << endl;
				if (!ods_part_scheduling(process_list[0].frequency[i], r_num))
				{
					for (int j = 0; j < process_list.size(); j++)
					{
						process_list[j].pt.clear();
						process_list[j].next_start_time = -1.00;
						process_list[j].ready_time = 0.00;
					}
				}
				else
				{
					return true;
				}
			}

		}
		r_num++;
	}
	return false;
}

bool EFR_Schedule::ods_part_scheduling(double p_f, int r_num)
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	for (int i = 0; i < down_list.size(); i++)
	{
		task_map[down_list[i].first].replica_start_time.clear();
		//int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, p_f);
		int now_replica_num = r_num;
		task_replica_number[down_list[i].first] = now_replica_num;
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << down_list[i].first << endl;
			return false;
		}
		task_start_time new_ts = divide_process(down_list[i].first, 0, p_f);
		task_map[down_list[i].first].replica_start_time.push_back(new_ts);
		for (int j = 1; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_process(down_list[i].first, j, f_max);
			task_map[down_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[down_list[i].first].replica_start_time[now_replica_num - 1].finish_time;
		now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].finish_time);
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			//cout << "Heft_exceed_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
			return false;
		}
	}
	return true;
}

bool EFR_Schedule::ods_optimization()
{
	vector<process> optimal_process_list;
	optimal_process_list = process_list;
	for (int i = 0; i < process_list.size(); i++)
	{
		optimal_process_list[i].pt.clear();
		optimal_process_list[i].next_start_time = -1.00;
		optimal_process_list[i].ready_time = 0.00;
	}
	bool has_changed = true;
	while (has_changed)
	{
		has_changed = false;
		vector<process> run_process_list = process_list;
		vector<process_task> need_improved_task;
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
				continue;
			reverse(run_process_list[i].pt.begin(), run_process_list[i].pt.end());
			for (int j = 0; j < run_process_list[i].pt.size(); j++)
			{
				run_process_list[i].pt[j].p_id = i;
			}
		}
		for (int i = 0; i < run_process_list.size(); i++)
		{
			if (run_process_list[i].pt.size() == 0)
			{
				continue;
			}
			else
			{
				need_improved_task.push_back(run_process_list[i].pt[0]);
			}

		}
		sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);



		while (!need_improved_task.empty())
		{
			sort(need_improved_task.begin(), need_improved_task.end(), cmp_larger_pt);
			//cout << "aaa" << endl;
			process_task now_pt = need_improved_task[0];
			string now_task_id = now_pt.task_id;
			int rep_num = now_pt.task_state;
			double Et_max = -1.00;
			double late_end_time = -1.00;
			for (int j = 0; j < task_map[now_task_id].successors_node.size(); j++)
			{
				string suc_task_id = task_map[now_task_id].successors_node[j];
				if (late_end_time == -1.00 || late_end_time > task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id])
					late_end_time = task_map[suc_task_id].optimal_replica_time[0].start_time - edge_communication[now_task_id][suc_task_id];
			}
			//cout << "ccc" << endl;
			if (late_end_time == -1.00)
				Et_max = task_map[now_task_id].deadline;
			else
				Et_max = min(task_map[now_task_id].deadline, late_end_time);

			//cout << "ddd1 " << optimal_process_list[now_pt.p_id].pt.size() << endl;

			if (optimal_process_list[now_pt.p_id].pt.size() != 0)
			{
				Et_max = min(optimal_process_list[now_pt.p_id].pt[0].start_time, Et_max);
			}

			//cout << "ddd" << endl;

			if (task_map[now_task_id].optimal_replica_time.size() != 0)
			{
				Et_max = min(task_map[now_task_id].optimal_replica_time[0].start_time, Et_max);
			}

			//cout << "bbb" << endl;

			if (rep_num != 0 || rep_num == 0)
			{

				process_task new_pt;
				new_pt.f = now_pt.f;
				new_pt.p_id = now_pt.p_id;
				new_pt.task_id = now_pt.task_id;
				new_pt.task_state = now_pt.task_state;
				if (now_pt.finish_time < Et_max)
				{
					new_pt.finish_time = Et_max;
					new_pt.start_time = Et_max - (now_pt.finish_time - now_pt.start_time);
				}
				else
				{
					new_pt.finish_time = now_pt.finish_time;
					new_pt.start_time = now_pt.start_time;
				}
				optimal_process_list[new_pt.p_id].pt.insert(optimal_process_list[new_pt.p_id].pt.begin(), new_pt);
				task_start_time new_st;
				new_st.f = new_pt.f;
				new_st.process_id = new_pt.p_id;
				new_st.start_time = new_pt.start_time;
				new_st.finish_time = new_pt.finish_time;
				task_map[now_task_id].optimal_replica_time.insert(task_map[now_task_id].optimal_replica_time.begin(), new_st);
			}

			run_process_list[now_pt.p_id].pt.erase(run_process_list[now_pt.p_id].pt.begin());
			if (run_process_list[now_pt.p_id].pt.size() == 0)
			{
				need_improved_task.erase(need_improved_task.begin());
			}
			else
			{
				need_improved_task[0] = run_process_list[now_pt.p_id].pt[0];
			}
		}

		process_list = optimal_process_list;
		for (int i = 0; i < optimal_process_list.size(); i++)
		{
			optimal_process_list[i].pt.clear();
			optimal_process_list[i].ready_time = 0.00;
			optimal_process_list[i].next_start_time = -1.00;
		}
		map<string, task>::iterator t_it = task_map.begin();
		while (t_it != task_map.end())
		{
			t_it->second.replica_start_time = t_it->second.optimal_replica_time;
			t_it->second.optimal_replica_time.clear();
			t_it++;
		}
		if (has_changed)
		{
			//cout << "hhhhhhhhhhhhhhhh" << endl;
			double min_time = -1.00;
			for (int i = 0; i < process_list.size(); i++)
			{
				if (process_list[i].pt.empty())
					continue;
				if (min_time == -1.00 || process_list[i].pt[0].start_time < min_time)
					min_time = process_list[i].pt[0].start_time;
			}

			for (int i = 0; i < process_list.size(); i++)
			{
				for (int j = 0; j < process_list[i].pt.size(); j++)
				{
					process_list[i].pt[j].start_time -= min_time;
					process_list[i].pt[j].finish_time -= min_time;
					process_task now_pt = process_list[i].pt[j];
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].start_time -= min_time;
					task_map[now_pt.task_id].replica_start_time[now_pt.task_state].finish_time -= min_time;
				}
			}
		}


	}
}

bool EFR_Schedule::out_degree_ods_scheduling()
{
	Calculate_OD();
	int r_num = 1;
	while (true)
	{
		if (r_num >= process_list.size())
		{
			for (int j = 0; j < process_list.size(); j++)
			{
				process_list[j].pt.clear();
				process_list[j].next_start_time = -1.00;
				process_list[j].ready_time = 0.00;
			}
			return scheduing_optimal_heft();
		}
		for (int i = process_list[0].frequency.size() - 1; i >= 0; i--)
		{
			map<string, task>::iterator t_it = task_map.begin();
			double min_rel = 1.00;
			while (t_it != task_map.end())
			{
				double now_rel = 1.00;
				if (r_num == 1)
					now_rel = Calculate_Reliable(t_it->second.wcet / process_list[0].frequency[i], process_list[0].frequency[i]);
				else
				{
					now_rel = 1 - (1 - Calculate_Reliable(t_it->second.wcet / process_list[0].frequency[i], process_list[0].frequency[i])) * pow(1 - Calculate_Reliable(t_it->second.wcet, f_max), r_num - 1);
				}
				min_rel *= now_rel;
				t_it++;
			}

			if (min_rel >= globle_reliability)
			{
				if (!out_degree_ods_part_scheduling(process_list[0].frequency[i], r_num))
				{
					for (int j = 0; j < process_list.size(); j++)
					{
						process_list[j].pt.clear();
						process_list[j].next_start_time = -1.00;
						process_list[j].ready_time = 0.00;
					}
				}
				else
				{
					return true;
				}
			}

		}
		r_num++;
	}
	return false;
}

bool EFR_Schedule::out_degree_ods_part_scheduling(double p_f, int r_num)
{
	vector<pair<string, double>> down_list = downward_task_list;
	double reliability = pow(globle_reliability, 1.0 / task_map.size());
	int optimal_l = 0;
	double min_end_time = -1.00;
	for (int l = 0; l < task_map.size(); l++)
	{
		for (int i = 0; i < process_list.size(); i++)
		{
			process_list[i].pt.clear();
			process_list[i].ready_time = 0.00;
		}
		double task_end_time = -1.00;
		for (int i = 0; i < down_list.size(); i++)
		{
			task_map[down_list[i].first].replica_start_time.clear();
			//int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, p_f);
			int now_replica_num = r_num;
			task_replica_number[down_list[i].first] = now_replica_num;
			if (now_replica_num == -1)
			{
				cout << "replica num false task id: " << down_list[i].first << endl;
				return false;
			}
			task_start_time new_ts = divide_degree_process(down_list[i].first, 0, p_f, 0, l);
			task_map[down_list[i].first].replica_start_time.push_back(new_ts);
			for (int j = 1; j < now_replica_num; j++)
			{
				task_start_time	new_ts = divide_degree_process(down_list[i].first, j, f_max, 0, l);
				task_map[down_list[i].first].replica_start_time.push_back(new_ts);
			}
			double now_end_time = task_map[down_list[i].first].replica_start_time[now_replica_num - 1].finish_time;
			now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].finish_time);
			if (task_end_time == -1.00 || task_end_time < now_end_time)
				task_end_time = now_end_time;
		}
		if (min_end_time == -1.00 || task_end_time < min_end_time)
		{
			min_end_time = task_end_time;
			optimal_l = l;
		}

	}
	//cout << "optimal_l: " << optimal_l << endl;
	for (int i = 0; i < process_list.size(); i++)
	{
		process_list[i].pt.clear();
		process_list[i].ready_time = 0.00;
	}

	for (int i = 0; i < down_list.size(); i++)
	{
		task_map[down_list[i].first].replica_start_time.clear();
		//int now_replica_num = Calculate_replica_number(down_list[i].first, reliability, p_f);
		int now_replica_num = r_num;
		task_replica_number[down_list[i].first] = now_replica_num;
		if (now_replica_num == -1)
		{
			cout << "replica num false task id: " << down_list[i].first << endl;
			return false;
		}
		task_start_time new_ts = divide_degree_process(down_list[i].first, 0, p_f, 0, optimal_l);
		task_map[down_list[i].first].replica_start_time.push_back(new_ts);
		for (int j = 1; j < now_replica_num; j++)
		{
			task_start_time	new_ts = divide_degree_process(down_list[i].first, j, f_max, 0, optimal_l);
			task_map[down_list[i].first].replica_start_time.push_back(new_ts);
		}
		double now_end_time = task_map[down_list[i].first].replica_start_time[now_replica_num - 1].finish_time;
		now_end_time = max(now_end_time, task_map[down_list[i].first].replica_start_time[0].finish_time);
		if (now_end_time > task_map[down_list[i].first].deadline)
		{
			//cout << "excced deadline" << endl;
			//cout << "Heft_exceed_deadline: " << down_list[i].first << "now end time: " << now_end_time << "deadline: " << task_map[down_list[i].first].deadline << endl;
			return false;
		}
	}
	return true;
}

void EFR_Schedule::Calculate_OD()
{
	map<string, task>::iterator m_it = task_map.begin();
	while (m_it != task_map.end())
	{
		OD[m_it->first] = m_it->second.successors_node.size();
		m_it++;
	}
	
	map<string, int>::iterator m_od = OD.begin();
	while (m_od != OD.end())
	{
		pair<string, int> odq;
		odq.first = m_od->first;
		odq.second = m_od->second;
		ODQ.push_back(odq);
		m_od++;
	}
	sort(ODQ.begin(), ODQ.end(), cmp_degree);



}

int EFR_Schedule::get_ODQ_number(string task_id)
{
	for (int i = 0; i < ODQ.size(); i++)
	{
		if (ODQ[i].first == task_id)
			return i;
	}
	return -1;
}

bool EFR_Schedule::milp_schedule(string milpfile)
{
	ifstream mf(milpfile);
	if (!mf.is_open())
	{
		cout << "未成功打开milp文件: " << milpfile << endl;
		return false;
	}
	string temp;
	int  k = 0;
	while (getline(mf, temp))
	{
		k++;
		vector<string> milp_temp;
		SplitString(temp, milp_temp, " ");
		string t_id = to_string(atoi(milp_temp[0].c_str()) + 1);
		int pid = atoi(milp_temp[1].c_str()) - 1;
		//cout << "pid: " << pid << endl;
		double f = atof(milp_temp[2].c_str());
		double start_time = atof(milp_temp[3].c_str());
		double finish_time = atof(milp_temp[4].c_str());
		int num_tid = atoi(t_id.c_str());
		bool has_find = false;
		if (num_tid <= task_map.size())
		{
			process_task new_pt;
			new_pt.task_id = t_id;
			new_pt.f = f;
			new_pt.start_time = start_time;
			new_pt.finish_time = finish_time;
			new_pt.task_state = 0;
			for (int i = 0; i < process_list[pid].pt.size(); i++)
			{
				if (process_list[pid].pt[i].start_time < start_time)
					continue;
				else
				{
					process_list[pid].pt.insert(process_list[pid].pt.begin() + i, new_pt);
					has_find = true;
					break;
				}
			}
			if (!has_find)
			{
				process_list[pid].pt.push_back(new_pt);
			}
			task_start_time new_ts;
			new_ts.f = f;
			new_ts.process_id = pid;
			new_ts.start_time = start_time;
			task_map[t_id].replica_start_time.push_back(new_ts);
			task_replica_number[t_id] = 1;
		}
		else
		{
			int task_state = num_tid / task_map.size();
			int now_id = num_tid % task_map.size();
			if (now_id == 0)
			{
				now_id = now_id + task_map.size();
				task_state = task_state - 1;
			}
			t_id = to_string(now_id);
			has_find = false;
			process_task new_pt;
			new_pt.task_id = t_id;
			new_pt.f = f;
			new_pt.start_time = start_time;
			new_pt.finish_time = finish_time;
			new_pt.task_state = task_state;
			for (int i = 0; i < process_list[pid].pt.size(); i++)
			{
				if (process_list[pid].pt[i].start_time < start_time)
					continue;
				else
				{
					process_list[pid].pt.insert(process_list[pid].pt.begin() + i, new_pt);
					has_find = true;
					break;
				}
			}
			if (!has_find)
			{
				process_list[pid].pt.push_back(new_pt);
			}
			task_start_time new_ts;
			new_ts.f = f;
			new_ts.process_id = pid;
			new_ts.start_time = start_time;
			task_map[t_id].replica_start_time.push_back(new_ts);
			task_replica_number[t_id]++;
		}
		//cout << "pid: " << pid << " psize: " << process_list[pid].pt.size() << endl;
		//cout << "k:" << k << endl;
	}
	mf.close();
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		t_it->second.optimal_replica_time = t_it->second.replica_start_time;
		t_it++;
	}
	cout << "milp finish" << endl;
	return true;

}


double EFR_Schedule::heft_static_run()
{
	vector<double> process_ready_time;
	vector<process> run_process_list = heft_process_list;
	srand((unsigned)time(NULL));
	for (int i = 0; i < heft_process_list.size(); i++)
	{
		if (heft_process_list[i].pt.empty())
			continue;
		process_ready_time.push_back(heft_process_list[i].pt[0].start_time);
	}
	double min_st = -1;
	int run_pid = 0;
	while (!process_ready_time.empty())
	{
		//cout << "c1: "<<  endl;
		for (int i = 0; i < process_ready_time.size(); i++)
		{
			if (i == 0)
			{
				min_st = process_ready_time[i];
				run_pid = i;
			}
			else if (process_ready_time[i] < min_st)
			{
				min_st = process_ready_time[i];
				run_pid = i;
			}
		}
		//cout << "c2: " << run_pid << " process ready time "<< process_ready_time[run_pid] << endl;
		string run_task_id = run_process_list[run_pid].pt[0].task_id;
		double run_f = run_process_list[run_pid].pt[0].f;
		//cout << "c3: " << endl;
		if (task_finish[run_task_id].finish)
		{
			if (task_finish[run_task_id].ftime <= min_st)
			{
				run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
				if (run_process_list[run_pid].pt.empty())
				{
					process_ready_time.erase(process_ready_time.begin() + run_pid);
					run_process_list.erase(run_process_list.begin() + run_pid);
				}
				else
				{
					process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
				}
			}
			else
			{
				double run_time;
				double wc = task_map[run_task_id].wcet / run_f;
				double bc = wc * bc_wc_radio;
				run_time = bc + (wc - bc) * ((double)(rand() % 101) / 100);

				/*
				double now_run_time;
				double wc = task_map[run_task_id].wcet / run_f;
				double bc = wc * bc_wc_radio;
				double mu = (wc + bc) / 2;
				double sigma = (wc - bc) / 6;
				normal_distribution<> norm{ mu, sigma };
				random_device rd;
				default_random_engine rng{ rd() };
				now_run_time = norm(rng);
				if (now_run_time < bc)
					now_run_time = bc;
				else if (now_run_time > wc)
					now_run_time = wc;
					*/
				task_energy_cost[run_task_id] += Calculate_Energy(run_time, run_f);
				run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
				if (run_process_list[run_pid].pt.empty())
				{
					process_ready_time.erase(process_ready_time.begin() + run_pid);
					run_process_list.erase(run_process_list.begin() + run_pid);
				}
				else
				{
					process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
				}
			}
		}
		else
		{
			double now_reliable = Calculate_Reliable(task_map[run_task_id].wcet / run_f, run_f);
			double run_time = 0.0;
			double wc = task_map[run_task_id].wcet / run_f;
			double bc = wc * bc_wc_radio;
			run_time = bc + (wc - bc) * ((double)(rand() % 101) / 100);
			/*
			double now_run_time;
			double wc = task_map[run_task_id].wcet / run_f;
			double bc = wc * bc_wc_radio;
			double mu = (wc + bc) / 2;
			double sigma = (wc - bc) / 6;
			normal_distribution<> norm{ mu, sigma };
			random_device rd;
			default_random_engine rng{ rd() };
			now_run_time = norm(rng);
			if (now_run_time < bc)
				now_run_time = bc;
			else if (now_run_time > wc)
				now_run_time = wc;
				*/
			if ((double)(rand() % 10000000) / 10000000 < now_reliable || task_finish[run_task_id].false_time == task_replica_number[run_task_id] - 1)
			{
				task_finish[run_task_id].finish = true;
				task_finish[run_task_id].ftime = process_ready_time[run_pid] + run_time;
			}
			else
			{
				task_finish[run_task_id].false_time++;
			}
			task_energy_cost[run_task_id] += Calculate_Energy(run_time, run_f);
			run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
			if (run_process_list[run_pid].pt.empty())
			{
				process_ready_time.erase(process_ready_time.begin() + run_pid);
				run_process_list.erase(run_process_list.begin() + run_pid);
			}
			else
			{
				process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
			}
		}
		//task_reliable[run_task_id] += Calculate_Reliable(task_map[run_task_id].wcet/run_f, run_f);
		//cout << "process read time size: " << process_ready_time.size() << endl;

	}
	//map<string,double>::iterator it_tr = task_reliable.begin();
	map<string, double>::iterator it_te = task_energy_cost.begin();
	double globle_reliable = 1.00;
	double globle_energy = 0.00;
	/*while(it_tr != task_reliable.end())
	{
		globle_reliable *= it_tr->second;
		it_tr++;
	}*/

	while (it_te != task_energy_cost.end())
	{
		globle_energy += it_te->second;
		it_te++;
	}

	//cout << "heft energy cost: " << globle_energy << endl;
	return globle_energy;
}

double EFR_Schedule::static_run()
{
	vector<double> process_ready_time;
	vector<process> run_process_list = process_list;
	srand((unsigned)time(NULL));
	for (int i = 0; i < run_process_list.size(); i++)
	{
		if (run_process_list[i].pt.empty())
		{
			run_process_list.erase(run_process_list.begin() + i);
			i--;
		}
		else
		{
			process_ready_time.push_back(run_process_list[i].pt[0].start_time);
		}
	}
	double min_st = -1;
	int run_pid = 0;
	while (!process_ready_time.empty())
	{
		//cout << "c1: "<<  endl;
		for (int i = 0; i < process_ready_time.size(); i++)
		{
			if (i == 0)
			{
				min_st = process_ready_time[i];
				run_pid = i;
			}
			else if (process_ready_time[i] < min_st)
			{
				min_st = process_ready_time[i];
				run_pid = i;
			}
		}
		//cout << "c2: " << run_pid << " process ready time "<< process_ready_time[run_pid] << endl;
		string run_task_id = run_process_list[run_pid].pt[0].task_id;
		double run_f = run_process_list[run_pid].pt[0].f;
		//cout << "c3: " << endl;
		if (task_finish[run_task_id].finish)
		{
			if (task_finish[run_task_id].ftime <= min_st)
			{
				run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
				if (run_process_list[run_pid].pt.empty())
				{
					process_ready_time.erase(process_ready_time.begin() + run_pid);
					run_process_list.erase(run_process_list.begin() + run_pid);
				}
				else
				{
					process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
				}
			}
			else
			{
				double run_time;
				double wc = task_map[run_task_id].wcet / run_f;
				double bc = wc * bc_wc_radio;
				run_time = bc + (wc - bc) * ((double)(rand() % 101) / 100);
				/*
				double now_run_time;
				double wc = task_map[run_task_id].wcet / run_f;
				double bc = wc * bc_wc_radio;
				double mu = (wc + bc) / 2;
				double sigma = (wc - bc) / 6;
				normal_distribution<> norm{ mu, sigma };
				random_device rd;
				default_random_engine rng{ rd() };
				now_run_time = norm(rng);
				if (now_run_time < bc)
					now_run_time = bc;
				else if (now_run_time > wc)
					now_run_time = wc;
					*/
				task_energy_cost[run_task_id] += Calculate_Energy(run_time, run_f);
				run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
				if (run_process_list[run_pid].pt.empty())
				{
					process_ready_time.erase(process_ready_time.begin() + run_pid);
					run_process_list.erase(run_process_list.begin() + run_pid);
				}
				else
				{
					process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
				}
			}
		}
		else
		{
			double run_time;
			double wc = task_map[run_task_id].wcet / run_f;
			double bc = wc * bc_wc_radio;
			run_time = bc + (wc - bc) * ((double)(rand() % 101) / 100);

			/*
			double now_run_time;
			double wc = task_map[run_task_id].wcet / run_f;
			double bc = wc * bc_wc_radio;
			double mu = (wc + bc) / 2;
			double sigma = (wc - bc) / 6;
			normal_distribution<> norm{ mu, sigma };
			random_device rd;
			default_random_engine rng{ rd() };
			now_run_time = norm(rng);
			if (now_run_time < bc)
				now_run_time = bc;
			else if (now_run_time > wc)
				now_run_time = wc;
				*/
			double wf = run_time;
			double now_reliable = Calculate_Reliable(wf, run_f);
			//double now_reliable = 0.99;
			//now_reliable = 0.99;
			if ( (double)(rand() % 10000000)/10000000 < now_reliable || task_finish[run_task_id].false_time == task_replica_number[run_task_id] - 1 )
			{
				task_finish[run_task_id].finish = true;
				task_finish[run_task_id].ftime = process_ready_time[run_pid] + wf;
			}
			else
			{
				task_finish[run_task_id].false_time++;
			}
			task_energy_cost[run_task_id] += Calculate_Energy(wf, run_f);
			run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
			if (run_process_list[run_pid].pt.empty())
			{
				process_ready_time.erase(process_ready_time.begin() + run_pid);
				run_process_list.erase(run_process_list.begin() + run_pid);
			}
			else
			{
				process_ready_time[run_pid] = run_process_list[run_pid].pt[0].start_time;
			}
		}
		//task_reliable[run_task_id] += Calculate_Reliable(task_map[run_task_id].wcet/run_f, run_f);
		//cout << "process read time size: " << process_ready_time.size() << endl;

	}
	//map<string,double>::iterator it_tr = task_reliable.begin();
	map<string, double>::iterator it_te = task_energy_cost.begin();
	double globle_reliable = 1.00;
	double globle_energy = 0.00;
	/*while(it_tr != task_reliable.end())
	{
		globle_reliable *= it_tr->second;
		it_tr++;
	}*/

	while (it_te != task_energy_cost.end())
	{
		globle_energy += it_te->second;
		it_te++;
	}

	//cout << "static energy cost: " << globle_energy << endl;
	return globle_energy;
}

double EFR_Schedule::dynamic_run()
{
	vector<process_time> process_ready_time;
	vector<process> run_process_list = process_list;
	srand((unsigned)time(NULL));
	for (int i = 0; i < process_list.size(); i++)
	{
		if (process_list[i].pt.empty())
			continue;
		process_time p_time;
		p_time.time = process_list[i].pt[0].start_time;
		p_time.finish_time = process_list[i].pt[0].finish_time;
		p_time.start_time = process_list[i].pt[0].start_time;
		if (p_time.finish_time - p_time.start_time < 0)
			cout << "p time error" << endl;
		p_time.p_id = i;
		p_time.is_start = true;
		p_time.task_id = process_list[i].pt[0].task_id;
		p_time.f = process_list[i].pt[0].f;
		process_ready_time.push_back(p_time);
	}
	double min_time = -1;
	int run_pid = 0;
	while (!process_ready_time.empty())
	{
		sort(process_ready_time.begin(), process_ready_time.end(), cmp_time);
		if (process_ready_time[0].is_start)
		{
			double run_time;
			double wc = task_map[process_ready_time[0].task_id].wcet / process_ready_time[0].f;
			double bc = wc * bc_wc_radio;
			run_time = bc + (wc - bc) * ((double)(rand() % 101) / 100);

			/*
			double now_run_time;
			double wc = task_map[run_task_id].wcet / run_f;
			double bc = wc * bc_wc_radio;
			double mu = (wc + bc) / 2;
			double sigma = (wc - bc) / 6;
			normal_distribution<> norm{ mu, sigma };
			random_device rd;
			default_random_engine rng{ rd() };
			now_run_time = norm(rng);
			if (now_run_time < bc)
				now_run_time = bc;
			else if (now_run_time > wc)
				now_run_time = wc;
				*/
			process_ready_time[0].finish_time = process_ready_time[0].start_time + run_time;
			double end_time = process_ready_time[0].finish_time;
			process_ready_time[0].time = end_time;
			process_ready_time[0].is_start = false;
			continue;
		}
		else
		{
			//double run_time = task_map[process_ready_time[0].task_id].wcet / process_ready_time[0].f;
			double run_time = process_ready_time[0].finish_time - process_ready_time[0].start_time;
			double now_time = process_ready_time[0].time;
			string now_task_id = process_ready_time[0].task_id;
			int run_pid = process_ready_time[0].p_id;
			if (run_time < 0)
				cout << "dynamic runtime error " << endl;
			task_energy_cost[process_ready_time[0].task_id] += Calculate_Energy(run_time, process_ready_time[0].f);
			run_process_list[run_pid].pt.erase(run_process_list[run_pid].pt.begin());
			double now_reliable = Calculate_Reliable(run_time, process_ready_time[0].f);
			//double now_reliable = 0.99;
			//now_reliable = 0.99;
			if ((double)(rand()%10000000)/10000000 < now_reliable || task_finish[now_task_id].false_time == task_replica_number[now_task_id] - 1)
			{
				task_finish[now_task_id].finish = true;
				task_finish[now_task_id].ftime = now_time;
				task_finish[now_task_id].finish_pid = run_pid;
				int psize = process_ready_time.size();
				for (int i = 1; i < psize; i++)
				{
					if (process_ready_time[i].task_id == now_task_id)
					{
						if (process_ready_time[i].is_start)
						{
							run_process_list[process_ready_time[i].p_id].pt.erase(run_process_list[process_ready_time[i].p_id].pt.begin());
						}
						else
						{
							task_energy_cost[process_ready_time[i].task_id] += Calculate_Energy(now_time - run_process_list[process_ready_time[i].p_id].pt[0].start_time, process_ready_time[i].f);
							if (now_time - run_process_list[process_ready_time[i].p_id].pt[0].start_time < 0)
							{
								cout << "2 dynamic runtime error! now time: " << now_time << " start time: " << run_process_list[process_ready_time[i].p_id].pt[0].start_time << " process time: " << process_ready_time[i].start_time << endl;
								for (int t = 0; t < process_ready_time.size(); t++)
								{
									cout << process_ready_time[t].is_start << " " << process_ready_time[t].time << " " << process_ready_time[t].start_time << " " << process_ready_time[t].finish_time << endl;
								}
							}
								
							run_process_list[process_ready_time[i].p_id].pt.erase(run_process_list[process_ready_time[i].p_id].pt.begin());
						}
						if (run_process_list[process_ready_time[i].p_id].pt.empty())
						{
							process_ready_time.erase(process_ready_time.begin() + i);
							i--;
							psize--;
						}
						else
						{
							process_task new_pt = run_process_list[process_ready_time[i].p_id].pt[0];
							process_ready_time[i].task_id = new_pt.task_id;
							process_ready_time[i].is_start = true;
							process_ready_time[i].f = new_pt.f;
							process_ready_time[i].time = new_pt.start_time;
							process_ready_time[i].start_time = new_pt.start_time;
							process_ready_time[i].finish_time = new_pt.finish_time;
						}

					}
				}
			}
			else
			{
				task_finish[now_task_id].false_time++;
			}
			if (run_process_list[process_ready_time[0].p_id].pt.empty())
			{
				process_ready_time.erase(process_ready_time.begin());
			}
			else
			{
				process_task new_pt = run_process_list[process_ready_time[0].p_id].pt[0];
				process_ready_time[0].task_id = new_pt.task_id;
				process_ready_time[0].is_start = true;
				process_ready_time[0].f = new_pt.f;
				process_ready_time[0].time = new_pt.start_time;
				process_ready_time[0].start_time = new_pt.start_time;
				process_ready_time[0].finish_time = new_pt.finish_time;
			}
			bool has_change = true;
			while (has_change)
			{
				has_change = false;
				int psize = process_ready_time.size();
				for (int i = 0; i < psize; i++)
				{
					if (process_ready_time[i].is_start)
					{
						if (task_finish[process_ready_time[i].task_id].finish)
						{
							run_process_list[process_ready_time[i].p_id].pt.erase(run_process_list[process_ready_time[i].p_id].pt.begin());
							if (run_process_list[process_ready_time[i].p_id].pt.empty())
							{
								process_ready_time.erase(process_ready_time.begin() + i);
								i--;
								psize--;
							}
							else
							{
								process_task new_pt = run_process_list[process_ready_time[i].p_id].pt[0];
								process_ready_time[i].task_id = new_pt.task_id;
								process_ready_time[i].is_start = true;
								process_ready_time[i].f = new_pt.f;
								process_ready_time[i].time = new_pt.start_time;
								process_ready_time[i].start_time = new_pt.start_time;
								process_ready_time[i].finish_time = new_pt.finish_time;
							}
							has_change = true;
						}
						else
						{
							string present_task_id = process_ready_time[i].task_id;
							double present_start_time = process_ready_time[i].time;
							int present_process_id = process_ready_time[i].p_id;
							if (present_start_time <= now_time)
								continue;
							double max_p_st = 0.00;
							for (int j = 0; j < task_map[present_task_id].predecessors_node.size(); j++)
							{
								string pre_task_id = task_map[present_task_id].predecessors_node[j];
								if (task_finish[pre_task_id].finish && task_finish[pre_task_id].finish_pid == present_process_id && max_p_st < task_finish[pre_task_id].ftime)
								{
									max_p_st = task_finish[pre_task_id].ftime;
								}
								else if (task_finish[pre_task_id].finish && task_finish[pre_task_id].finish_pid != present_process_id && max_p_st < task_finish[pre_task_id].ftime + edge_communication[pre_task_id][present_task_id])
									max_p_st = task_finish[pre_task_id].ftime + edge_communication[pre_task_id][present_task_id];
								else if (!task_finish[pre_task_id].finish)
								{
									double end_time = task_map[pre_task_id].optimal_replica_time[task_map[pre_task_id].optimal_replica_time.size() - 1].finish_time;
									if (end_time + edge_communication[pre_task_id][present_task_id] > max_p_st)
										max_p_st = end_time + edge_communication[pre_task_id][present_task_id];
								}
							}

							double min_st = max(now_time, max_p_st);
							if (min_st > present_start_time)
								continue;

							int pre_id = -1;
							for (int j = 0; j < task_map[present_task_id].optimal_replica_time.size(); j++)
							{
								if (task_map[present_task_id].optimal_replica_time[j].process_id == present_process_id)
								{
									pre_id = j;
									break;
								}
							}
							if (pre_id == -1)
								continue;
							if (pre_id == 0)
							{
								if (min_st < present_start_time)
								{
									/*if (present_task_id == "merge_gcvf_00000295")
									{
										cout << "present_start_time: " << present_start_time << " min_st" << min_st << endl;
										for (int j = 0; j < task_map[present_task_id].optimal_replica_time.size(); j++)
										{
											cout << "!!!!!!: " << task_map[present_task_id].optimal_replica_time[j].start_time << " ";
										}
										cout << endl;
									}*/
									bool a = false;
									for (int j = 1; j < task_map[present_task_id].optimal_replica_time.size(); j++)
									{
										if (task_map[present_task_id].optimal_replica_time[j].start_time < present_start_time)
										{
											a = true;
											cout << "!!!!!: " << task_finish[present_task_id].finish << " " << present_start_time << " " << task_map[present_task_id].optimal_replica_time[0].start_time << " " << task_map[present_task_id].optimal_replica_time[j].start_time << endl;
										}
									}
									if (a == true)
									{
										cout << "??????????: " << present_task_id << endl;
										for (int j = 0; j < task_map[present_task_id].optimal_replica_time.size(); j++)
										{
											cout << task_map[present_task_id].optimal_replica_time[j].process_id << " " << task_map[present_task_id].optimal_replica_time[j].start_time << " " << task_map[present_task_id].optimal_replica_time[j].f << endl;
										}
									}
									double move_forward_time = process_ready_time[i].start_time - min_st;
									process_ready_time[i].time = min_st;
									process_ready_time[i].finish_time -= move_forward_time;
									process_ready_time[i].start_time = min_st;
									if (process_ready_time[i].finish_time - process_ready_time[i].start_time < 0)
										cout << "p1 runtime < 0 " << endl;
									task_map[present_task_id].optimal_replica_time[pre_id].start_time = min_st;
									task_map[present_task_id].optimal_replica_time[pre_id].finish_time = process_ready_time[i].finish_time;
									run_process_list[present_process_id].pt[0].start_time = min_st;
									run_process_list[present_process_id].pt[0].finish_time = process_ready_time[i].finish_time;
									has_change = true;
								}
								//continue;
							}
							else
							{
								double pre_end_time = task_map[present_task_id].optimal_replica_time[pre_id - 1].finish_time;
								if (pre_end_time < present_start_time)
								{
									process_ready_time[i].time = pre_end_time;
									double move_forward_time = process_ready_time[i].start_time - pre_end_time;
									process_ready_time[i].finish_time -= move_forward_time;
									process_ready_time[i].start_time = pre_end_time;
									if (process_ready_time[i].finish_time - process_ready_time[i].start_time < 0)
									{
										cout << "p2 runtime < 0 " << endl;
										cout << process_ready_time[i].finish_time << " " << move_forward_time << " " << pre_end_time << endl;
									}
										
									task_map[present_task_id].optimal_replica_time[pre_id].start_time = pre_end_time;
									task_map[present_task_id].optimal_replica_time[pre_id].finish_time = process_ready_time[i].finish_time;
									run_process_list[present_process_id].pt[0].start_time = pre_end_time;
									run_process_list[present_process_id].pt[0].finish_time = process_ready_time[i].finish_time;
									has_change = true;
								}
								//continue;
							}


						}
					}
				}
			}



		}
	}

	map<string, double>::iterator it_te = task_energy_cost.begin();
	double globle_energy = 0.00;

	while (it_te != task_energy_cost.end())
	{
		globle_energy += it_te->second;
		it_te++;
	}
	//cout << "dynamic energy cost: " << globle_energy << endl;
	return globle_energy;
}

int EFR_Schedule::output_add_additional_replica_num()
{
	return add_additional_replica_number;
}

int EFR_Schedule::show_can_add_additional()
{
	return can_add_additional;
}

void EFR_Schedule::Display_schedule()
{
	for (int i = 0; i < process_list.size(); i++)
	{
		cout << "----------------------------------------------" << endl;
		cout << "Process " << i << ":";
		for (int j = 0; j < process_list[i].pt.size(); j++)
		{
			cout << "[" << process_list[i].pt[j].task_id << "," << process_list[i].pt[j].start_time << "," << process_list[i].pt[j].finish_time << "," << process_list[i].pt[j].f << "] ";
		}
		cout << endl;
	}
}

void EFR_Schedule::Display_heft_schedule()
{
	for (int i = 0; i < process_list.size(); i++)
	{
		cout << "----------------------------------------------" << endl;
		cout << "Heft Process " << i << ":";
		for (int j = 0; j < heft_process_list[i].pt.size(); j++)
		{
			cout << "[" << heft_process_list[i].pt[j].task_id << "," << heft_process_list[i].pt[j].start_time << "," << heft_process_list[i].pt[j].f << "] ";
		}
		cout << endl;
	}
}

void EFR_Schedule::Display_layer()
{
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		cout << "task id:" << t_it->first << " lay_num: " << t_it->second.layer << endl;
		t_it++;
	}
}

void EFR_Schedule::Display_energy()
{
	return ;
}

void EFR_Schedule::Display_replica_num()
{
	map<string, int>::iterator r_it = task_replica_number.begin();
	while (r_it != task_replica_number.end())
	{
		cout << "task id:" << r_it->first << " rep_num: " << r_it->second << endl;
		r_it++;
	}
}

void EFR_Schedule::Display_optimal_replica()
{
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		cout << "task id:" << t_it->first << " optimal_relica_num: " << t_it->second.optimal_replica_time.size() << endl;
		t_it++;
	}
}

void EFR_Schedule::Display_task_time(string task_id)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		for (int j = 0; j < process_list[i].pt.size(); j++)
		{
			if (process_list[i].pt[j].task_id == task_id)
				cout << "Process " << i << " [" << process_list[i].pt[j].task_id << "," << process_list[i].pt[j].start_time << "," << process_list[i].pt[j].f << "] ";
		}
		cout << endl;
	}
}

void EFR_Schedule::Display_Deadline()
{
	for (int i = 0; i < downward_task_list.size(); i++)
	{
		cout << "task id:" << downward_task_list[i].first << " deadline: " << task_map[downward_task_list[i].first].deadline << endl;
	}
}

void EFR_Schedule::Display_edge()
{
	map<string, map<string, double>>::iterator e_it_1 = edge_communication.begin();
	while (e_it_1 != edge_communication.end())
	{
		map<string, double>::iterator e_it_2 = e_it_1->second.begin();
		while (e_it_2 != e_it_1->second.end())
		{
			cout << e_it_1->first << "-->" << e_it_2->first << ":" << e_it_2->second << endl;
			e_it_2++;
		}
		e_it_1++;
	}
}

void EFR_Schedule::Display_frequency(string filename)
{
	ofstream out(filename, ios::app);
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		out << t_it->second.replica_start_time[0].f << " " << t_it->second.replica_start_time.size() << " " << t_it->second.has_change_replica << endl;
		t_it++;
	}
	out.close();
}

void EFR_Schedule::Display_frequency_list(string filename)
{
	ofstream out(filename, ios::app);
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		out << t_it->first << " ";
		out << t_it->second.has_change_replica << " ";
		for (int i = 0; i < t_it->second.replica_start_time.size(); i++)
		{
			out << t_it->second.replica_start_time[i].start_time << " " << t_it->second.replica_start_time[i].process_id << " ";
		}
		out << endl;
		t_it++;
	}
	out.close();
}

void EFR_Schedule::Display_optimal_frequency(string filename)
{
	ofstream out(filename, ios::app);
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		int r_max = Calculate_replica_number(t_it->first, single_reliability, f_max);
		int r_opt = Calculate_replica_number(t_it->first, single_reliability, t_it->second.opt_frequency);
		out << t_it->second.opt_frequency << " " << t_it->second.replica_start_time.size() << " " << t_it->second.has_change_replica << " rmax: " << r_max << " ropt: " << r_opt << endl;
		t_it++;
	}
	out.close();
}

void EFR_Schedule::check_schedule()
{
	map<string, task>::iterator t_it = task_map.begin();
	while (t_it != task_map.end())
	{
		for (int i = 0; i < t_it->second.replica_start_time.size(); i++)
		{
			if (t_it->second.replica_start_time[i].start_time > t_it->second.replica_start_time[i].finish_time)
				cout << "check error !!!!" << endl;
		}
		t_it++;
	}

	for (int i = 0; i < process_list.size(); i++)
	{
		for (int j = 0; j < process_list[i].pt.size(); j++)
		{
			if (j < process_list[i].pt.size() - 1)
			{
				if (process_list[i].pt[j].start_time > process_list[i].pt[j + 1].start_time)
				{
					cout << "process cmp error" << endl;
					cout << j << " " << process_list[i].pt[j].start_time << " " << process_list[i].pt[j + 1].start_time << endl;
				}
				if (process_list[i].pt[j].finish_time > process_list[i].pt[j + 1].start_time)
					cout << "overlapping error" << endl;
			}
			if (process_list[i].pt[j].finish_time - process_list[i].pt[j].start_time < 0)
				cout << "process list error " << endl;
		}
	}

}

void EFR_Schedule::set_radio(string radio)
{
	bc_wc_radio = atof(radio.c_str());
}

void EFR_Schedule::output_schedule(string output_filename)
{
	for (int i = 0; i < process_list.size(); i++)
	{
		cout << "----------------------------------------------" << endl;
		cout << "Process " << i << ":";
		for (int j = 0; j < process_list[i].pt.size(); j++)
		{
			cout << "[" << process_list[i].pt[j].task_id << "," << process_list[i].pt[j].start_time << "," << process_list[i].pt[j].f << "] ";
		}
		cout << endl;
	}

	/*for (int i = 0; i < process_list.size(); i++)
	{

	}*/

}


