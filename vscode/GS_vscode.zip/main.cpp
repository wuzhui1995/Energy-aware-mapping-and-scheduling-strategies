#include <iostream>
#include "EFR_Schedule.h"
#include <algorithm>
#include <fstream>
using namespace std;



int main(int argc, char **argv)
{
	if (argc < 3)
	{
		cout << "error parameter" << endl;
		return -1;
	}
	vector<double> frequncy;
	vector<double> ccr_list;
	ccr_list.push_back(1.00);
	ccr_list.push_back(0.1);
	ccr_list.push_back(0.01);
	ccr_list.push_back(0.003);
	ccr_list.push_back(0.001);
	ccr_list.push_back(0.0003);

	/*frequncy.push_back(1.00);
	frequncy.push_back(0.80);
	frequncy.push_back(0.60);
	frequncy.push_back(0.40);
	frequncy.push_back(0.15);*/


	/*frequncy.push_back(1.00);
	frequncy.push_back(0.90);
	frequncy.push_back(0.80);
	frequncy.push_back(0.70);
	frequncy.push_back(0.60);
	frequncy.push_back(0.50);
	frequncy.push_back(0.40);
	frequncy.push_back(0.30);
	frequncy.push_back(0.20);
	frequncy.push_back(0.10);*/


	frequncy.push_back(1.00);
	frequncy.push_back(0.86);
	frequncy.push_back(0.71);
	frequncy.push_back(0.57);
	frequncy.push_back(0.46);
	frequncy.push_back(0.32);
	frequncy.push_back(0.21);

	/*frequncy.push_back(1.00);
	frequncy.push_back(0.844);
	frequncy.push_back(0.750);
	frequncy.push_back(0.633);
	frequncy.push_back(0.562);
	frequncy.push_back(0.50);
	frequncy.push_back(0.421);
	frequncy.push_back(0.375);
	frequncy.push_back(0.316);
	frequncy.push_back(0.281);
	frequncy.push_back(0.250);
	frequncy.push_back(0.211);*/

	EFR_Schedule es;
	//es.get_task_map(a, 10 ,w, 0.95);
	//es.inital_process(frequncy, 5);
	es.read_graph(argv[1], argv[2]);
	es.inital_process(frequncy, 8);
	
	//for (int c_num = 0; c_num < 6; c_num++)
	for (int c_num = 0; c_num < 1; c_num++)
	{
		es.change_ccr(ccr_list[c_num]);
		vector<double> rel_list = es.Calculate_Reliability_list(3);
		
		double min_rel = rel_list[0];
		for (int i = 0; i < 3; i++)
		{
			min_rel = min_rel * 0.9;
			rel_list.push_back(min_rel);
		}
		
		sort(rel_list.begin(), rel_list.end());
		for (int i = 0; i < 6; i++)
		{
			cout << rel_list[i] << endl;
		}
		//for (int i = 0; i < 3; i++)
		rel_list[3] = 0.9;
		rel_list[4] = 0.93;
		rel_list[5] = 0.96;
		for (int i = 3; i < 6; i++)
		{
			EFR_Schedule es1;
			es1.read_graph(argv[1], argv[2]);
			es1.inital_process(frequncy, 8);
			es1.set_reliability(rel_list[i]);
			vector<double> deadline_list = es1.Calculate_Deadline_list(5);
			for (int m = 0; m < 5; m++)
			{
				cout << "deadline: " << deadline_list[m] << endl;
			}
			//for (int j = 0; j < 5; j++)
			for (int j = 0; j < 5; j++)
			{
				EFR_Schedule es1;
				EFR_Schedule es2;
				EFR_Schedule es3;
				EFR_Schedule es4;
				EFR_Schedule es5;
				EFR_Schedule es6;
				EFR_Schedule es_ods;
				EFR_Schedule es_outdegree_ods;
				EFR_Schedule es_milp;

				EFR_Schedule nes1;

				es1.read_graph(argv[1], argv[2]);
				es1.inital_process(frequncy, 8);
				es1.set_reliability(rel_list[i]);
				es1.Calculate_Deadline_Priority(deadline_list[j]);
				es1.sort_task_with_priority();
				es1.set_radio(argv[3]);

				es2.read_graph(argv[1], argv[2]);
				es2.inital_process(frequncy, 8);
				es2.set_reliability(rel_list[i]);
				es2.Calculate_Deadline_Priority(deadline_list[j]);
				es2.sort_task_with_priority();
				es2.set_radio(argv[3]);

				es3.read_graph(argv[1], argv[2]);
				es3.inital_process(frequncy, 8);
				es3.set_reliability(rel_list[i]);
				es3.Calculate_Deadline_Priority(deadline_list[j]);
				es3.sort_task_with_priority();
				es3.set_radio(argv[3]);
				
				es4.read_graph(argv[1], argv[2]);
				es4.inital_process(frequncy, 8);
				es4.set_reliability(rel_list[i]);
				es4.Calculate_Deadline_Priority(deadline_list[j]);
				es4.sort_task_with_priority();
				es4.set_radio(argv[3]);

				es5.read_graph(argv[1], argv[2]);
				es5.inital_process(frequncy, 8);
				es5.set_reliability(rel_list[i]);
				es5.Calculate_Deadline_Priority(deadline_list[j]);
				es5.sort_task_with_priority();
				es5.set_radio(argv[3]);

				es6.read_graph(argv[1], argv[2]);
				es6.inital_process(frequncy, 8);
				es6.set_reliability(rel_list[i]);
				es6.Calculate_Deadline_Priority(deadline_list[j]);
				es6.sort_task_with_priority();
				es6.set_radio(argv[3]);


				nes1.read_graph(argv[1], argv[2]);
				nes1.inital_process(frequncy, 8);
				nes1.set_reliability(rel_list[i]);
				nes1.Calculate_Deadline_Priority(deadline_list[j]);
				nes1.sort_task_with_priority();
				nes1.set_radio(argv[3]);

				es_ods.read_graph(argv[1], argv[2]);
				es_ods.inital_process(frequncy, 8);
				es_ods.set_reliability(rel_list[i]);
				es_ods.Calculate_Deadline_Priority(deadline_list[j]);
				es_ods.sort_task_with_priority();
				es_ods.set_radio(argv[3]);

				es_outdegree_ods.read_graph(argv[1], argv[2]);
				es_outdegree_ods.inital_process(frequncy, 8);
				es_outdegree_ods.set_reliability(rel_list[i]);
				es_outdegree_ods.Calculate_Deadline_Priority(deadline_list[j]);
				es_outdegree_ods.sort_task_with_priority();
				es_outdegree_ods.set_radio(argv[3]);

				es_milp.read_graph(argv[1], argv[2]);
				es_milp.inital_process(frequncy, 8);
				es_milp.set_reliability(rel_list[i]);
				es_milp.Calculate_Deadline_Priority(deadline_list[j]);
				es_milp.sort_task_with_priority();
				es_milp.set_radio(argv[3]);


				if (es1.Heft_scheduing())
				{
					cout << "heft_scheduing true" << endl;
					es1.scheduing();
					es1.check_schedule();
					
					cout << "scheduing true------------------------" << endl;
					//es1.Display_schedule();
					//es.Display_optimal_replica();
					//es1.optimization();
					//es1.Display_schedule();
					es1.another_optimization();
					es1.check_schedule();
					cout << "optimization true" << endl;
					//es1.Display_schedule();
					//es1.Display_frequency_list("es1.txt");
					es2.partial_scheduling();
					es2.check_schedule();
					cout << "partial scheduing true------------------------" << endl;
					//es2.optimization();
					es2.another_optimization();
					es2.check_schedule();
					cout << "partial optimization true" << endl;

					es3.add_scheduling();
					es3.check_schedule();
					cout << "add scheduing true------------------------" << endl;
					//es3.Display_schedule();
					es3.choose_layer();
					es3.check_schedule();
					cout << "add choose true------------------------" << endl;
					//int y = es3.Calculate_task_num2();
					//es3.Display_schedule();
					//es2.Display_schedule();
					//es3.optimization();
					es3.another_optimization();
					es3.check_schedule();
					cout << "add optimization true------------------------" << endl;
					
					//cout << "add layer optimization true------------------------" << endl;
					//es1.Display_schedule();
					//es1.Display_heft_schedule();
					//es1.Display_replica_num();
					//es1.Display_task_time("GEMM_8_1_0");
					//cout << "finish display" << endl;

					es4.decrease_scheduling();
					es4.check_schedule();
					
					cout << "decrease scheduling successful-------------------------" << endl;
					es4.decrease_another_optimization();
					es4.check_schedule();
					cout << "decrease optimization successful-------------------------" << endl;
					//es4.Display_schedule();
					es5.add_scheduling();
					es5.check_schedule();
					bool b = false;
					cout << "es5: " << es5.choose_all_layer() << endl;

					int x = es5.Calculate_task_num();
					cout << "x: " << x << endl;
					es5.check_schedule();
					cout << "final scheduing true------------------------" << endl;	
					//es5.optimization();
					es5.another_optimization();
					es5.check_schedule();
					cout << "final optimization true------------------------" << endl;
					nes1.non_layer_scheduling();
					nes1.check_schedule();
					cout << "nes1 scheduling true ----------------" << endl;
					nes1.optimization();
					nes1.check_schedule();
					cout << "nes1 optimization true ----------------" << endl;
					
					es_ods.ods_scheduling();
					es_ods.check_schedule();
					cout << "ods scheduling true ----------------" << endl;
					//es_ods.ods_optimization();
					es_ods.check_schedule();
					cout << "ods optimization true ----------------" << endl;

					es_outdegree_ods.out_degree_ods_scheduling();
					es_outdegree_ods.check_schedule();
					cout << "outdegree scheduling true ----------------" << endl;
					//es_ods.ods_optimization();
					//es_ods.check_schedule();
					cout << "outdegree optimization true ----------------" << endl;

					string nodename = argv[1];
					nodename.pop_back();
					nodename.pop_back();
					nodename.pop_back();
					nodename.pop_back();
					string milpfile = "MILP_f2_node_" + nodename + "_" + to_string(i - 3) + "_" + to_string(j + 1) + ".txt";
					es_milp.milp_schedule(milpfile);
					

					//es6.add_scheduling();
					//es6.choose_single_task();
					//es6.optimization();
					//es6.add_scheduling();
					//es6.another_choose_all_layer();
					//es6.new_optimization();
					//cout << "xxx" << endl;
					/*string n = argv[1];
					string on = "output_energy_" + n;
					ofstream ont(on, ios::app);
					//output << ccr_list[c_num] << " " << rel_list[i] << " " << deadline_list[j] << " " << (double)heft_energy / 100 << " " << (double)static_energy / 100 << " " << (double)dynamic_energy / 100 << endl;
					//ont << x << " " << es5.Calculate_task_num() << " " << es2.Calculate_task_num() << " " << es3.Calculate_task_num() << " " << y << endl;
					//ont << es1.Calculate_task_num2() << " " << es3.Calculate_task_num2() << " " << es5.Calculate_task_num2() << endl;
					ont << es1.Calculate_overlapping() << " " << es2.Calculate_overlapping() << " " << es3.Calculate_overlapping() << " " << es4.Calculate_overlapping() << " " << es5.Calculate_overlapping() << endl;
					ont << es1.Calculate_primary_energy() << " " << es2.Calculate_primary_energy() << " " << es3.Calculate_primary_energy() << " " << es4.Calculate_primary_energy() << " " << es5.Calculate_primary_energy() << endl;
					ont << es1.Calculate_real_energy() << " " << es2.Calculate_real_energy() << " " << es3.Calculate_real_energy() << " " << es4.Calculate_real_energy() << " " << es5.Calculate_real_energy() << endl;
					ont.close();*/
					
					
					//es1.Display_frequency("es1.txt");
					//es4.Display_frequency("es4.txt");
					//es5.Display_frequency("es5.txt");
					//es6.Display_frequency("es6.txt");

					//es1.Display_frequency("es1.txt");
					//nes1.Display_frequency("nes1.txt");
					
					//int add_additional_replica_num = es1.output_add_additional_replica_num();
					//int can_add_additional = es1.show_can_add_additional();
					double static_energy = 0.00;
					double dynamic_energy = 0.00;
					double heft_energy = 0.00;
					double partial_static_energy = 0.00;
					double partial_dynamic_energy = 0.00;
					double add_static_energy = 0.00;
					double add_dynamic_energy = 0.00;
					double decrease_static_energy = 0.00;
					double decrease_dynamic_energy = 0.00;
					double a_s = 0.00;
					double a_d = 0.00;
					double another_s = 0.00;
					double another_d = 0.00;
					double nes1_s_energy = 0.00;
					double nes1_d_energy = 0.00;
					double ods_s = 0.00;
					double ods_d = 0.00;
					double out_ods_s = 0.00;
					double out_ods_d = 0.00;
					double milp_s = 0.00;
					double milp_d = 0.00;
					int times = 2000;
					//nes1.Display_schedule();

					//cout << "****************************************************" << endl;
					//es1.Display_schedule();
					

					for (int i = 0; i < times; i++)
					{
						heft_energy += es1.heft_static_run();
						es1.clear_task_energy();
						cout << "heft static" << endl;
						//es1.Display_schedule();
						static_energy += es1.static_run();
						//cout << "es1 static" << endl;
						es1.clear_task_energy();
						dynamic_energy += es1.dynamic_run();
						//cout << "es1 dynamic" << endl;
						es1.clear_task_energy();
						//cout << "aaa" << endl;

						/*nes1_s_energy += nes1.static_run();
						nes1.clear_task_energy();
						//cout << "bbb" << endl;
						nes1_d_energy += nes1.dynamic_run();
						nes1.clear_task_energy();*/
						
						partial_static_energy += es2.static_run();
						//cout << "es2 static" << endl;
						es2.clear_task_energy();
						partial_dynamic_energy += es2.dynamic_run();
						//cout << "es2 dynamic" << endl;
						es2.clear_task_energy();

						add_static_energy += es3.static_run();
						//cout << "es3 static" << endl;
						es3.clear_task_energy();
						add_dynamic_energy += es3.dynamic_run();
						//cout << "es3 dynamic" << endl;
						es3.clear_task_energy();

						decrease_static_energy += es4.static_run();
						es4.clear_task_energy();
						decrease_dynamic_energy += es4.dynamic_run();
						es4.clear_task_energy();

						a_s += es5.static_run();
						//cout << "es5 static" << endl;
						es5.clear_task_energy();
						a_d += es5.dynamic_run();
						//cout << "es5 dynamic" << endl;
						es5.clear_task_energy();

						//another_s += es6.static_run();
						//cout << "ttt" << endl;
						//es6.clear_task_energy();
						//another_d += es6.dynamic_run();
						//es6.clear_task_energy();

						ods_s += es_ods.static_run();
						es_ods.clear_task_energy();
						ods_d += es_ods.dynamic_run();
						es_ods.clear_task_energy();

						out_ods_s += es_outdegree_ods.static_run();
						es_outdegree_ods.clear_task_energy();
						out_ods_d += es_outdegree_ods.dynamic_run();
						es_outdegree_ods.clear_task_energy();

						//cout << "aaa" << endl;
						//es_milp.Display_schedule();
						milp_s += es_milp.static_run();
						es_milp.clear_task_energy();


						cout << i << "/200" << endl;
					}
					//cout << "+++++++++++++++++++++++++++++++++++++" << endl;
					//es1.Display_schedule();
					cout << "----------------------------------" << endl;
					cout << "average heft energy: " << (double)heft_energy / 100 << endl;
					cout << "average static energy: " << (double)static_energy / 100 << endl;
					cout << "average dynamic energy: " << (double)dynamic_energy / 100 << endl;
					//cout << "average partial static energy: " << (double)partial_static_energy / 5000 << endl;
					//cout << "average partial dynamic energy: " << (double)partial_dynamic_energy / 5000 << endl;
					//cout << "average add static energy: " << (double)add_static_energy / 5000 << endl;
					//cout << "average add dynamic energy: " << (double)add_dynamic_energy / 5000 << endl;

					string l = argv[1];
					string radio = argv[3];
					string outputname = "F:\\vs-workspace\\GS_Result\\Release\\milp_result\\output_milp_normal_f2_" + radio + "_" + l;
					ofstream output(outputname, ios::app);
					
					//output << ccr_list[c_num] << " " << rel_list[i] << " " << deadline_list[j] << " " << (double)heft_energy / 100 << " " << (double)static_energy / 100 << " " << (double)dynamic_energy / 100 << endl;
					//output << ccr_list[c_num] << " " << rel_list[i] << " " << deadline_list[j] << " " << (double)heft_energy / times << " " << (double)static_energy / times << " " << (double)dynamic_energy / times << " " << (double)partial_static_energy / times << " " << (double)partial_dynamic_energy / times << " " << (double)add_static_energy / times << " " << (double)add_dynamic_energy / times << " " << (double)decrease_static_energy / times << " " << (double)decrease_dynamic_energy / times << " " << (double)a_s / times << " " << (double)a_d / times << endl;
					output << ccr_list[c_num] << " " << rel_list[i] << " " << deadline_list[j] << " " << (double)heft_energy / times << " " << (double)static_energy / times << " " << (double)dynamic_energy / times << " " << (double)partial_static_energy / times << " " << (double)partial_dynamic_energy / times << " " << (double)add_static_energy / times << " " << (double)add_dynamic_energy / times << " " << (double)decrease_static_energy / times << " " << (double)decrease_dynamic_energy / times << " " << (double)a_s / times << " " << (double)a_d / times << " " << (double)ods_s / times << " " << (double)ods_d / times << " " << (double)out_ods_s / times << " " << (double)out_ods_d / times <<
						" " << (double)milp_s / times  << endl;
					//output << (double)decrease_static_energy / 100 << " " << (double)decrease_dynamic_energy / 100 << endl;
					//output << (double)static_energy / 100 << " " << (double)dynamic_energy / 100 << " " << (double)decrease_static_energy / 100 << " " << (double)decrease_dynamic_energy / 100 << " " << (double)a_s / 100 << " " << (double)a_d / 100 << " " << (double)another_s / 100 << " " << (double)another_d / 100 << endl;
					//output << ccr_list[c_num] << " " << rel_list[i] << " " << deadline_list[j] << " " << (double)heft_energy / times << " " << (double)static_energy / times << " " << (double)dynamic_energy / times << " " << (double)nes1_s_energy / times << " " << (double)nes1_d_energy / times << endl;
					output.close();
					//cout << es6.times << endl;
					
				}
				else
					cout << "heft scheduing false" << endl;
			}
		}
	}

	




	/*es.set_reliability(rel_list[2]);
	vector<double> deadline_list = es.Calculate_Deadline_list(5);
	if (es.Calculate_Deadline_Priority(deadline_list[0]))
	{
		cout << "finish calculate Deadline" << endl;
		es.sort_task_with_priority();
		//es.Display_Deadline();
		//es.Display_layer();
		cout << "finish sort task" << endl;
		if (es.Heft_scheduing())
		{
			cout << "heft_scheduing true" << endl;
			if (es.scheduing())
			{
				cout << "scheduing true------------------------" << endl;
				//es.Display_optimal_replica();
				es.optimization();
				cout << "optimization true" << endl;
				es.Display_schedule();
				es.Display_heft_schedule();
				es.Display_replica_num();
				es.Display_task_time("GEMM_8_1_0");
				cout << "finish display" << endl;
				double static_energy = 0.00;
				double dynamic_energy = 0.00;
				double heft_energy = 0.00;
				for (int i = 0; i < 10; i++)
				{
					heft_energy += es.heft_static_run();
					es.clear_task_energy();
					static_energy += es.static_run();
					es.clear_task_energy();
					dynamic_energy += es.dynamic_run();
					es.clear_task_energy();
				}
				cout << "----------------------------------" << endl;
				cout << "average heft energy: " << (double)heft_energy / 10 << endl;
				cout << "average static energy: " << (double)static_energy / 10 << endl;
				cout << "average dynamic energy: " << (double)dynamic_energy / 10 << endl;
			}
			else
				cout << "scheduing false" << endl;
			
		}
		else
			cout << "heft scheduing false" << endl;
	}*/
	
	//system("pause");
	return 0;
}